<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
    exit;
}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">
    <title>BBDMS | Reports</title>

    <!-- CSS Files -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link rel="stylesheet" href="css/fileinput.min.css">
    <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .1);
        }

        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .1);
        }

        table th, table td {
            vertical-align: middle !important;
        }
    </style>
</head>

<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/leftbar.php'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Reports</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Search by Blood Group</div>
                        <div class="panel-body">
                            <form method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Select Blood Group</label>
                                    <div class="col-sm-4">
                                        <select name="bloodgroup" class="form-control" required>
                                            <option value="">Select</option>
                                            <?php 
                                            $sql = "SELECT DISTINCT BloodGroup FROM tblblooddonars";
                                            $query = $dbh->prepare($sql);
                                            $query->execute();
                                            $results = $query->fetchAll(PDO::FETCH_OBJ);
                                            foreach($results as $result) { ?>   
                                                <option value="<?php echo htmlentities($result->BloodGroup); ?>">
                                                    <?php echo htmlentities($result->BloodGroup); ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-2">
                                        <button type="submit" name="search" class="btn btn-primary">Get Report</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php 
                    if(isset($_POST['search'])) {
                        $bloodgroup = $_POST['bloodgroup'];
                        // Query to get the list of donors by Blood Group
                        $sql = "SELECT FullName, EmailId, MobileNumber, Gender, Age, Address, PostingDate 
                                FROM tblblooddonars 
                                WHERE BloodGroup = :bloodgroup AND status = 1"; // assuming 'status' is 1 for active donors
                        $query = $dbh->prepare($sql);
                        $query->bindParam(':bloodgroup', $bloodgroup, PDO::PARAM_STR);
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);

                        if($query->rowCount() > 0) {
                            echo "<div class='panel panel-default'>";
                            echo "<div class='panel-heading'>Donors with Blood Group: <strong>" . htmlentities($bloodgroup) . "</strong></div>";
                            echo "<div class='panel-body'>";
                            echo "<table class='table table-bordered table-striped'>";
                            echo "<thead><tr><th>#</th><th>Full Name</th><th>Email</th><th>Mobile</th><th>Gender</th><th>Age</th><th>Address</th><th>Posting Date</th></tr></thead>";
                            echo "<tbody>";
                            $cnt = 1;
                            foreach($results as $row) {
                                echo "<tr>";
                                echo "<td>" . $cnt++ . "</td>";
                                echo "<td>" . htmlentities($row->FullName) . "</td>";
                                echo "<td>" . htmlentities($row->EmailId) . "</td>";
                                echo "<td>" . htmlentities($row->MobileNumber) . "</td>";
                                echo "<td>" . htmlentities($row->Gender) . "</td>";
                                echo "<td>" . htmlentities($row->Age) . "</td>";
                                echo "<td>" . htmlentities($row->Address) . "</td>";
                                echo "<td>" . htmlentities($row->PostingDate) . "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody></table>";
                            echo "</div></div>";
                        } else {
                            echo "<div class='alert alert-warning'>No donors found for blood group <strong>" . htmlentities($bloodgroup) . "</strong>.</div>";
                        }
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>

</body>
</html>