<?php
/**
 * LifeBlood BBMS - AuthController
 * Handles login, rate-limiting, CSRF check, and session lifecycle
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Helpers\Auth;
use App\Helpers\Security;

class AuthController
{
    public function login(): void
    {
        Security::startSecureSession();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $csrfToken = $_POST['csrf_token'] ?? '';
            if (!Security::validateCsrfToken($csrfToken)) {
                http_response_code(403);
                die('Security Error: Invalid or expired CSRF token.');
            }

            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($email) || empty($password)) {
                $error = 'Email and password are required.';
                require __DIR__ . '/../../resources/views/auth/login.php';
                return;
            }

            $result = Auth::attemptLogin($email, $password);
            if ($result['success']) {
                header('Location: /blood-bank-management/public/index.php');
                exit;
            } else {
                $error = $result['message'];
                require __DIR__ . '/../../resources/views/auth/login.php';
                return;
            }
        }

        require __DIR__ . '/../../resources/views/auth/login.php';
    }

    public function logout(): void
    {
        Auth::logout();
        header('Location: /blood-bank-management/public/login.php');
        exit;
    }
}
