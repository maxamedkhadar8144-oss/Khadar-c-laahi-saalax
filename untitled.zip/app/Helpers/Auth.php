<?php
/**
 * LifeBlood BBMS - Role-Based Access Control (RBAC) & Authentication Helper
 */

declare(strict_types=1);

namespace App\Helpers;

use App\Config\Database;
use PDO;

class Auth
{
    /**
     * Map of standard system roles
     */
    public const ROLE_SUPER_ADMIN = 'super-admin';
    public const ROLE_BLOOD_BANK_ADMIN = 'blood-bank-admin';
    public const ROLE_BLOOD_BANK_TECH = 'blood-bank-tech';
    public const ROLE_LAB_TECH = 'lab-tech';
    public const ROLE_DONOR_OFFICER = 'donor-officer';
    public const ROLE_HOSPITAL_OFFICER = 'hospital-officer';
    public const ROLE_REPORT_VIEWER = 'report-viewer';

    /**
     * Attempt login with rate limiting & audit recording
     */
    public static function attemptLogin(string $email, string $password): array
    {
        Security::startSecureSession();
        $pdo = Database::getConnection();

        // Check if user exists
        $stmt = $pdo->prepare("
            SELECT u.*, r.slug AS role_slug, r.name AS role_name
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.email = :email
            LIMIT 1
        ");
        $stmt->execute(['email' => trim($email)]);
        $user = $stmt->fetch();

        if (!$user) {
            return ['success' => false, 'message' => 'Invalid email address or credentials.'];
        }

        if ((int)$user['is_active'] !== 1) {
            return ['success' => false, 'message' => 'Account is suspended or inactive. Please contact your system administrator.'];
        }

        // Check for lockout
        if ($user['lockout_until'] && strtotime($user['lockout_until']) > time()) {
            return ['success' => false, 'message' => 'Account temporarily locked due to multiple failed attempts. Please try again in 15 minutes.'];
        }

        // Verify password
        if (!Security::verifyPassword($password, $user['password_hash'])) {
            // Increment failed attempts
            $failed = (int)$user['failed_login_attempts'] + 1;
            $lockout = null;
            if ($failed >= 5) {
                $lockout = date('Y-m-d H:i:s', time() + 900); // 15 mins
            }
            $update = $pdo->prepare("UPDATE users SET failed_login_attempts = :f, lockout_until = :l WHERE id = :id");
            $update->execute(['f' => $failed, 'l' => $lockout, 'id' => $user['id']]);

            return ['success' => false, 'message' => 'Invalid email address or password.'];
        }

        // Login successful: Regenerate session ID to prevent fixation attacks
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['staff_id'] = $user['staff_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role_slug'] = $user['role_slug'];
        $_SESSION['role_name'] = $user['role_name'];
        $_SESSION['logged_in_at'] = time();

        // Reset failed attempts & record last login
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $update = $pdo->prepare("UPDATE users SET failed_login_attempts = 0, lockout_until = NULL, last_login_at = NOW(), last_login_ip = :ip WHERE id = :id");
        $update->execute(['ip' => $ip, 'id' => $user['id']]);

        return [
            'success' => true,
            'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'role' => $user['role_slug'],
                'role_name' => $user['role_name']
            ]
        ];
    }

    /**
     * Check if user is authenticated
     */
    public static function check(): bool
    {
        Security::startSecureSession();
        return !empty($_SESSION['user_id']);
    }

    /**
     * Get currently authenticated user data
     */
    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }
        return [
            'id' => $_SESSION['user_id'],
            'staff_id' => $_SESSION['staff_id'],
            'name' => $_SESSION['name'],
            'email' => $_SESSION['email'],
            'role_slug' => $_SESSION['role_slug'],
            'role_name' => $_SESSION['role_name']
        ];
    }

    /**
     * Enforce role authorization or exit with 403 Forbidden
     */
    public static function requireRoles(array $allowedRoles): void
    {
        if (!self::check()) {
            header('Location: /login.php');
            exit;
        }

        $currentRole = $_SESSION['role_slug'] ?? '';
        if (!in_array($currentRole, $allowedRoles, true)) {
            http_response_code(403);
            die('Access Denied: Your staff profile does not possess authorization for this action.');
        }
    }

    /**
     * Logout and destroy session completely
     */
    public static function logout(): void
    {
        Security::startSecureSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
    }
}
