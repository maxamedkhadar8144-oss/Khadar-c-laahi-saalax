<?php
/**
 * LifeBlood BBMS - Donor Model
 */

declare(strict_types=1);

namespace App\Models;

use App\Config\Database;
use PDO;

class Donor
{
    public static function getAll(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("
            SELECT d.*, bg.group_name AS blood_group 
            FROM donors d
            JOIN blood_groups bg ON d.blood_group_id = bg.id
            ORDER BY d.id DESC
        ");
        return $stmt->fetchAll();
    }

    public static function checkDuplicate(string $nationalId, string $phone): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT id, donor_number, first_name, last_name 
            FROM donors 
            WHERE national_id = :nid OR phone = :phone
            LIMIT 1
        ");
        $stmt->execute(['nid' => $nationalId, 'phone' => $phone]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
