/**
 * LifeBlood BBMS - Client-side Storage & Business Logic Engine
 * Persists in LocalStorage, providing transactional integrity, FEFO ordering,
 * audit logging, and barrier-controlled release workflows.
 */

import {
  User,
  Donor,
  Donation,
  BloodUnit,
  LabTest,
  CrossmatchRecord,
  BloodRequest,
  Hospital,
  BloodIssue,
  BloodReturn,
  RecallRecord,
  Appointment,
  AuditLogEntry,
  SystemSettings,
  ComponentDefinition,
  BloodGroup,
  ComponentCode,
  RoleSlug,
  BackupSnapshot
} from '../types';

export const COMPONENT_DEFINITIONS: Record<ComponentCode, ComponentDefinition> = {
  WB: {
    code: 'WB',
    name: 'Whole Blood',
    storageTemp: '2°C to 6°C',
    shelfLifeDays: 35,
    standardVolumeMl: 450,
    requiresAgitation: false,
  },
  PRBC: {
    code: 'PRBC',
    name: 'Packed Red Blood Cells',
    storageTemp: '2°C to 6°C',
    shelfLifeDays: 42,
    standardVolumeMl: 280,
    requiresAgitation: false,
  },
  PLT: {
    code: 'PLT',
    name: 'Platelets (Single Donor/Pool)',
    storageTemp: '20°C to 24°C',
    shelfLifeDays: 5,
    standardVolumeMl: 250,
    requiresAgitation: true,
  },
  FFP: {
    code: 'FFP',
    name: 'Fresh Frozen Plasma',
    storageTemp: '-18°C or colder',
    shelfLifeDays: 365,
    standardVolumeMl: 220,
    requiresAgitation: false,
  },
  CRYO: {
    code: 'CRYO',
    name: 'Cryoprecipitate AHF',
    storageTemp: '-18°C or colder',
    shelfLifeDays: 365,
    standardVolumeMl: 40,
    requiresAgitation: false,
  },
};

export const INITIAL_USERS: User[] = [
  {
    id: 1,
    staffId: 'STAFF-001',
    name: 'Dr. Amina Yusuf',
    email: 'admin@lifeblood.org',
    role: 'super-admin',
    roleName: 'Super Administrator',
    department: 'Executive Administration',
    isActive: true,
    lastLoginAt: '2026-10-21 08:30:00'
  },
  {
    id: 2,
    staffId: 'STAFF-002',
    name: 'Farah Hassan',
    email: 'operations@lifeblood.org',
    role: 'blood-bank-admin',
    roleName: 'Blood Bank Administrator',
    department: 'Operations & Stock Governance',
    isActive: true,
    lastLoginAt: '2026-10-21 07:45:00'
  },
  {
    id: 3,
    staffId: 'STAFF-003',
    name: 'Elena Rostova',
    email: 'lab@lifeblood.org',
    role: 'lab-tech',
    roleName: 'Laboratory Technician',
    department: 'Immunohematology & Viral Serology',
    isActive: true,
    lastLoginAt: '2026-10-21 08:10:00'
  },
  {
    id: 4,
    staffId: 'STAFF-004',
    name: 'Khadar Jama',
    email: 'tech@lifeblood.org',
    role: 'blood-bank-tech',
    roleName: 'Blood Bank Technician',
    department: 'Component Separation & Cold Chain',
    isActive: true,
    lastLoginAt: '2026-10-21 06:50:00'
  },
  {
    id: 5,
    staffId: 'STAFF-005',
    name: 'Sarah Jenkins',
    email: 'donors@lifeblood.org',
    role: 'donor-officer',
    roleName: 'Donor Registration Officer',
    department: 'Donor Recruitment & Mobile Drives',
    isActive: true,
    lastLoginAt: '2026-10-20 16:30:00'
  },
  {
    id: 6,
    staffId: 'STAFF-006',
    name: 'Dr. Evelyn Vance',
    email: 'stjude.orders@stjude.org',
    role: 'hospital-officer',
    roleName: 'Hospital Requesting Officer',
    department: 'St. Jude Transfusion Services',
    facility: 'St. Jude General Hospital',
    isActive: true,
    lastLoginAt: '2026-10-21 07:15:00'
  },
  {
    id: 7,
    staffId: 'STAFF-007',
    name: 'Inspector Cole',
    email: 'auditor@lifeblood.org',
    role: 'report-viewer',
    roleName: 'Report Viewer & Auditor',
    department: 'Health Ministry Regulatory Inspectorate',
    isActive: true,
    lastLoginAt: '2026-10-19 14:00:00'
  }
];

export const INITIAL_HOSPITALS: Hospital[] = [
  {
    id: 1,
    hospitalCode: 'HOSP-001',
    name: 'St. Jude General Hospital',
    facilityType: 'Tertiary Hospital',
    address: '1200 Mercy Drive',
    city: 'Capital City',
    phone: '+1-555-882-1000',
    email: 'bloodbank@stjude.org',
    licenseNumber: 'LIC-MED-2024-9981',
    contactPerson: 'Dr. Evelyn Vance',
    contactPhone: '+1-555-882-1044',
    isActive: true,
  },
  {
    id: 2,
    hospitalCode: 'HOSP-002',
    name: 'City Trauma & Emergency Center',
    facilityType: 'Specialized Trauma Center',
    address: '77 Responder Ave',
    city: 'Capital City',
    phone: '+1-555-911-3000',
    email: 'trauma.blood@citytrauma.gov',
    licenseNumber: 'LIC-MED-2023-4120',
    contactPerson: 'Dr. Marcus Sterling',
    contactPhone: '+1-555-911-3022',
    isActive: true,
  },
  {
    id: 3,
    hospitalCode: 'HOSP-003',
    name: 'Northwood Maternal & Pediatric Center',
    facilityType: 'Maternity Hospital',
    address: '304 Blossom Street',
    city: 'Northwood',
    phone: '+1-555-344-9000',
    email: 'orders@northwoodmaternal.org',
    licenseNumber: 'LIC-MED-2025-0711',
    contactPerson: 'Nurse Sup. Aisha Noor',
    contactPhone: '+1-555-344-9018',
    isActive: true,
  },
  {
    id: 4,
    hospitalCode: 'HOSP-004',
    name: 'Highland Memorial Regional Hospital',
    facilityType: 'Regional Referral Hospital',
    address: '500 Highland Peak Rd',
    city: 'Highland',
    phone: '+1-555-722-4400',
    email: 'lab@highlandmemorial.org',
    licenseNumber: 'LIC-MED-2022-8823',
    contactPerson: 'Dr. Tariq Farooq',
    contactPhone: '+1-555-722-4412',
    isActive: true,
  }
];

export const INITIAL_DONORS: Donor[] = [
  {
    id: 1,
    donorNumber: 'DON-2026-00101',
    firstName: 'Abdi',
    lastName: 'Warsame',
    nationalId: 'NAT-8829104',
    dateOfBirth: '1992-04-14',
    sex: 'Male',
    bloodGroup: 'O-',
    phone: '+1-555-201-9988',
    email: 'abdi.warsame@example.com',
    address: '14 Ocean View Avenue',
    city: 'Capital City',
    emergencyContactName: 'Hodan Warsame (Spouse)',
    emergencyContactPhone: '+1-555-201-9989',
    status: 'Active',
    consentSigned: true,
    consentDate: '2026-01-15',
    totalDonations: 7,
    lastDonationDate: '2026-08-12',
    nextEligibleDate: '2026-11-12',
    preferredContact: 'SMS',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-01-15 09:30:00'
  },
  {
    id: 2,
    donorNumber: 'DON-2026-00102',
    firstName: 'Liam',
    lastName: 'O\'Connor',
    nationalId: 'NAT-7749210',
    dateOfBirth: '1988-11-23',
    sex: 'Male',
    bloodGroup: 'O+',
    phone: '+1-555-302-8811',
    email: 'liam.oc@example.com',
    address: '78 Pinecrest Drive',
    city: 'Northwood',
    emergencyContactName: 'Sean O\'Connor (Brother)',
    emergencyContactPhone: '+1-555-302-8812',
    status: 'Active',
    consentSigned: true,
    consentDate: '2026-02-10',
    totalDonations: 4,
    lastDonationDate: '2026-09-02',
    nextEligibleDate: '2026-12-02',
    preferredContact: 'SMS',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-02-10 11:20:00'
  },
  {
    id: 3,
    donorNumber: 'DON-2026-00103',
    firstName: 'Faduma',
    lastName: 'Ali',
    nationalId: 'NAT-6638192',
    dateOfBirth: '1995-07-08',
    sex: 'Female',
    bloodGroup: 'A+',
    phone: '+1-555-403-7722',
    email: 'faduma.ali@example.com',
    address: '210 Maple Terrace',
    city: 'Capital City',
    emergencyContactName: 'Mariam Ali (Sister)',
    emergencyContactPhone: '+1-555-403-7723',
    status: 'Active',
    consentSigned: true,
    consentDate: '2026-03-01',
    totalDonations: 5,
    lastDonationDate: '2026-07-28',
    nextEligibleDate: '2026-11-28',
    preferredContact: 'Email',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-03-01 14:15:00'
  },
  {
    id: 4,
    donorNumber: 'DON-2026-00104',
    firstName: 'Mateo',
    lastName: 'Silva',
    nationalId: 'NAT-5527183',
    dateOfBirth: '1990-09-19',
    sex: 'Male',
    bloodGroup: 'B+',
    phone: '+1-555-504-6633',
    email: 'mateo.silva@example.com',
    address: '44 Highland Road',
    city: 'Eastgate',
    emergencyContactName: 'Lucia Silva (Spouse)',
    emergencyContactPhone: '+1-555-504-6634',
    status: 'Active',
    consentSigned: true,
    consentDate: '2026-02-18',
    totalDonations: 3,
    lastDonationDate: '2026-09-15',
    nextEligibleDate: '2026-12-15',
    preferredContact: 'SMS',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-02-18 10:00:00'
  },
  {
    id: 5,
    donorNumber: 'DON-2026-00105',
    firstName: 'Chloe',
    lastName: 'Dubois',
    nationalId: 'NAT-4416074',
    dateOfBirth: '1997-02-04',
    sex: 'Female',
    bloodGroup: 'AB+',
    phone: '+1-555-605-5544',
    email: 'chloe.d@example.com',
    address: '312 River Road',
    city: 'Northwood',
    emergencyContactName: 'Marc Dubois (Father)',
    emergencyContactPhone: '+1-555-605-5545',
    status: 'Active',
    consentSigned: true,
    consentDate: '2026-04-12',
    totalDonations: 2,
    lastDonationDate: '2026-08-30',
    nextEligibleDate: '2026-12-30',
    preferredContact: 'Phone',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-04-12 15:40:00'
  },
  {
    id: 6,
    donorNumber: 'DON-2026-00106',
    firstName: 'Zahra',
    lastName: 'Nur',
    nationalId: 'NAT-3305965',
    dateOfBirth: '1993-12-30',
    sex: 'Female',
    bloodGroup: 'A-',
    phone: '+1-555-706-4455',
    email: 'zahra.nur@example.com',
    address: '95 Cedar Lane',
    city: 'Capital City',
    emergencyContactName: 'Bilal Nur (Brother)',
    emergencyContactPhone: '+1-555-706-4456',
    status: 'Temporarily Deferred',
    consentSigned: true,
    consentDate: '2026-01-20',
    totalDonations: 6,
    lastDonationDate: '2026-06-20',
    nextEligibleDate: '2026-12-01',
    preferredContact: 'SMS',
    registeredBy: 'Sarah Jenkins',
    createdAt: '2026-01-20 09:00:00'
  }
];

export const INITIAL_BLOOD_UNITS: BloodUnit[] = [
  {
    id: 1,
    unitBarcode: 'DIN-2026-08819',
    donationId: 101,
    donationNumber: 'DN-2026-10491',
    componentCode: 'PRBC',
    componentName: 'Packed Red Blood Cells',
    bloodGroup: 'O-',
    volumeMl: 280,
    collectionDate: '2026-10-10 09:30:00',
    expiryDate: '2026-11-21 09:30:00',
    storageLocation: 'Emergency O- Reserve Fridge (FRIDGE-A2)',
    status: 'Released',
    version: 1
  },
  {
    id: 2,
    unitBarcode: 'DIN-2026-08820',
    donationId: 101,
    donationNumber: 'DN-2026-10491',
    componentCode: 'FFP',
    componentName: 'Fresh Frozen Plasma',
    bloodGroup: 'O-',
    volumeMl: 220,
    collectionDate: '2026-10-10 09:30:00',
    expiryDate: '2027-10-10 09:30:00',
    storageLocation: 'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
    status: 'Released',
    version: 1
  },
  {
    id: 3,
    unitBarcode: 'DIN-2026-08821',
    donationId: 102,
    donationNumber: 'DN-2026-10492',
    componentCode: 'PLT',
    componentName: 'Platelets (Single Donor/Pool)',
    bloodGroup: 'O+',
    volumeMl: 250,
    collectionDate: '2026-10-19 11:00:00',
    expiryDate: '2026-10-24 11:00:00', // Expiring in 3 days!
    storageLocation: 'Platelet Incubator & Agitator (AGITATOR-C1)',
    status: 'Released',
    version: 1
  },
  {
    id: 4,
    unitBarcode: 'DIN-2026-08822',
    donationId: 103,
    donationNumber: 'DN-2026-10493',
    componentCode: 'PRBC',
    componentName: 'Packed Red Blood Cells',
    bloodGroup: 'A+',
    volumeMl: 280,
    collectionDate: '2026-10-18 14:15:00',
    expiryDate: '2026-11-29 14:15:00',
    storageLocation: 'Main Red Cell Cold Room #1 (FRIDGE-A1)',
    status: 'Released',
    version: 1
  },
  {
    id: 5,
    unitBarcode: 'DIN-2026-08823',
    donationId: 104,
    donationNumber: 'DN-2026-10494',
    componentCode: 'WB',
    componentName: 'Whole Blood',
    bloodGroup: 'B+',
    volumeMl: 450,
    collectionDate: '2026-10-20 10:00:00',
    expiryDate: '2026-11-24 10:00:00',
    storageLocation: 'Pre-Testing Quarantine Cooler (QUARANTINE-Q1)',
    status: 'Quarantined',
    version: 1
  },
  {
    id: 6,
    unitBarcode: 'DIN-2026-08824',
    donationId: 105,
    donationNumber: 'DN-2026-10495',
    componentCode: 'PRBC',
    componentName: 'Packed Red Blood Cells',
    bloodGroup: 'AB+',
    volumeMl: 280,
    collectionDate: '2026-10-15 15:40:00',
    expiryDate: '2026-11-26 15:40:00',
    storageLocation: 'Main Red Cell Cold Room #1 (FRIDGE-A1)',
    status: 'Released',
    version: 1
  },
  {
    id: 7,
    unitBarcode: 'DIN-2026-08825',
    donationId: 106,
    donationNumber: 'DN-2026-10496',
    componentCode: 'PRBC',
    componentName: 'Packed Red Blood Cells',
    bloodGroup: 'O+',
    volumeMl: 280,
    collectionDate: '2026-10-12 08:45:00',
    expiryDate: '2026-11-23 08:45:00',
    storageLocation: 'Main Red Cell Cold Room #1 (FRIDGE-A1)',
    status: 'Reserved',
    reservedForRequestId: 1,
    version: 2
  },
  {
    id: 8,
    unitBarcode: 'DIN-2026-08826',
    donationId: 107,
    donationNumber: 'DN-2026-10497',
    componentCode: 'CRYO',
    componentName: 'Cryoprecipitate AHF',
    bloodGroup: 'A+',
    volumeMl: 40,
    collectionDate: '2026-09-01 10:20:00',
    expiryDate: '2027-09-01 10:20:00',
    storageLocation: 'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
    status: 'Released',
    version: 1
  }
];

export const INITIAL_REQUESTS: BloodRequest[] = [
  {
    id: 1,
    requestNumber: 'REQ-2026-00441',
    hospitalId: 2,
    hospitalName: 'City Trauma & Emergency Center',
    requestingClinician: 'Dr. Marcus Sterling',
    clinicianPhone: '+1-555-911-3022',
    patientReference: 'PT-TRAUMA-991',
    patientNameMasked: 'J. D. (Severe Hemorrhagic Shock)',
    patientBloodGroup: 'O-',
    componentCode: 'PRBC',
    unitsRequested: 2,
    unitsIssued: 0,
    clinicalIndication: 'Major motor vehicle collision trauma resus with massive transfusion protocol',
    priority: 'Emergency',
    status: 'Approved',
    requiredBy: '2026-10-21 12:00:00',
    reservedUnitBarcodes: ['DIN-2026-08825'],
    createdAt: '2026-10-21 07:15:00'
  },
  {
    id: 2,
    requestNumber: 'REQ-2026-00442',
    hospitalId: 1,
    hospitalName: 'St. Jude General Hospital',
    requestingClinician: 'Dr. Evelyn Vance',
    clinicianPhone: '+1-555-882-1044',
    patientReference: 'PT-CARDIO-412',
    patientNameMasked: 'M. K. (CABG Surgery)',
    patientBloodGroup: 'A+',
    componentCode: 'PRBC',
    unitsRequested: 3,
    unitsIssued: 0,
    clinicalIndication: 'Scheduled elective Coronary Artery Bypass Graft procedure',
    priority: 'Routine',
    status: 'Under Review',
    requiredBy: '2026-10-22 08:00:00',
    createdAt: '2026-10-21 08:00:00'
  },
  {
    id: 3,
    requestNumber: 'REQ-2026-00443',
    hospitalId: 3,
    hospitalName: 'Northwood Maternal & Pediatric Center',
    requestingClinician: 'Dr. S. K. Patel',
    clinicianPhone: '+1-555-344-9018',
    patientReference: 'PT-OB-802',
    patientNameMasked: 'R. N. (Postpartum Hemorrhage)',
    patientBloodGroup: 'O+',
    componentCode: 'PRBC',
    unitsRequested: 2,
    unitsIssued: 2,
    clinicalIndication: 'Acute primary postpartum hemorrhage management',
    priority: 'Urgent',
    status: 'Fulfilled',
    requiredBy: '2026-10-20 18:00:00',
    createdAt: '2026-10-20 16:30:00'
  }
];

export const INITIAL_LAB_TESTS: LabTest[] = [
  {
    id: 1,
    unitId: 5,
    unitBarcode: 'DIN-2026-08823',
    sampleBarcode: 'SMP-2026-9041',
    bloodGroupOriginal: 'B+',
    aboVerified: 'B',
    rhVerified: 'Positive',
    antibodyScreen: 'Negative',
    hivResult: 'Pending',
    hbsagResult: 'Pending',
    hcvResult: 'Pending',
    syphilisResult: 'Pending',
    overallDecision: 'Pending',
    testedBy: 'Elena Rostova',
    testedAt: '2026-10-20 13:45:00',
    notes: 'Infectious disease ELISA run in progress on Batch Serology-98.'
  },
  {
    id: 2,
    unitId: 1,
    unitBarcode: 'DIN-2026-08819',
    sampleBarcode: 'SMP-2026-8911',
    bloodGroupOriginal: 'O-',
    aboVerified: 'O',
    rhVerified: 'Negative',
    antibodyScreen: 'Negative',
    hivResult: 'Non-Reactive',
    hbsagResult: 'Non-Reactive',
    hcvResult: 'Non-Reactive',
    syphilisResult: 'Non-Reactive',
    overallDecision: 'Released',
    testedBy: 'Elena Rostova',
    verifiedBy: 'Dr. Amina Yusuf',
    verifiedAt: '2026-10-11 11:20:00',
    testedAt: '2026-10-10 16:30:00',
    notes: 'All standard blood bank screening non-reactive. Released for clinical emergency supply.'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 1,
    timestamp: '2026-10-21 07:15:00',
    userName: 'Dr. Marcus Sterling',
    userRole: 'hospital-officer',
    action: 'Blood Request Submitted',
    module: 'Requests',
    entityId: 'REQ-2026-00441',
    details: 'Submitted Emergency request for 2 units O- PRBC for trauma resus',
    ipAddress: '192.168.1.45'
  },
  {
    id: 2,
    timestamp: '2026-10-21 07:20:00',
    userName: 'Farah Hassan',
    userRole: 'blood-bank-admin',
    action: 'Request Approved & Reserved',
    module: 'Requests',
    entityId: 'REQ-2026-00441',
    details: 'Approved Emergency order; reserved unit DIN-2026-08825',
    ipAddress: '192.168.1.12'
  },
  {
    id: 3,
    timestamp: '2026-10-20 16:45:00',
    userName: 'Khadar Jama',
    userRole: 'blood-bank-tech',
    action: 'Blood Issue Dispatched',
    module: 'Issue',
    entityId: 'ISS-2026-00918',
    details: 'Issued 2 units O+ PRBC to Northwood Maternal Center in cold-box TB-04 (3.8°C)',
    ipAddress: '192.168.1.20'
  }
];

export const INITIAL_SETTINGS: SystemSettings = {
  organizationName: 'LifeBlood National Transfusion Service',
  licenseNumber: 'CLIN-REG-2026-NTS88',
  hotlinePhone: '+1-555-BLOOD-24',
  officialEmail: 'transfusion-dispatch@lifeblood.org',
  websiteUrl: 'https://lifeblood-transfusion.org',
  headquartersAddress: 'Building 4, National Health Complex, Clinical Boulevard',
  defaultLanguage: 'en',
  enableFefo: true,
  sessionTimeoutMinutes: 30,
  emergencyONegativeReserve: 15,
  autoQuarantineTesting: true,
  maxFailedLoginAttempts: 5,
  lockoutDurationMinutes: 15,
  theme: 'light',
  maintenanceMode: false,
  departments: [
    'Executive Administration',
    'Immunohematology & Viral Serology',
    'Component Separation & Cold Chain',
    'Donor Recruitment & Mobile Drives',
    'Transfusion Clinical Safety',
    'Hospital Distribution & Logistics',
    'Quality Assurance & Regulatory'
  ],
  storageLocations: [
    'Main Red Cell Cold Room #1 (FRIDGE-A1)',
    'Emergency O- Reserve Fridge (FRIDGE-A2)',
    'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
    'Platelet Incubator & Agitator (AGITATOR-C1)',
    'Pre-Testing Quarantine Cooler (QUARANTINE-Q1)',
    'Cryoprecipitate Sub-Zero Box (FREEZER-B2)'
  ]
};

export const INITIAL_BACKUPS: BackupSnapshot[] = [
  {
    id: 'BKP-2026-1020-001',
    name: 'Scheduled Weekly Disaster Recovery Dump',
    createdAt: '2026-10-20 04:00:00',
    sizeKb: 148,
    recordCount: 84,
    createdBy: 'System Automated Daemon',
    notes: 'Clean baseline snapshot following weekly viral serology batch verification.',
    version: '1.4.0',
    data: ''
  },
  {
    id: 'BKP-2026-1015-002',
    name: 'Pre-Audit Regulatory Inspection Snapshot',
    createdAt: '2026-10-15 18:30:00',
    sizeKb: 132,
    recordCount: 76,
    createdBy: 'Dr. Amina Yusuf',
    notes: 'Snapshot taken before external MoH health inspectorate review.',
    version: '1.4.0',
    data: ''
  }
];

// Storage Key Constants
const STORAGE_KEYS = {
  CURRENT_USER: 'lifeblood_current_user',
  USERS: 'lifeblood_users',
  DONORS: 'lifeblood_donors',
  UNITS: 'lifeblood_units',
  REQUESTS: 'lifeblood_requests',
  HOSPITALS: 'lifeblood_hospitals',
  LAB_TESTS: 'lifeblood_lab_tests',
  ISSUES: 'lifeblood_issues',
  RETURNS: 'lifeblood_returns',
  RECALLS: 'lifeblood_recalls',
  APPOINTMENTS: 'lifeblood_appointments',
  AUDIT_LOGS: 'lifeblood_audit_logs',
  SETTINGS: 'lifeblood_settings',
  BACKUPS: 'lifeblood_backups',
  LANGUAGE: 'lifeblood_language'
};

/**
 * Storage Service singleton implementing local DB operations
 */
export class StorageService {
  private static getItem<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data) as T;
    } catch {
      return defaultValue;
    }
  }

  private static setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Storage save failure for key ${key}:`, e);
    }
  }

  /**
   * Initialize and seed storage if empty
   */
  public static init(): void {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      this.setItem(STORAGE_KEYS.USERS, INITIAL_USERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.DONORS)) {
      this.setItem(STORAGE_KEYS.DONORS, INITIAL_DONORS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.UNITS)) {
      this.setItem(STORAGE_KEYS.UNITS, INITIAL_BLOOD_UNITS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.REQUESTS)) {
      this.setItem(STORAGE_KEYS.REQUESTS, INITIAL_REQUESTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.HOSPITALS)) {
      this.setItem(STORAGE_KEYS.HOSPITALS, INITIAL_HOSPITALS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.LAB_TESTS)) {
      this.setItem(STORAGE_KEYS.LAB_TESTS, INITIAL_LAB_TESTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS)) {
      this.setItem(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      this.setItem(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.BACKUPS)) {
      const sampleDump = {
        version: '1.4.0',
        exportedAt: '2026-10-20 04:00:00',
        metadata: { system: 'LifeBlood BBMS', database: 'MySQL 8.0 / LocalStorage' },
        tables: {
          users: INITIAL_USERS,
          donors: INITIAL_DONORS,
          units: INITIAL_BLOOD_UNITS,
          requests: INITIAL_REQUESTS,
          hospitals: INITIAL_HOSPITALS,
          settings: INITIAL_SETTINGS
        }
      };
      const backupsWithData = INITIAL_BACKUPS.map(b => ({
        ...b,
        data: JSON.stringify(sampleDump, null, 2)
      }));
      this.setItem(STORAGE_KEYS.BACKUPS, backupsWithData);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
      // Default to Super Admin for seamless development and evaluation
      this.setItem(STORAGE_KEYS.CURRENT_USER, INITIAL_USERS[0]);
    }
  }

  // --- Auth & Users ---
  public static getCurrentUser(): User {
    this.init();
    return this.getItem<User>(STORAGE_KEYS.CURRENT_USER, INITIAL_USERS[0]);
  }

  public static setCurrentUser(user: User): void {
    this.setItem(STORAGE_KEYS.CURRENT_USER, user);
    this.logAudit('User Switched Role / Logged In', 'Auth', user.staffId, `Logged in as ${user.name} (${user.roleName})`);
  }

  public static getUsers(): User[] {
    this.init();
    return this.getItem<User[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  }

  public static saveUser(user: User): void {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index >= 0) {
      users[index] = user;
    } else {
      user.id = Date.now();
      users.push(user);
    }
    this.setItem(STORAGE_KEYS.USERS, users);

    // If saving the active user, update current_user as well
    const current = this.getCurrentUser();
    if (current && current.id === user.id) {
      this.setItem(STORAGE_KEYS.CURRENT_USER, user);
    }

    this.logAudit('User Account Saved', 'Users', user.staffId, `Updated user account ${user.name} (${user.role})`);
  }

  public static updateUser(userId: number, updates: Partial<User>): User | null {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index === -1) return null;

    users[index] = { ...users[index], ...updates };
    this.setItem(STORAGE_KEYS.USERS, users);

    const current = this.getCurrentUser();
    if (current && current.id === userId) {
      this.setItem(STORAGE_KEYS.CURRENT_USER, users[index]);
    }

    this.logAudit('User Account Modified', 'Users', users[index].staffId, `Modified fields for user ${users[index].name}`);
    return users[index];
  }

  public static deleteUser(userId: number): { success: boolean; error?: string } {
    const users = this.getUsers();
    const target = users.find(u => u.id === userId);
    if (!target) {
      return { success: false, error: 'User not found in system.' };
    }

    const current = this.getCurrentUser();
    if (current && current.id === userId) {
      return { success: false, error: 'Cannot delete the currently active administrator account. Please switch users or login with another account first.' };
    }

    // Safety: Ensure there is at least one active Super Admin remaining
    if (target.role === 'super-admin') {
      const remainingSuperAdmins = users.filter(u => u.role === 'super-admin' && u.isActive && u.id !== userId);
      if (remainingSuperAdmins.length === 0) {
        return { success: false, error: 'Security barrier: Cannot delete the only active Super Administrator in the system.' };
      }
    }

    const remaining = users.filter(u => u.id !== userId);
    this.setItem(STORAGE_KEYS.USERS, remaining);
    this.logAudit('User Deleted', 'Users', target.staffId, `Deleted staff account: ${target.name} (${target.roleName})`);
    return { success: true };
  }

  // --- Donors ---
  public static getDonors(): Donor[] {
    this.init();
    return this.getItem<Donor[]>(STORAGE_KEYS.DONORS, INITIAL_DONORS);
  }

  public static saveDonor(donor: Partial<Donor>): { success: boolean; donor?: Donor; error?: string } {
    const donors = this.getDonors();
    
    // Duplicate check on nationalId and phone
    if (!donor.id) {
      const exists = donors.find(d => 
        (donor.nationalId && d.nationalId.toLowerCase() === donor.nationalId.toLowerCase()) ||
        (donor.phone && d.phone === donor.phone)
      );
      if (exists) {
        return { success: false, error: `Duplicate detected: A donor already exists with National ID ${exists.nationalId} or Phone ${exists.phone} (${exists.firstName} ${exists.lastName}).` };
      }
    }

    let savedDonor: Donor;
    if (donor.id) {
      const idx = donors.findIndex(d => d.id === donor.id);
      savedDonor = { ...donors[idx], ...donor } as Donor;
      donors[idx] = savedDonor;
    } else {
      const newId = donors.length > 0 ? Math.max(...donors.map(d => d.id)) + 1 : 1;
      const donorNumber = `DON-2026-${String(newId).padStart(5, '0')}`;
      savedDonor = {
        id: newId,
        donorNumber,
        firstName: donor.firstName || '',
        lastName: donor.lastName || '',
        nationalId: donor.nationalId || '',
        dateOfBirth: donor.dateOfBirth || '1995-01-01',
        sex: donor.sex || 'Male',
        bloodGroup: donor.bloodGroup || 'O+',
        phone: donor.phone || '',
        email: donor.email || '',
        address: donor.address || '',
        city: donor.city || 'Capital City',
        emergencyContactName: donor.emergencyContactName || '',
        emergencyContactPhone: donor.emergencyContactPhone || '',
        status: donor.status || 'Active',
        consentSigned: true,
        consentDate: new Date().toISOString().split('T')[0],
        totalDonations: donor.totalDonations || 0,
        preferredContact: donor.preferredContact || 'SMS',
        registeredBy: this.getCurrentUser().name,
        createdAt: new Date().toISOString()
      };
      donors.unshift(savedDonor);
    }

    this.setItem(STORAGE_KEYS.DONORS, donors);
    this.logAudit('Donor Profile Saved', 'Donors', savedDonor.donorNumber, `Saved donor record for ${savedDonor.firstName} ${savedDonor.lastName} (${savedDonor.bloodGroup})`);
    return { success: true, donor: savedDonor };
  }

  // --- Blood Units & Inventory ---
  public static getBloodUnits(): BloodUnit[] {
    this.init();
    return this.getItem<BloodUnit[]>(STORAGE_KEYS.UNITS, INITIAL_BLOOD_UNITS);
  }

  /**
   * Register a new donation: creates whole blood unit in QUARANTINED status
   * and creates pending laboratory testing record automatically
   */
  public static recordDonation(data: {
    donorId: number;
    collectionType: 'Whole Blood' | 'Apheresis Platelets' | 'Apheresis Plasma';
    volumeMl: number;
    bagBarcode: string;
    anticoagulantBatch: string;
    centerName: string;
    hasReaction?: boolean;
    reactionNotes?: string;
  }): { success: boolean; unit?: BloodUnit; donationNumber?: string; error?: string } {
    const donors = this.getDonors();
    const donor = donors.find(d => d.id === data.donorId);
    if (!donor) return { success: false, error: 'Donor not found' };
    if (donor.status.includes('Deferred')) {
      return { success: false, error: `Cannot collect blood: Donor status is currently ${donor.status}.` };
    }

    const units = this.getBloodUnits();
    const unitId = units.length > 0 ? Math.max(...units.map(u => u.id)) + 1 : 1;
    const unitBarcode = `DIN-2026-${String(Math.floor(10000 + Math.random() * 90000))}`;
    const donationNumber = `DN-2026-${String(Math.floor(10000 + Math.random() * 90000))}`;

    const now = new Date();
    // Expiry: 35 days for whole blood
    const expiry = new Date(now.getTime() + 35 * 24 * 60 * 60 * 1000);

    const compCode: ComponentCode = data.collectionType === 'Apheresis Platelets' ? 'PLT' : (data.collectionType === 'Apheresis Plasma' ? 'FFP' : 'WB');

    const newUnit: BloodUnit = {
      id: unitId,
      unitBarcode,
      donationId: unitId + 1000,
      donationNumber,
      componentCode: compCode,
      componentName: COMPONENT_DEFINITIONS[compCode].name,
      bloodGroup: donor.bloodGroup,
      volumeMl: data.volumeMl,
      collectionDate: now.toISOString(),
      expiryDate: expiry.toISOString(),
      storageLocation: 'Pre-Testing Quarantine Cooler (QUARANTINE-Q1)',
      status: 'Quarantined',
      version: 1
    };

    units.unshift(newUnit);
    this.setItem(STORAGE_KEYS.UNITS, units);

    // Update donor donation count and dates
    donor.totalDonations += 1;
    donor.lastDonationDate = now.toISOString().split('T')[0];
    const nextDate = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000); // 90 days deferral
    donor.nextEligibleDate = nextDate.toISOString().split('T')[0];
    this.setItem(STORAGE_KEYS.DONORS, donors);

    // Automatically create a pending Lab Test entry
    const labTests = this.getLabTests();
    const newTest: LabTest = {
      id: labTests.length > 0 ? Math.max(...labTests.map(t => t.id)) + 1 : 1,
      unitId: newUnit.id,
      unitBarcode: newUnit.unitBarcode,
      sampleBarcode: `SMP-2026-${String(Math.floor(1000 + Math.random() * 9000))}`,
      bloodGroupOriginal: donor.bloodGroup,
      aboVerified: donor.bloodGroup.replace(/[\+\-]/g, '') as 'A' | 'B' | 'AB' | 'O',
      rhVerified: donor.bloodGroup.includes('+') ? 'Positive' : 'Negative',
      antibodyScreen: 'Negative',
      hivResult: 'Pending',
      hbsagResult: 'Pending',
      hcvResult: 'Pending',
      syphilisResult: 'Pending',
      overallDecision: 'Pending',
      testedBy: this.getCurrentUser().name,
      testedAt: now.toISOString(),
      notes: `Fresh donation received from Center ${data.centerName}. Awaiting viral serology panels.`
    };
    labTests.unshift(newTest);
    this.setItem(STORAGE_KEYS.LAB_TESTS, labTests);

    this.logAudit('Donation Recorded', 'Donations', donationNumber, `Collected ${data.volumeMl}ml ${data.collectionType} from ${donor.firstName} ${donor.lastName} (Unit ${unitBarcode})`);

    return { success: true, unit: newUnit, donationNumber };
  }

  /**
   * Component Fractionation: Splits a Whole Blood unit into PRBC, Platelets, FFP, and Cryo
   * Marks parent unit as Discarded / Processed so stock is never double counted!
   */
  public static fractionateUnit(parentUnitBarcode: string, options: {
    makePRBC: boolean;
    makePlatelets: boolean;
    makeFFP: boolean;
    makeCryo: boolean;
  }): { success: boolean; derivedUnits?: BloodUnit[]; error?: string } {
    const units = this.getBloodUnits();
    const parent = units.find(u => u.unitBarcode === parentUnitBarcode);
    if (!parent) return { success: false, error: 'Parent unit not found' };
    if (parent.componentCode !== 'WB') return { success: false, error: 'Only Whole Blood units can be separated into components' };
    if (parent.status === 'Issued' || parent.status === 'Discarded') {
      return { success: false, error: `Unit is already ${parent.status}` };
    }

    const now = new Date();
    const derived: BloodUnit[] = [];

    // 1. Packed Red Blood Cells (42 days)
    if (options.makePRBC) {
      const prbcId = Math.max(...units.map(u => u.id), 0) + 1 + derived.length;
      derived.push({
        id: prbcId,
        unitBarcode: `DIN-PRBC-${String(Math.floor(10000 + Math.random() * 90000))}`,
        donationId: parent.donationId,
        donationNumber: parent.donationNumber,
        parentUnitBarcode: parent.unitBarcode,
        componentCode: 'PRBC',
        componentName: COMPONENT_DEFINITIONS.PRBC.name,
        bloodGroup: parent.bloodGroup,
        volumeMl: 280,
        collectionDate: parent.collectionDate,
        expiryDate: new Date(now.getTime() + 42 * 24 * 60 * 60 * 1000).toISOString(),
        storageLocation: 'Main Red Cell Cold Room #1 (FRIDGE-A1)',
        status: parent.status,
        version: 1
      });
    }

    // 2. Platelets (5 days)
    if (options.makePlatelets) {
      const pltId = Math.max(...units.map(u => u.id), 0) + 1 + derived.length;
      derived.push({
        id: pltId,
        unitBarcode: `DIN-PLT-${String(Math.floor(10000 + Math.random() * 90000))}`,
        donationId: parent.donationId,
        donationNumber: parent.donationNumber,
        parentUnitBarcode: parent.unitBarcode,
        componentCode: 'PLT',
        componentName: COMPONENT_DEFINITIONS.PLT.name,
        bloodGroup: parent.bloodGroup,
        volumeMl: 250,
        collectionDate: parent.collectionDate,
        expiryDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString(),
        storageLocation: 'Platelet Incubator & Agitator (AGITATOR-C1)',
        status: parent.status,
        version: 1
      });
    }

    // 3. Fresh Frozen Plasma (365 days)
    if (options.makeFFP) {
      const ffpId = Math.max(...units.map(u => u.id), 0) + 1 + derived.length;
      derived.push({
        id: ffpId,
        unitBarcode: `DIN-FFP-${String(Math.floor(10000 + Math.random() * 90000))}`,
        donationId: parent.donationId,
        donationNumber: parent.donationNumber,
        parentUnitBarcode: parent.unitBarcode,
        componentCode: 'FFP',
        componentName: COMPONENT_DEFINITIONS.FFP.name,
        bloodGroup: parent.bloodGroup,
        volumeMl: 220,
        collectionDate: parent.collectionDate,
        expiryDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        storageLocation: 'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
        status: parent.status,
        version: 1
      });
    }

    // 4. Cryoprecipitate (365 days)
    if (options.makeCryo) {
      const cryoId = Math.max(...units.map(u => u.id), 0) + 1 + derived.length;
      derived.push({
        id: cryoId,
        unitBarcode: `DIN-CRYO-${String(Math.floor(10000 + Math.random() * 90000))}`,
        donationId: parent.donationId,
        donationNumber: parent.donationNumber,
        parentUnitBarcode: parent.unitBarcode,
        componentCode: 'CRYO',
        componentName: COMPONENT_DEFINITIONS.CRYO.name,
        bloodGroup: parent.bloodGroup,
        volumeMl: 40,
        collectionDate: parent.collectionDate,
        expiryDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        storageLocation: 'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
        status: parent.status,
        version: 1
      });
    }

    // Mark parent Whole Blood unit as Discarded/Fractionated
    parent.status = 'Discarded';
    parent.discardReason = `Fractionated into components: ${derived.map(d => d.componentCode).join(', ')}`;

    units.push(...derived);
    this.setItem(STORAGE_KEYS.UNITS, units);

    this.logAudit('Component Fractionation', 'Components', parent.unitBarcode, `Separated Whole Blood ${parent.unitBarcode} into ${derived.length} child components`);

    return { success: true, derivedUnits: derived };
  }

  // --- Laboratory Tests ---
  public static getLabTests(): LabTest[] {
    this.init();
    return this.getItem<LabTest[]>(STORAGE_KEYS.LAB_TESTS, INITIAL_LAB_TESTS);
  }

  /**
   * Complete lab test and release/reject unit
   */
  public static updateLabTest(test: LabTest): { success: boolean; error?: string } {
    const tests = this.getLabTests();
    const idx = tests.findIndex(t => t.id === test.id);
    if (idx < 0) return { success: false, error: 'Test record not found' };

    const units = this.getBloodUnits();
    const unit = units.find(u => u.unitBarcode === test.unitBarcode);

    // If decision is Released: Verify non-reactive across all 4 mandatory diseases!
    if (test.overallDecision === 'Released') {
      const isClean = 
        test.hivResult === 'Non-Reactive' &&
        test.hbsagResult === 'Non-Reactive' &&
        test.hcvResult === 'Non-Reactive' &&
        test.syphilisResult === 'Non-Reactive' &&
        test.antibodyScreen === 'Negative';

      if (!isClean) {
        return {
          success: false,
          error: 'Transfusion Safety Violation: Cannot authorize release. All infectious disease screenings (HIV, HBV, HCV, Syphilis) and antibody screening must test strictly NON-REACTIVE / NEGATIVE.'
        };
      }

      if (unit && unit.status === 'Quarantined') {
        unit.status = 'Released';
        unit.storageLocation = unit.componentCode === 'PRBC' ? 'Main Red Cell Cold Room #1 (FRIDGE-A1)' :
          (unit.componentCode === 'PLT' ? 'Platelet Incubator & Agitator (AGITATOR-C1)' : 'Ultra-Low Plasma Freezer #1 (FREEZER-B1)');
      }
    } else if (test.overallDecision === 'Rejected') {
      if (unit) {
        unit.status = 'Discarded';
        unit.discardReason = `Laboratory test reactive / positive: HIV: ${test.hivResult}, HBV: ${test.hbsagResult}, HCV: ${test.hcvResult}, Syphilis: ${test.syphilisResult}`;
      }
    }

    test.verifiedBy = this.getCurrentUser().name;
    test.verifiedAt = new Date().toISOString();
    tests[idx] = test;

    this.setItem(STORAGE_KEYS.LAB_TESTS, tests);
    this.setItem(STORAGE_KEYS.UNITS, units);

    this.logAudit('Laboratory Results Verified', 'Laboratory', test.sampleBarcode, `Verified unit ${test.unitBarcode} decision: ${test.overallDecision}`);

    return { success: true };
  }

  // --- Blood Requests ---
  public static getBloodRequests(): BloodRequest[] {
    this.init();
    return this.getItem<BloodRequest[]>(STORAGE_KEYS.REQUESTS, INITIAL_REQUESTS);
  }

  public static saveBloodRequest(req: Partial<BloodRequest>): { success: boolean; request?: BloodRequest; error?: string } {
    const requests = this.getBloodRequests();
    const user = this.getCurrentUser();
    let saved: BloodRequest;

    if (req.id) {
      const idx = requests.findIndex(r => r.id === req.id);
      saved = { ...requests[idx], ...req } as BloodRequest;
      requests[idx] = saved;
    } else {
      const newId = requests.length > 0 ? Math.max(...requests.map(r => r.id)) + 1 : 1;
      const requestNumber = `REQ-2026-${String(newId).padStart(5, '0')}`;
      saved = {
        id: newId,
        requestNumber,
        hospitalId: req.hospitalId || 1,
        hospitalName: req.hospitalName || 'St. Jude General Hospital',
        requestingClinician: req.requestingClinician || user.name,
        clinicianPhone: req.clinicianPhone || '+1-555-882-1044',
        patientReference: req.patientReference || `PT-REF-${Math.floor(100 + Math.random() * 900)}`,
        patientNameMasked: req.patientNameMasked || 'Patient Confidential',
        patientBloodGroup: req.patientBloodGroup || 'O+',
        componentCode: req.componentCode || 'PRBC',
        unitsRequested: req.unitsRequested || 1,
        unitsIssued: 0,
        clinicalIndication: req.clinicalIndication || 'Urgent Transfusion Support',
        priority: req.priority || 'Routine',
        status: req.status || 'Submitted',
        requiredBy: req.requiredBy || new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
        createdAt: new Date().toISOString()
      };
      requests.unshift(saved);
    }

    this.setItem(STORAGE_KEYS.REQUESTS, requests);
    this.logAudit('Blood Request Updated', 'Requests', saved.requestNumber, `Request ${saved.requestNumber} for ${saved.unitsRequested} units ${saved.patientBloodGroup} ${saved.componentCode} (${saved.priority})`);

    return { success: true, request: saved };
  }

  /**
   * Controlled Blood Issue: Takes unit, confirms cold chain temperature, generates delivery slip,
   * transitions unit status to 'Issued', updates request fulfilled counts
   */
  public static issueBloodUnit(data: {
    requestId: number;
    unitBarcode: string;
    receivingOfficerName: string;
    receivingOfficerId: string;
    transportTempCelsius: number;
    transportBoxId: string;
  }): { success: boolean; issueSlip?: BloodIssue; error?: string } {
    const units = this.getBloodUnits();
    const unit = units.find(u => u.unitBarcode === data.unitBarcode);
    if (!unit) return { success: false, error: 'Blood unit not found' };

    if (unit.status !== 'Released' && unit.status !== 'Reserved') {
      return { success: false, error: `Safety Block: Cannot issue unit in ${unit.status} status. Only Released or Reserved units may be issued.` };
    }

    // Check cold chain transport temperatures
    // PRBC / WB: 2 to 6°C (up to 10°C during transport)
    // FFP: <= -18°C
    // Platelets: 20 to 24°C
    if (unit.componentCode === 'PRBC' || unit.componentCode === 'WB') {
      if (data.transportTempCelsius < 1.0 || data.transportTempCelsius > 10.0) {
        return { success: false, error: `Cold Chain Alert: Red blood cells must be transported between 2°C and 10°C. Recorded: ${data.transportTempCelsius}°C.` };
      }
    } else if (unit.componentCode === 'FFP') {
      if (data.transportTempCelsius > -10.0) {
        return { success: false, error: `Cold Chain Alert: Frozen plasma must be transported frozen with dry ice (below -10°C). Recorded: ${data.transportTempCelsius}°C.` };
      }
    }

    const requests = this.getBloodRequests();
    const req = requests.find(r => r.id === data.requestId);
    if (!req) return { success: false, error: 'Associated blood request not found' };

    // Update unit
    unit.status = 'Issued';
    unit.issuedToHospitalId = req.hospitalId;

    // Update request
    req.unitsIssued += 1;
    if (req.unitsIssued >= req.unitsRequested) {
      req.status = 'Fulfilled';
    } else {
      req.status = 'Partially Fulfilled';
    }

    const issues = this.getItem<BloodIssue[]>(STORAGE_KEYS.ISSUES, []);
    const issueSlipNumber = `ISS-2026-${String(Math.floor(10000 + Math.random() * 90000))}`;
    const newIssue: BloodIssue = {
      id: Date.now(),
      issueSlipNumber,
      requestId: req.id,
      requestNumber: req.requestNumber,
      unitId: unit.id,
      unitBarcode: unit.unitBarcode,
      componentCode: unit.componentCode,
      bloodGroup: unit.bloodGroup,
      hospitalName: req.hospitalName,
      receivingOfficer: data.receivingOfficerName,
      receivingOfficerId: data.receivingOfficerId,
      transportTempCelsius: data.transportTempCelsius,
      transportBoxId: data.transportBoxId,
      issuedBy: this.getCurrentUser().name,
      issuedAt: new Date().toISOString()
    };
    issues.unshift(newIssue);

    this.setItem(STORAGE_KEYS.UNITS, units);
    this.setItem(STORAGE_KEYS.REQUESTS, requests);
    this.setItem(STORAGE_KEYS.ISSUES, issues);

    this.logAudit('Blood Unit Issued', 'Issue', issueSlipNumber, `Issued unit ${unit.unitBarcode} (${unit.bloodGroup} ${unit.componentCode}) to ${req.hospitalName}`);

    return { success: true, issueSlip: newIssue };
  }

  // --- Recalls ---
  public static getRecalls(): RecallRecord[] {
    this.init();
    return this.getItem<RecallRecord[]>(STORAGE_KEYS.RECALLS, [
      {
        id: 1,
        recallCode: 'RCL-2026-001',
        reason: 'Donor post-donation notification: Diagnosed with acute bacterial illness within 24h of collection',
        severity: 'Critical',
        donorNumber: 'DON-2026-00106',
        affectedUnitBarcodes: ['DIN-2026-08823'],
        status: 'Quarantined',
        actionTaken: 'All derived components recalled and placed under quarantine lock.',
        initiatedBy: 'Dr. Amina Yusuf',
        createdAt: '2026-10-20 10:00:00'
      }
    ]);
  }

  public static initiateRecall(reason: string, severity: 'Critical' | 'High' | 'Moderate', unitBarcode: string): { success: boolean } {
    const units = this.getBloodUnits();
    const unit = units.find(u => u.unitBarcode === unitBarcode);
    if (!unit) return { success: false };

    // Quarantine this unit and all units with the same donationId!
    const affected = units.filter(u => u.donationId === unit.donationId);
    affected.forEach(u => {
      u.status = 'Recalled';
      u.discardReason = `Product Recall Initiated: ${reason}`;
    });

    const recalls = this.getRecalls();
    recalls.unshift({
      id: Date.now(),
      recallCode: `RCL-2026-${String(Math.floor(100 + Math.random() * 900))}`,
      reason,
      severity,
      affectedUnitBarcodes: affected.map(a => a.unitBarcode),
      status: 'Active',
      actionTaken: 'Units locked and quarantined across all storage rooms.',
      initiatedBy: this.getCurrentUser().name,
      createdAt: new Date().toISOString()
    });

    this.setItem(STORAGE_KEYS.UNITS, units);
    this.setItem(STORAGE_KEYS.RECALLS, recalls);

    this.logAudit('Recall Initiated', 'Recalls', unitBarcode, `Critical recall for donation ${unit.donationNumber}: ${affected.length} units quarantined`);

    return { success: true };
  }

  // --- Issues, Returns & Appointments ---
  public static getBloodIssues(): BloodIssue[] {
    this.init();
    return this.getItem<BloodIssue[]>(STORAGE_KEYS.ISSUES, []);
  }

  public static getBloodReturns(): BloodReturn[] {
    this.init();
    return this.getItem<BloodReturn[]>(STORAGE_KEYS.RETURNS, []);
  }

  public static getAppointments(): Appointment[] {
    this.init();
    return this.getItem<Appointment[]>(STORAGE_KEYS.APPOINTMENTS, [
      {
        id: 1,
        donorId: 1,
        donorName: 'Abdi Warsame',
        donorNumber: 'DON-2026-00101',
        bloodGroup: 'O-',
        phone: '+1-555-201-9988',
        centerName: 'Metropolitan Blood Transfusion Center (CTR-HQ)',
        appointmentDate: '2026-10-22',
        appointmentTime: '10:00 AM',
        status: 'Confirmed',
        reminderSent: true,
        notes: 'Whole blood repeat donation slot'
      },
      {
        id: 2,
        donorId: 3,
        donorName: 'Faduma Ali',
        donorNumber: 'DON-2026-00103',
        bloodGroup: 'A+',
        phone: '+1-555-403-7722',
        centerName: 'Northside Community Donor Clinic (CTR-NORTH)',
        appointmentDate: '2026-10-23',
        appointmentTime: '02:30 PM',
        status: 'Scheduled',
        reminderSent: false,
        notes: 'Platelet apheresis pre-booked session'
      }
    ]);
  }

  // --- Audit Logs ---
  public static getAuditLogs(): AuditLogEntry[] {
    this.init();
    return this.getItem<AuditLogEntry[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  }

  public static logAudit(action: string, module: string, entityId: string, details: string): void {
    const logs = this.getAuditLogs();
    const user = this.getCurrentUser();
    logs.unshift({
      id: Date.now() + Math.floor(Math.random() * 1000),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userName: user ? user.name : 'System',
      userRole: user ? user.role : 'system',
      action,
      module,
      entityId,
      details,
      ipAddress: '127.0.0.1'
    });
    // Keep last 300 logs
    this.setItem(STORAGE_KEYS.AUDIT_LOGS, logs.slice(0, 300));
  }

  // --- Hospitals ---
  public static getHospitals(): Hospital[] {
    this.init();
    return this.getItem<Hospital[]>(STORAGE_KEYS.HOSPITALS, INITIAL_HOSPITALS);
  }

  // --- Settings ---
  public static getSettings(): SystemSettings {
    this.init();
    return this.getItem<SystemSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
  }

  public static saveSettings(settings: SystemSettings): void {
    this.setItem(STORAGE_KEYS.SETTINGS, settings);
    this.logAudit('System Settings Updated', 'Settings', 'CONFIG', 'Organization parameters and stock thresholds updated');
  }

  // --- Backups Management (Add, Edit, Delete, Restore, Import/Export) ---
  public static getBackups(): BackupSnapshot[] {
    this.init();
    return this.getItem<BackupSnapshot[]>(STORAGE_KEYS.BACKUPS, INITIAL_BACKUPS);
  }

  public static createBackup(name: string, notes?: string): BackupSnapshot {
    const backups = this.getBackups();
    const currentUser = this.getCurrentUser();
    
    const dump = {
      version: '1.4.0',
      exportedAt: new Date().toISOString(),
      metadata: { 
        system: 'LifeBlood BBMS', 
        facility: this.getSettings().organizationName,
        schemaVersion: '2026.1'
      },
      tables: {
        users: this.getUsers(),
        donors: this.getDonors(),
        units: this.getBloodUnits(),
        requests: this.getBloodRequests(),
        hospitals: this.getHospitals(),
        labTests: this.getLabTests(),
        issues: this.getBloodIssues(),
        returns: this.getBloodReturns(),
        recalls: this.getRecalls(),
        appointments: this.getAppointments(),
        auditLogs: this.getAuditLogs(),
        settings: this.getSettings()
      }
    };

    const serialized = JSON.stringify(dump, null, 2);
    const totalRecords = 
      dump.tables.users.length +
      dump.tables.donors.length +
      dump.tables.units.length +
      dump.tables.requests.length +
      dump.tables.hospitals.length +
      dump.tables.labTests.length +
      dump.tables.issues.length +
      dump.tables.returns.length +
      dump.tables.recalls.length +
      dump.tables.appointments.length;

    const newBackup: BackupSnapshot = {
      id: `BKP-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      name: name.trim() || `System Snapshot ${new Date().toLocaleDateString()}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      sizeKb: Math.max(1, Math.round(serialized.length / 1024)),
      recordCount: totalRecords,
      createdBy: currentUser ? currentUser.name : 'Administrator',
      notes: notes?.trim() || 'Manual full clinical database state backup',
      version: '1.4.0',
      data: serialized
    };

    backups.unshift(newBackup);
    this.setItem(STORAGE_KEYS.BACKUPS, backups);
    this.logAudit('Database Backup Created', 'Backup', newBackup.id, `Created snapshot "${newBackup.name}" (${newBackup.sizeKb} KB, ${newBackup.recordCount} records)`);
    return newBackup;
  }

  public static updateBackup(id: string, name: string, notes?: string): BackupSnapshot | null {
    const backups = this.getBackups();
    const index = backups.findIndex(b => b.id === id);
    if (index === -1) return null;

    backups[index].name = name.trim();
    if (notes !== undefined) {
      backups[index].notes = notes.trim();
    }

    this.setItem(STORAGE_KEYS.BACKUPS, backups);
    this.logAudit('Database Backup Updated', 'Backup', id, `Updated metadata for backup snapshot "${backups[index].name}"`);
    return backups[index];
  }

  public static deleteBackup(id: string): boolean {
    const backups = this.getBackups();
    const target = backups.find(b => b.id === id);
    if (!target) return false;

    const remaining = backups.filter(b => b.id !== id);
    this.setItem(STORAGE_KEYS.BACKUPS, remaining);
    this.logAudit('Database Backup Deleted', 'Backup', id, `Removed backup snapshot: ${target.name}`);
    return true;
  }

  public static restoreBackup(id: string): { success: boolean; error?: string } {
    const backups = this.getBackups();
    const backup = backups.find(b => b.id === id);
    if (!backup) {
      return { success: false, error: 'Backup snapshot not found.' };
    }

    if (!backup.data || backup.data.trim() === '') {
      return { success: false, error: 'This snapshot has empty payload data.' };
    }

    try {
      const parsed = JSON.parse(backup.data);
      if (!parsed.tables) {
        return { success: false, error: 'Invalid backup structure: missing tables payload.' };
      }

      if (Array.isArray(parsed.tables.users)) this.setItem(STORAGE_KEYS.USERS, parsed.tables.users);
      if (Array.isArray(parsed.tables.donors)) this.setItem(STORAGE_KEYS.DONORS, parsed.tables.donors);
      if (Array.isArray(parsed.tables.units)) this.setItem(STORAGE_KEYS.UNITS, parsed.tables.units);
      if (Array.isArray(parsed.tables.requests)) this.setItem(STORAGE_KEYS.REQUESTS, parsed.tables.requests);
      if (Array.isArray(parsed.tables.hospitals)) this.setItem(STORAGE_KEYS.HOSPITALS, parsed.tables.hospitals);
      if (Array.isArray(parsed.tables.labTests)) this.setItem(STORAGE_KEYS.LAB_TESTS, parsed.tables.labTests);
      if (Array.isArray(parsed.tables.issues)) this.setItem(STORAGE_KEYS.ISSUES, parsed.tables.issues);
      if (Array.isArray(parsed.tables.returns)) this.setItem(STORAGE_KEYS.RETURNS, parsed.tables.returns);
      if (Array.isArray(parsed.tables.recalls)) this.setItem(STORAGE_KEYS.RECALLS, parsed.tables.recalls);
      if (Array.isArray(parsed.tables.appointments)) this.setItem(STORAGE_KEYS.APPOINTMENTS, parsed.tables.appointments);
      if (parsed.tables.settings) this.setItem(STORAGE_KEYS.SETTINGS, parsed.tables.settings);

      this.logAudit('System Database Restored', 'Backup', id, `Database state restored from snapshot: ${backup.name}`);
      return { success: true };
    } catch (e) {
      return { success: false, error: `Failed to restore snapshot: ${e instanceof Error ? e.message : 'Unknown parse error'}` };
    }
  }

  public static importBackupData(jsonString: string, customName?: string): { success: boolean; backup?: BackupSnapshot; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.tables && !parsed.users && !parsed.donors) {
        return { success: false, error: 'Imported file does not contain valid LifeBlood database tables.' };
      }

      const tables = parsed.tables || parsed;
      const totalRecords = 
        (tables.users?.length || 0) +
        (tables.donors?.length || 0) +
        (tables.units?.length || 0) +
        (tables.requests?.length || 0) +
        (tables.hospitals?.length || 0);

      const backups = this.getBackups();
      const backup: BackupSnapshot = {
        id: `BKP-IMP-${Date.now().toString().slice(-6)}`,
        name: customName || parsed.metadata?.system || `Imported Snapshot ${new Date().toLocaleDateString()}`,
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        sizeKb: Math.max(1, Math.round(jsonString.length / 1024)),
        recordCount: totalRecords,
        createdBy: this.getCurrentUser().name,
        notes: `Imported from external file on ${new Date().toLocaleString()}`,
        version: parsed.version || '1.4.0',
        data: JSON.stringify(parsed, null, 2)
      };

      backups.unshift(backup);
      this.setItem(STORAGE_KEYS.BACKUPS, backups);
      this.logAudit('Backup File Imported', 'Backup', backup.id, `Imported external backup file: ${backup.name}`);
      return { success: true, backup };
    } catch (e) {
      return { success: false, error: `Invalid JSON format: ${e instanceof Error ? e.message : 'Could not parse'}` };
    }
  }

  // --- Reset to Default Demo State ---
  public static resetToFactoryDefaults(): void {
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.DONORS);
    localStorage.removeItem(STORAGE_KEYS.UNITS);
    localStorage.removeItem(STORAGE_KEYS.REQUESTS);
    localStorage.removeItem(STORAGE_KEYS.HOSPITALS);
    localStorage.removeItem(STORAGE_KEYS.LAB_TESTS);
    localStorage.removeItem(STORAGE_KEYS.ISSUES);
    localStorage.removeItem(STORAGE_KEYS.RETURNS);
    localStorage.removeItem(STORAGE_KEYS.RECALLS);
    localStorage.removeItem(STORAGE_KEYS.APPOINTMENTS);
    localStorage.removeItem(STORAGE_KEYS.AUDIT_LOGS);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.BACKUPS);
    this.init();
  }
}
