import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  Plus, 
  Send, 
  CheckCircle2, 
  X, 
  User as UserIcon, 
  MapPin, 
  Phone,
  MessageSquare,
  Mail
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { Appointment, Donor, BloodGroup } from '../../types';

export const AppointmentsView: React.FC = () => {
  const donors = StorageService.getDonors();
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: 1,
      donorId: 1,
      donorName: 'Abdi Warsame',
      donorNumber: 'DON-2026-00101',
      bloodGroup: 'O-',
      phone: '+1-555-201-9988',
      centerName: 'Metropolitan Blood Transfusion Center (CTR-HQ)',
      appointmentDate: '2026-10-22',
      appointmentTime: '10:00 AM',
      status: 'Confirmed',
      reminderSent: true,
      notes: 'Whole blood repeat donation slot'
    },
    {
      id: 2,
      donorId: 3,
      donorName: 'Faduma Ali',
      donorNumber: 'DON-2026-00103',
      bloodGroup: 'A+',
      phone: '+1-555-403-7722',
      centerName: 'Northside Community Donor Clinic (CTR-NORTH)',
      appointmentDate: '2026-10-23',
      appointmentTime: '02:30 PM',
      status: 'Scheduled',
      reminderSent: false,
      notes: 'Regular donor reminder booking'
    }
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDonorId, setSelectedDonorId] = useState<number>(donors[0]?.id || 1);
  const [appDate, setAppDate] = useState('2026-10-24');
  const [appTime, setAppTime] = useState('09:30 AM');
  const [centerName, setCenterName] = useState('Metropolitan Blood Transfusion Center (CTR-HQ)');
  const [notes, setNotes] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const donor = donors.find(d => d.id === selectedDonorId);
    if (!donor) return;

    const newApp: Appointment = {
      id: Date.now(),
      donorId: donor.id,
      donorName: `${donor.firstName} ${donor.lastName}`,
      donorNumber: donor.donorNumber,
      bloodGroup: donor.bloodGroup,
      phone: donor.phone,
      centerName,
      appointmentDate: appDate,
      appointmentTime: appTime,
      status: 'Scheduled',
      reminderSent: false,
      notes
    };

    setAppointments([newApp, ...appointments]);
    StorageService.logAudit('Appointment Scheduled', 'Appointments', donor.donorNumber, `Scheduled slot on ${appDate} at ${appTime}`);
    setShowAddModal(false);
    setSuccessMessage(`Appointment scheduled for ${donor.firstName} ${donor.lastName}.`);
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  const sendReminder = (app: Appointment, method: 'SMS' | 'Email') => {
    app.reminderSent = true;
    setAppointments([...appointments]);
    StorageService.logAudit('Donor Reminder Dispatched', 'Notifications', app.donorNumber, `Dispatched ${method} reminder for slot on ${app.appointmentDate} to ${app.phone}`);
    setSuccessMessage(`Automated ${method} appointment reminder sent to ${app.donorName} (${app.phone}): "Reminder: Your blood donation appointment is confirmed for ${app.appointmentDate} at ${app.appointmentTime}. Thank you for saving lives."`);
    setTimeout(() => setSuccessMessage(''), 6000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Donor Relations</span>
            <span aria-hidden="true">·</span>
            <span>Appointment Scheduling</span>
            <span aria-hidden="true">·</span>
            <span>Automated SMS & Email Reminders</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Appointments & Donor Notifications
          </h1>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Book Donor Appointment</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Appointments List */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-900">Upcoming Donor Schedule</span>
          <span className="text-xs text-slate-500 font-mono">{appointments.length} Bookings</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Donor Name</th>
                <th className="py-3 px-4">ABO/Rh</th>
                <th className="py-3 px-4">Phone</th>
                <th className="py-3 px-4">Donation Center</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Reminder</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {appointments.map(app => (
                <tr key={app.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-mono font-medium text-slate-900">
                    {app.appointmentDate} <span className="text-slate-500">at {app.appointmentTime}</span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-900">{app.donorName}</td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{app.bloodGroup}</td>
                  <td className="py-3 px-4 font-mono text-slate-600">{app.phone}</td>
                  <td className="py-3 px-4 text-slate-600 truncate max-w-xs">{app.centerName}</td>
                  <td className="py-3 px-4">
                    <span className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800">
                      {app.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {app.reminderSent ? (
                      <span className="text-emerald-700 font-medium text-[11px] flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Sent
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">Not Sent</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right space-x-1.5 font-sans">
                    <button
                      onClick={() => sendReminder(app, 'SMS')}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-red-800 border border-slate-200 hover:bg-slate-50 rounded cursor-pointer"
                    >
                      Send SMS
                    </button>
                    <button
                      onClick={() => sendReminder(app, 'Email')}
                      className="px-2 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
                    >
                      Send Email
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Book Appointment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900">Schedule Donor Appointment</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddAppointment} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Select Donor *</label>
                <select
                  value={selectedDonorId}
                  onChange={(e) => setSelectedDonorId(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white cursor-pointer font-medium"
                >
                  {donors.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.donorNumber} — {d.firstName} {d.lastName} ({d.bloodGroup})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Appointment Date *</label>
                  <input
                    type="date"
                    required
                    value={appDate}
                    onChange={(e) => setAppDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Time Slot *</label>
                  <input
                    type="text"
                    required
                    value={appTime}
                    onChange={(e) => setAppTime(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md"
                    placeholder="e.g. 10:00 AM"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Donation Center *</label>
                <select
                  value={centerName}
                  onChange={(e) => setCenterName(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-md bg-white cursor-pointer"
                >
                  <option value="Metropolitan Blood Transfusion Center (CTR-HQ)">Metropolitan Center (CTR-HQ)</option>
                  <option value="Northside Community Donor Clinic (CTR-NORTH)">Northside Clinic (CTR-NORTH)</option>
                  <option value="University Teaching Hospital Blood Hub (CTR-EAST)">University Hub (CTR-EAST)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Booking Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  placeholder="e.g. Apheresis platelet donor"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 font-semibold text-slate-600 bg-white border border-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
