import React, { useState } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  ShieldCheck, 
  Download, 
  Lock 
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { AuditLogEntry } from '../../types';

export const AuditLogsView: React.FC = () => {
  const [logs] = useState<AuditLogEntry[]>(StorageService.getAuditLogs());
  const [search, setSearch] = useState('');
  const [selectedModule, setSelectedModule] = useState('all');

  const modules = Array.from(new Set(logs.map(l => l.module)));

  const filtered = logs.filter(l => {
    const matchesSearch = 
      l.action.toLowerCase().includes(search.toLowerCase()) ||
      l.details.toLowerCase().includes(search.toLowerCase()) ||
      l.userName.toLowerCase().includes(search.toLowerCase()) ||
      l.entityId.toLowerCase().includes(search.toLowerCase());

    const matchesMod = selectedModule === 'all' || l.module === selectedModule;
    return matchesSearch && matchesMod;
  });

  const exportAuditCSV = () => {
    const headers = ['ID', 'Timestamp', 'Staff User', 'Role', 'Action', 'Module', 'Entity Reference', 'IP Address', 'Details'];
    const rows = filtered.map(l => [
      l.id,
      `"${l.timestamp}"`,
      `"${l.userName}"`,
      l.userRole,
      `"${l.action}"`,
      l.module,
      `"${l.entityId}"`,
      l.ipAddress,
      `"${l.details.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LifeBlood_Audit_Trail_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Regulatory Governance</span>
            <span aria-hidden="true">·</span>
            <span>Immutable Audit Trail</span>
            <span aria-hidden="true">·</span>
            <span>Tamper-Resistant Security Logging</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            System Activity & Clinical Audit Trail
          </h1>
        </div>

        <button
          onClick={exportAuditCSV}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Download className="w-4 h-4 text-slate-500" />
          <span>Export Audit Log (CSV)</span>
        </button>
      </div>

      {/* Security notice */}
      <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-start gap-2.5">
        <Lock className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
        <div>
          <strong>Compliance Invariant:</strong> The audit trail records every state-changing transaction in the system including user authentications, blood releases, stock discards, recalls, and role modifications. Audit entries are immutable and retained for 10 years per clinical blood banking regulations.
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 border border-slate-200 rounded-lg shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search audit trail by user, action, unit ID, or details..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-red-800"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 whitespace-nowrap">Module:</span>
          <select
            value={selectedModule}
            onChange={(e) => setSelectedModule(e.target.value)}
            className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white cursor-pointer"
          >
            <option value="all">All Modules</option>
            {modules.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium font-sans">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Staff User</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Module</th>
                <th className="py-3 px-4">Entity ID</th>
                <th className="py-3 px-4 font-sans">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(l => (
                <tr key={l.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 text-slate-500 text-[11px] whitespace-nowrap">{l.timestamp}</td>
                  <td className="py-3 px-4 font-bold text-slate-900 font-sans">{l.userName}</td>
                  <td className="py-3 px-4 text-slate-600 font-sans text-[11px]">{l.userRole}</td>
                  <td className="py-3 px-4 font-semibold text-red-900 font-sans">{l.action}</td>
                  <td className="py-3 px-4 text-slate-600 font-sans">{l.module}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{l.entityId}</td>
                  <td className="py-3 px-4 text-slate-700 font-sans text-xs">{l.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
