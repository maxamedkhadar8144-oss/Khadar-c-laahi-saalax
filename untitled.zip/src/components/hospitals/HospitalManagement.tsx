import React, { useState } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Phone, 
  Mail, 
  MapPin, 
  FileCheck, 
  CheckCircle2, 
  X,
  Activity
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { Hospital } from '../../types';

export const HospitalManagement: React.FC = () => {
  const [hospitals, setHospitals] = useState<Hospital[]>(StorageService.getHospitals());
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const [name, setName] = useState('');
  const [facilityType, setFacilityType] = useState<any>('Tertiary Hospital');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Capital City');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [contactPhone, setContactPhone] = useState('');

  const filtered = hospitals.filter(h => 
    h.name.toLowerCase().includes(search.toLowerCase()) ||
    h.city.toLowerCase().includes(search.toLowerCase()) ||
    h.hospitalCode.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddHospital = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = hospitals.length > 0 ? Math.max(...hospitals.map(h => h.id)) + 1 : 1;
    const newHospital: Hospital = {
      id: newId,
      hospitalCode: `HOSP-00${newId}`,
      name,
      facilityType,
      address,
      city,
      phone,
      email,
      licenseNumber,
      contactPerson,
      contactPhone,
      isActive: true
    };

    const updated = [...hospitals, newHospital];
    setHospitals(updated);
    localStorage.setItem('lifeblood_hospitals', JSON.stringify(updated));
    StorageService.logAudit('Hospital Registered', 'Hospitals', newHospital.hospitalCode, `Registered ${newHospital.name}`);
    setShowAddModal(false);
    setSuccessMessage(`Hospital ${newHospital.name} added successfully.`);
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Distribution Network</span>
            <span aria-hidden="true">·</span>
            <span>Accredited Medical Facilities</span>
            <span aria-hidden="true">·</span>
            <span>{hospitals.length} Licensed Hospitals</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Hospital & Medical Facility Management
          </h1>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Facility</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Search */}
      <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-xs max-w-md relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search by facility name, city, or hospital code..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-red-800"
        />
      </div>

      {/* Hospital Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(h => (
          <div key={h.id} className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-slate-400 font-semibold">{h.hospitalCode}</span>
                <h3 className="text-base font-bold text-slate-900">{h.name}</h3>
                <span className="text-xs text-red-900 font-medium">{h.facilityType}</span>
              </div>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                Active License
              </span>
            </div>

            <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{h.address}, {h.city}</span>
              </div>
              <div className="flex items-center gap-2 font-mono">
                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{h.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{h.email}</span>
              </div>
              <div className="pt-2 text-[11px] text-slate-500 flex justify-between">
                <span>License: <strong className="font-mono text-slate-700">{h.licenseNumber}</strong></span>
                <span>Contact: <strong className="text-slate-800">{h.contactPerson}</strong></span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Hospital Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-lg p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900">Register Medical Facility</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddHospital} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Hospital / Clinic Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  placeholder="e.g. City Trauma Center"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Facility Type *</label>
                  <select
                    value={facilityType}
                    onChange={(e) => setFacilityType(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded-md bg-white cursor-pointer"
                  >
                    <option value="Tertiary Hospital">Tertiary Hospital</option>
                    <option value="Regional Referral Hospital">Regional Referral Hospital</option>
                    <option value="Specialized Trauma Center">Specialized Trauma Center</option>
                    <option value="Maternity Hospital">Maternity Hospital</option>
                    <option value="Private Clinic">Private Clinic</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Accredited License # *</label>
                  <input
                    type="text"
                    required
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                    placeholder="e.g. LIC-MED-2026-09"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Dispatch Phone *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                    placeholder="+1-555-000-0000"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Order Requisition Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md"
                    placeholder="orders@hospital.org"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Chief Transfusion Contact Person *</label>
                  <input
                    type="text"
                    required
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md"
                    placeholder="Dr. Evelyn Vance"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Contact Direct Phone *</label>
                  <input
                    type="tel"
                    required
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Physical Address *</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  placeholder="Street and building number"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 font-semibold text-slate-600 bg-white border border-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Save Facility
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
