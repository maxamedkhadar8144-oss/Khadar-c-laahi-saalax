import React from 'react';
import {
  LayoutDashboard,
  Users,
  Droplet,
  Grid,
  Layers,
  PackageCheck,
  Microscope,
  ClipboardList,
  Building2,
  Truck,
  AlertTriangle,
  Calendar,
  BarChart3,
  ShieldCheck,
  History,
  Settings,
  FileCode2,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { User, RoleSlug } from '../../types';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  currentUser: User;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: RoleSlug[]; // If specified, role must match
  badge?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  currentUser,
  collapsed,
  onToggleCollapse
}) => {
  const navItems: { section: string; items: NavItem[] }[] = [
    {
      section: 'CLINICAL OPERATIONS',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'donors', label: 'Donor Management', icon: Users },
        { id: 'donations', label: 'Blood Donation', icon: Droplet },
        { id: 'blood-groups', label: 'Blood Groups & ABO', icon: Grid },
        { id: 'components', label: 'Component Fractionation', icon: Layers },
        { id: 'inventory', label: 'Stock & FEFO Inventory', icon: PackageCheck },
        { id: 'laboratory', label: 'Laboratory Release', icon: Microscope },
      ]
    },
    {
      section: 'DISTRIBUTION & TRANSFUSION',
      items: [
        { id: 'requests', label: 'Hospital Requests', icon: ClipboardList },
        { id: 'hospitals', label: 'Hospital Facilities', icon: Building2 },
        { id: 'issues', label: 'Blood Issue & Slips', icon: Truck },
        { id: 'alerts', label: 'Safety & Recall Alerts', icon: AlertTriangle },
        { id: 'appointments', label: 'Appointments & SMS', icon: Calendar },
      ]
    },
    {
      section: 'GOVERNANCE & AUDIT',
      items: [
        { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
        { id: 'users', label: 'Staff & RBAC Roles', icon: ShieldCheck },
        { id: 'audit', label: 'Audit Trail Logs', icon: History },
        { id: 'settings', label: 'System Settings', icon: Settings },
        { id: 'code-export', label: 'XAMPP PHP & Schema', icon: FileCode2 },
      ]
    }
  ];

  return (
    <aside 
      className={`sidebar-container shrink-0 bg-white border-r border-slate-200 transition-all duration-200 flex flex-col justify-between ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      <div className="py-4 overflow-y-auto">
        {navItems.map((group, gIdx) => (
          <div key={gIdx} className="mb-6">
            {!collapsed && (
              <div className="px-5 mb-2 text-[10px] font-semibold text-slate-400 tracking-wider">
                {group.section}
              </div>
            )}
            <div className="space-y-0.5 px-2">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer text-left ${
                      isActive 
                        ? 'bg-red-50 text-red-900 font-semibold' 
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-red-800' : 'text-slate-400'}`} />
                    {!collapsed && (
                      <span className="truncate whitespace-nowrap">{item.label}</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Collapse Toggle Footer */}
      <div className="p-3 border-t border-slate-200 flex items-center justify-between">
        {!collapsed && (
          <div className="text-[11px] text-slate-400 truncate">
            LifeBlood BBMS v2.4
          </div>
        )}
        <button
          onClick={onToggleCollapse}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer ml-auto"
          title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>
    </aside>
  );
};
