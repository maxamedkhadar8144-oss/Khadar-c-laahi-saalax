import React, { useState } from 'react';
import { 
  Bell, 
  User as UserIcon, 
  ChevronDown, 
  Activity, 
  Globe, 
  ShieldAlert, 
  LogOut,
  RefreshCw,
  FileCode2,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { User, RoleSlug } from '../../types';
import { StorageService } from '../../services/storage';

interface NavbarProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  onNavigate: (view: string) => void;
  activeView: string;
  isArabic: boolean;
  onToggleArabic: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onUserChange,
  onNavigate,
  activeView,
  isArabic,
  onToggleArabic
}) => {
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);

  const users = StorageService.getUsers();
  const requests = StorageService.getBloodRequests();
  const units = StorageService.getBloodUnits();

  // Pending urgent/emergency requests
  const urgentRequests = requests.filter(r => (r.priority === 'Emergency' || r.priority === 'Urgent') && r.status !== 'Fulfilled');
  
  // Units expiring within 7 days
  const now = new Date();
  const sevenDaysLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const expiringUnits = units.filter(u => {
    if (u.status !== 'Released' && u.status !== 'Reserved') return false;
    const exp = new Date(u.expiryDate);
    return exp > now && exp <= sevenDaysLater;
  });

  const notificationCount = urgentRequests.length + expiringUnits.length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* Strict 3-Zone Top Bar Contract: Brand - Nav Links - Primary Actions */}
      <div className="flex items-center justify-between gap-8 px-6 py-3.5 max-w-[1600px] mx-auto">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-red-800 text-white flex items-center justify-center font-bold text-base shadow-sm">
            <Activity className="w-5 h-5 text-red-100" />
          </div>
          <button 
            onClick={() => onNavigate('dashboard')} 
            className="text-left cursor-pointer focus-visible:outline-none"
          >
            <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
              LifeBlood <span className="font-normal text-slate-500 text-sm">· Transfusion Service</span>
            </span>
          </button>
        </div>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 ${
              activeView === 'dashboard' 
                ? 'text-red-800 font-semibold border-b-2 border-red-800' 
                : 'hover:text-slate-900'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onNavigate('inventory')}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 ${
              activeView === 'inventory' 
                ? 'text-red-800 font-semibold border-b-2 border-red-800' 
                : 'hover:text-slate-900'
            }`}
          >
            Inventory & FEFO
          </button>
          <button
            onClick={() => onNavigate('requests')}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 ${
              activeView === 'requests' 
                ? 'text-red-800 font-semibold border-b-2 border-red-800' 
                : 'hover:text-slate-900'
            }`}
          >
            Hospital Requests
          </button>
          <button
            onClick={() => onNavigate('laboratory')}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 ${
              activeView === 'laboratory' 
                ? 'text-red-800 font-semibold border-b-2 border-red-800' 
                : 'hover:text-slate-900'
            }`}
          >
            Laboratory Release
          </button>
          <button
            onClick={() => onNavigate('code-export')}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-0.5 flex items-center gap-1.5 ${
              activeView === 'code-export' 
                ? 'text-red-800 font-semibold border-b-2 border-red-800' 
                : 'hover:text-slate-900 text-slate-700'
            }`}
          >
            <FileCode2 className="w-4 h-4 text-red-800" />
            <span>XAMPP PHP & Schema</span>
          </button>
        </nav>

        {/* Zone 3: Functional Utilities & Profile Menu */}
        <div className="flex items-center gap-3 shrink-0">
          
          {/* Language Selector */}
          <button
            onClick={onToggleArabic}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            title="Toggle Arabic / RTL Layout"
          >
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span>{isArabic ? 'English (LTR)' : 'العربية (RTL)'}</span>
          </button>

          {/* Clinical Alerts / Notification Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifDropdown(!showNotifDropdown)}
              className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
              title="Clinical Alerts & Requests"
            >
              <Bell className="w-4 h-4" />
              {notificationCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full" />
              )}
            </button>

            {showNotifDropdown && (
              <div className="absolute right-0 mt-2 w-80 bg-white border border-slate-200 rounded-lg shadow-lg py-2 z-50">
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-900 uppercase tracking-wider">Clinical Alerts</span>
                  <span className="text-xs text-slate-500">{notificationCount} Active</span>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {urgentRequests.map(req => (
                    <div 
                      key={req.id} 
                      onClick={() => { onNavigate('requests'); setShowNotifDropdown(false); }}
                      className="px-4 py-2.5 hover:bg-slate-50 cursor-pointer text-xs"
                    >
                      <div className="flex items-center justify-between text-red-700 font-semibold mb-0.5">
                        <span className="flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {req.priority} Request
                        </span>
                        <span className="font-mono text-slate-500">{req.requestNumber}</span>
                      </div>
                      <div className="text-slate-800 font-medium">{req.hospitalName}</div>
                      <div className="text-slate-500 text-[11px]">{req.unitsRequested} units {req.patientBloodGroup} {req.componentCode}</div>
                    </div>
                  ))}

                  {expiringUnits.map(unit => (
                    <div 
                      key={unit.id} 
                      onClick={() => { onNavigate('inventory'); setShowNotifDropdown(false); }}
                      className="px-4 py-2.5 hover:bg-slate-50 cursor-pointer text-xs"
                    >
                      <div className="flex items-center justify-between text-amber-700 font-semibold mb-0.5">
                        <span>Expiring Soon</span>
                        <span className="font-mono text-slate-500">{unit.unitBarcode}</span>
                      </div>
                      <div className="text-slate-800">{unit.bloodGroup} {unit.componentName}</div>
                      <div className="text-slate-500 text-[11px]">Expires: {unit.expiryDate.split('T')[0]}</div>
                    </div>
                  ))}

                  {notificationCount === 0 && (
                    <div className="px-4 py-6 text-center text-xs text-slate-500">
                      No active critical alerts or urgent requests.
                    </div>
                  )}
                </div>
                <div className="px-4 py-2 border-t border-slate-100 text-center">
                  <button
                    onClick={() => { onNavigate('alerts'); setShowNotifDropdown(false); }}
                    className="text-xs text-red-800 font-medium hover:underline cursor-pointer"
                  >
                    View All Safety Alerts
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick RBAC Role Switcher & User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center gap-2.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors cursor-pointer text-left"
            >
              <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold overflow-hidden border border-slate-200 shrink-0">
                {currentUser.avatarUrl ? (
                  <img src={currentUser.avatarUrl} alt={currentUser.name} className="w-full h-full object-cover" />
                ) : (
                  <span>{currentUser.name.charAt(0)}</span>
                )}
              </div>
              <div className="hidden sm:block">
                <div className="text-xs font-semibold text-slate-900 leading-tight">
                  {currentUser.name}
                </div>
                <div className="text-[11px] text-slate-500 font-medium">
                  {currentUser.roleName}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showRoleDropdown && (
              <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-lg shadow-lg py-2 z-50">
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-900">Switch RBAC Role</div>
                    <div className="text-[11px] text-slate-500">Test permissions for any of the 7 roles:</div>
                  </div>
                </div>

                <div className="max-h-60 overflow-y-auto py-1">
                  {users.map(u => (
                    <button
                      key={u.id}
                      onClick={() => {
                        StorageService.setCurrentUser(u);
                        onUserChange(u);
                        setShowRoleDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer ${
                        u.id === currentUser.id ? 'bg-red-50 text-red-900 font-medium' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-6 h-6 rounded-full overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center font-bold text-[10px] text-slate-700 shrink-0">
                          {u.avatarUrl ? (
                            <img src={u.avatarUrl} alt={u.name} className="w-full h-full object-cover" />
                          ) : (
                            <span>{u.name.charAt(0)}</span>
                          )}
                        </div>
                        <div>
                          <div className="font-semibold">{u.name}</div>
                          <div className="text-[11px] text-slate-500">{u.roleName}</div>
                        </div>
                      </div>
                      {u.id === currentUser.id && (
                        <CheckCircle2 className="w-4 h-4 text-red-800 shrink-0" />
                      )}
                    </button>
                  ))}
                </div>

                <div className="border-t border-slate-100 mt-1 pt-1 px-4 py-1.5 flex justify-between items-center text-xs text-slate-500">
                  <span className="font-mono text-[10px]">{currentUser.staffId}</span>
                  <button
                    onClick={() => {
                      if (confirm('Reset application data back to initial seed dataset?')) {
                        StorageService.resetToFactoryDefaults();
                        window.location.reload();
                      }
                    }}
                    className="flex items-center gap-1 text-red-800 hover:underline cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Reset Data
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};
