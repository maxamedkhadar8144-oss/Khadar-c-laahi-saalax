import React, { useState } from 'react';
import { 
  Truck, 
  Plus, 
  Printer, 
  Thermometer, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  RotateCcw, 
  Barcode, 
  ShieldCheck, 
  Clock 
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { BloodIssue, BloodRequest, BloodUnit, User } from '../../types';

interface BloodIssueViewProps {
  currentUser: User;
}

export const BloodIssueView: React.FC<BloodIssueViewProps> = ({ currentUser }) => {
  const [issues, setIssues] = useState<BloodIssue[]>(() => {
    try {
      const data = localStorage.getItem('lifeblood_issues');
      return data ? JSON.parse(data) : [
        {
          id: 1,
          issueSlipNumber: 'ISS-2026-00918',
          requestId: 3,
          requestNumber: 'REQ-2026-00443',
          unitId: 108,
          unitBarcode: 'DIN-2026-08825',
          componentCode: 'PRBC',
          bloodGroup: 'O+',
          hospitalName: 'Northwood Maternal & Pediatric Center',
          receivingOfficer: 'Nurse Supervisor Aisha Noor',
          receivingOfficerId: 'STAFF-HOSP-992',
          transportTempCelsius: 3.8,
          transportBoxId: 'COLD-BOX-04',
          issuedBy: 'Khadar Jama',
          issuedAt: '2026-10-20 16:45:00'
        }
      ];
    } catch {
      return [];
    }
  });

  const [units] = useState<BloodUnit[]>(StorageService.getBloodUnits());
  const [requests] = useState<BloodRequest[]>(StorageService.getBloodRequests());

  const [showIssueModal, setShowIssueModal] = useState(false);
  const [printableSlip, setPrintableSlip] = useState<BloodIssue | null>(null);
  const [showReturnModal, setShowReturnModal] = useState(false);

  const [selectedRequestId, setSelectedRequestId] = useState<number>(requests[0]?.id || 1);
  const [selectedUnitBarcode, setSelectedUnitBarcode] = useState<string>('');
  const [receivingOfficerName, setReceivingOfficerName] = useState('');
  const [receivingOfficerId, setReceivingOfficerId] = useState('');
  const [transportTemp, setTransportTemp] = useState<string>('4.0');
  const [transportBoxId, setTransportBoxId] = useState('COLD-BOX-02');

  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Eligible units for issue: Either 'Released' or 'Reserved'
  const eligibleUnits = units.filter(u => u.status === 'Released' || u.status === 'Reserved');

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!selectedUnitBarcode || !receivingOfficerName || !receivingOfficerId) {
      setErrorMessage('Please fill in receiving clinician credentials and select a blood unit.');
      return;
    }

    const res = StorageService.issueBloodUnit({
      requestId: selectedRequestId,
      unitBarcode: selectedUnitBarcode,
      receivingOfficerName,
      receivingOfficerId,
      transportTempCelsius: parseFloat(transportTemp),
      transportBoxId
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Issue transaction failed.');
      return;
    }

    // Refresh issues list
    const updated = JSON.parse(localStorage.getItem('lifeblood_issues') || '[]');
    setIssues(updated);
    setPrintableSlip(res.issueSlip || null);
    setShowIssueModal(false);
    setSuccessMessage(`Blood unit ${selectedUnitBarcode} issued successfully. Issue Slip: ${res.issueSlip?.issueSlipNumber}`);
    setTimeout(() => setSuccessMessage(''), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Distribution & Hospital Service</span>
            <span aria-hidden="true">·</span>
            <span>Blood Issue & Delivery</span>
            <span aria-hidden="true">·</span>
            <span>Cold-Chain Custody Verification</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Blood Unit Issue & Transfusion Custody Slips
          </h1>
        </div>

        <button
          onClick={() => setShowIssueModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Issue Blood to Hospital</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Issues Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-900">Dispatched Delivery & Issue History</span>
          <span className="text-xs text-slate-500 font-mono">{issues.length} Dispatches</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Issue Slip</th>
                <th className="py-3 px-4">Requisition No.</th>
                <th className="py-3 px-4">Unit Barcode</th>
                <th className="py-3 px-4">ABO/Rh</th>
                <th className="py-3 px-4">Component</th>
                <th className="py-3 px-4">Receiving Hospital</th>
                <th className="py-3 px-4">Transport Temp</th>
                <th className="py-3 px-4">Dispatched At</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {issues.map(iss => (
                <tr key={iss.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-bold text-slate-900">{iss.issueSlipNumber}</td>
                  <td className="py-3 px-4 text-slate-600">{iss.requestNumber}</td>
                  <td className="py-3 px-4 text-red-900 font-bold">{iss.unitBarcode}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">{iss.bloodGroup}</td>
                  <td className="py-3 px-4 font-sans text-slate-700">{iss.componentCode}</td>
                  <td className="py-3 px-4 font-sans text-slate-800 font-medium truncate max-w-xs">{iss.hospitalName}</td>
                  <td className="py-3 px-4 font-sans">
                    <span className="inline-flex items-center gap-1 font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                      <Thermometer className="w-3 h-3" />
                      {iss.transportTempCelsius}°C
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-600">{iss.issuedAt.replace('T', ' ').substring(0, 16)}</td>
                  <td className="py-3 px-4 text-right font-sans">
                    <button
                      onClick={() => setPrintableSlip(iss)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-red-800 border border-slate-200 hover:bg-slate-50 rounded cursor-pointer"
                    >
                      Print Slip
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Controlled Issue Modal */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Issue Blood Unit to Hospital</h3>
                <div className="text-xs text-slate-500">Record cold chain temperature and authorized receiving clinician</div>
              </div>
              <button 
                onClick={() => setShowIssueModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleIssueSubmit} className="p-6 space-y-4 text-xs">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Associated Request */}
              <div>
                <label className="block font-medium text-slate-700 mb-1">Select Blood Requisition *</label>
                <select
                  value={selectedRequestId}
                  onChange={(e) => setSelectedRequestId(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white cursor-pointer font-medium"
                >
                  {requests.filter(r => r.status !== 'Fulfilled' && r.status !== 'Rejected').map(r => (
                    <option key={r.id} value={r.id}>
                      {r.requestNumber} — {r.hospitalName} ({r.unitsRequested} units {r.patientBloodGroup} {r.componentCode} - {r.priority})
                    </option>
                  ))}
                </select>
              </div>

              {/* Select Eligible Unit */}
              <div>
                <label className="block font-medium text-slate-700 mb-1">Select Verified Released Unit *</label>
                {eligibleUnits.length === 0 ? (
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-md text-slate-500">
                    No eligible units in Released status. Authorize units in Laboratory first.
                  </div>
                ) : (
                  <select
                    value={selectedUnitBarcode}
                    onChange={(e) => setSelectedUnitBarcode(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white cursor-pointer font-mono font-bold"
                  >
                    <option value="">-- Choose Unit to Issue --</option>
                    {eligibleUnits.map(u => (
                      <option key={u.unitBarcode} value={u.unitBarcode}>
                        {u.unitBarcode} · {u.bloodGroup} · {u.componentCode} ({u.volumeMl}ml) · Exp: {u.expiryDate.split('T')[0]} · Status: {u.status}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Cold Chain Verification */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                  <Thermometer className="w-4 h-4 text-red-700" />
                  <span>Cold Chain Transport Verification</span>
                </span>
                
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Measured Transport Temp (°C) *</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      value={transportTemp}
                      onChange={(e) => setTransportTemp(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Insulated Container / Box ID *</label>
                    <input
                      type="text"
                      required
                      value={transportBoxId}
                      onChange={(e) => setTransportBoxId(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Receiving Clinician Credentials */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Receiving Clinician Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Marcus Sterling"
                    value={receivingOfficerName}
                    onChange={(e) => setReceivingOfficerName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Staff / Medical License ID *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MD-LIC-9921"
                    value={receivingOfficerId}
                    onChange={(e) => setReceivingOfficerId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={eligibleUnits.length === 0}
                  className="px-4 py-2 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs disabled:opacity-50"
                >
                  Confirm Issue & Generate Delivery Receipt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Delivery & Issue Slip Modal */}
      {printableSlip && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 bg-slate-50 no-print">
              <span className="text-xs font-semibold text-slate-900">Official Blood Delivery Receipt</span>
              <button 
                onClick={() => setPrintableSlip(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 printable-area bg-white space-y-4 text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-300">
                <div>
                  <div className="text-base font-bold text-slate-900">LifeBlood National Transfusion Service</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">Clinical Transfusion Issue Slip & Transport Custody</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-900">{printableSlip.issueSlipNumber}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{printableSlip.issuedAt.split('T')[0]}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-md font-mono text-[11px]">
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Receiving Facility</span>
                  <span className="font-bold text-slate-900">{printableSlip.hospitalName}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Requisition Reference</span>
                  <span className="font-bold text-slate-900">{printableSlip.requestNumber}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Unit Barcode</span>
                  <span className="font-bold text-red-900">{printableSlip.unitBarcode}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">ABO/Rh & Component</span>
                  <span className="font-bold text-slate-900">{printableSlip.bloodGroup} · {printableSlip.componentCode}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Transport Temp</span>
                  <span className="font-bold text-emerald-800">{printableSlip.transportTempCelsius}°C ({printableSlip.transportBoxId})</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Receiving Officer</span>
                  <span className="font-bold text-slate-800">{printableSlip.receivingOfficer} ({printableSlip.receivingOfficerId})</span>
                </div>
              </div>

              <div className="pt-6 grid grid-cols-2 gap-6 text-[10px] text-slate-500 border-t border-slate-200">
                <div>
                  <div className="border-b border-slate-300 pb-8 mb-1"></div>
                  <div>Issuing Technologist Signature</div>
                  <div className="font-mono text-slate-700">{printableSlip.issuedBy}</div>
                </div>
                <div>
                  <div className="border-b border-slate-300 pb-8 mb-1"></div>
                  <div>Receiving Clinician Signature</div>
                  <div className="font-mono text-slate-700">{printableSlip.receivingOfficer}</div>
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3 no-print">
              <button
                onClick={() => setPrintableSlip(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-md cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Delivery Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
