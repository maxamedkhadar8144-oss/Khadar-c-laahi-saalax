import React, { useState } from 'react';
import { 
  Droplet, 
  Plus, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Clock, 
  X, 
  Barcode, 
  Activity,
  HeartPulse
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { Donor, BloodUnit, User } from '../../types';

interface DonationManagementProps {
  currentUser: User;
}

export const DonationManagement: React.FC<DonationManagementProps> = ({ currentUser }) => {
  const [units, setUnits] = useState<BloodUnit[]>(StorageService.getBloodUnits());
  const [donors, setDonors] = useState<Donor[]>(StorageService.getDonors());
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Donation form state
  const [selectedDonorId, setSelectedDonorId] = useState<number>(donors[0]?.id || 1);
  const [collectionType, setCollectionType] = useState<'Whole Blood' | 'Apheresis Platelets' | 'Apheresis Plasma'>('Whole Blood');
  const [volumeMl, setVolumeMl] = useState<number>(450);
  const [centerName, setCenterName] = useState('Metropolitan Blood Transfusion Center (CTR-HQ)');
  const [anticoagulantBatch, setAnticoagulantBatch] = useState('CPDA-1-LOT-9821');
  const [hasReaction, setHasReaction] = useState(false);
  const [reactionNotes, setReactionNotes] = useState('');

  // Pre-donation screening fields
  const [hemoglobin, setHemoglobin] = useState('14.2');
  const [systolicBp, setSystolicBp] = useState('120');
  const [diastolicBp, setDiastolicBp] = useState('80');
  const [pulse, setPulse] = useState('72');
  const [weightKg, setWeightKg] = useState('70');

  const selectedDonor = donors.find(d => d.id === selectedDonorId);

  const handleSubmitDonation = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (parseFloat(hemoglobin) < 12.5) {
      setErrorMessage('Screening Failure: Hemoglobin level must be at least 12.5 g/dL for safe clinical blood donation.');
      return;
    }

    if (parseFloat(weightKg) < 50.0) {
      setErrorMessage('Screening Failure: Donor weight must be at least 50 kg.');
      return;
    }

    const res = StorageService.recordDonation({
      donorId: selectedDonorId,
      collectionType,
      volumeMl,
      bagBarcode: `BAG-LOT-${Math.floor(100000 + Math.random() * 900000)}`,
      anticoagulantBatch,
      centerName,
      hasReaction,
      reactionNotes: hasReaction ? reactionNotes : undefined
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Failed to record donation.');
      return;
    }

    setUnits(StorageService.getBloodUnits());
    setDonors(StorageService.getDonors());
    setSuccessMessage(`Donation successfully recorded: Unit ${res.unit?.unitBarcode} placed in QUARANTINE.`);
    setShowDonationModal(false);
    setTimeout(() => setSuccessMessage(''), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>Blood Donation Intake</span>
            <span aria-hidden="true">·</span>
            <span>Strict Quarantine Intake Protocol</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Blood Donation & Intake Management
          </h1>
        </div>

        <button
          onClick={() => setShowDonationModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Record New Donation</span>
        </button>
      </div>

      {/* Safety Notice */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Mandatory Quarantine Protocol:</span> All newly collected blood units immediately receive a unique donation barcode and enter the inventory as <span className="font-semibold underline">QUARANTINED</span>. Under international transfusion regulations, no unit can be released to available stock until ABO/Rh confirmatory typing, antibody screening, and fourfold infectious disease testing (HIV, Hepatitis B, Hepatitis C, Syphilis) are complete.
        </div>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Recent Collections Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="text-sm font-semibold text-slate-900">Recent Blood Collections & Intake Register</div>
          <div className="text-xs text-slate-500 font-mono">{units.length} Total Units</div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Unit Barcode</th>
                <th className="py-3 px-4">Donation No.</th>
                <th className="py-3 px-4">ABO / Rh</th>
                <th className="py-3 px-4">Component</th>
                <th className="py-3 px-4">Volume</th>
                <th className="py-3 px-4">Collected Date</th>
                <th className="py-3 px-4">Storage Location</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {units.map(unit => (
                <tr key={unit.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                    <Barcode className="w-4 h-4 text-slate-400" />
                    <span>{unit.unitBarcode}</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">{unit.donationNumber}</td>
                  <td className="py-3 px-4 font-bold text-slate-900 font-mono">{unit.bloodGroup}</td>
                  <td className="py-3 px-4 font-medium text-slate-800">{unit.componentName}</td>
                  <td className="py-3 px-4 font-mono tabular-nums">{unit.volumeMl} ml</td>
                  <td className="py-3 px-4 text-slate-600">{unit.collectionDate.replace('T', ' ').substring(0, 16)}</td>
                  <td className="py-3 px-4 text-slate-600 truncate max-w-xs">{unit.storageLocation}</td>
                  <td className="py-3 px-4 text-right">
                    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                      unit.status === 'Released' ? 'bg-emerald-50 text-emerald-800' :
                      unit.status === 'Quarantined' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                      unit.status === 'Reserved' ? 'bg-blue-50 text-blue-800' :
                      unit.status === 'Issued' ? 'bg-slate-100 text-slate-800' :
                      'bg-red-50 text-red-800'
                    }`}>
                      {unit.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Donation Modal */}
      {showDonationModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Record Clinical Blood Donation</h3>
                <div className="text-xs text-slate-500">Collect sample, perform vitals pre-screening, and assign barcode</div>
              </div>
              <button 
                onClick={() => setShowDonationModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitDonation} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Donor Selector */}
              <div>
                <label className="block font-medium text-slate-700 mb-1">Select Registered Donor *</label>
                <select
                  value={selectedDonorId}
                  onChange={(e) => setSelectedDonorId(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none bg-white cursor-pointer font-medium"
                >
                  {donors.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.donorNumber} — {d.firstName} {d.lastName} ({d.bloodGroup}) {d.status.includes('Deferred') ? `[DEFERRED: ${d.status}]` : ''}
                    </option>
                  ))}
                </select>
                {selectedDonor && (
                  <div className="mt-1 text-[11px] text-slate-500 flex items-center gap-3">
                    <span>Blood Group: <strong className="text-red-900">{selectedDonor.bloodGroup}</strong></span>
                    <span>Total Donations: <strong>{selectedDonor.totalDonations}</strong></span>
                    <span>Last Donated: {selectedDonor.lastDonationDate || 'None'}</span>
                  </div>
                )}
              </div>

              {/* Pre-Donation Clinical Vitals */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <div className="flex items-center gap-2 font-semibold text-slate-800">
                  <HeartPulse className="w-4 h-4 text-red-700" />
                  <span>Pre-Donation Screening & Vitals</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Hemoglobin (g/dL) *</label>
                    <input
                      type="number"
                      step="0.1"
                      min="10"
                      max="20"
                      required
                      value={hemoglobin}
                      onChange={(e) => setHemoglobin(e.target.value)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Weight (kg) *</label>
                    <input
                      type="number"
                      min="40"
                      max="180"
                      required
                      value={weightKg}
                      onChange={(e) => setWeightKg(e.target.value)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Systolic BP *</label>
                    <input
                      type="number"
                      required
                      value={systolicBp}
                      onChange={(e) => setSystolicBp(e.target.value)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Diastolic BP *</label>
                    <input
                      type="number"
                      required
                      value={diastolicBp}
                      onChange={(e) => setDiastolicBp(e.target.value)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Pulse (bpm) *</label>
                    <input
                      type="number"
                      required
                      value={pulse}
                      onChange={(e) => setPulse(e.target.value)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded-md bg-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Collection Parameters */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Collection Type *</label>
                  <select
                    value={collectionType}
                    onChange={(e) => setCollectionType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none bg-white cursor-pointer"
                  >
                    <option value="Whole Blood">Whole Blood (Standard 450ml)</option>
                    <option value="Apheresis Platelets">Apheresis Platelets</option>
                    <option value="Apheresis Plasma">Apheresis Plasma</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Volume Collected (ml) *</label>
                  <input
                    type="number"
                    required
                    value={volumeMl}
                    onChange={(e) => setVolumeMl(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Collection Center *</label>
                  <input
                    type="text"
                    required
                    value={centerName}
                    onChange={(e) => setCenterName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Anticoagulant Bag Batch *</label>
                  <input
                    type="text"
                    required
                    value={anticoagulantBatch}
                    onChange={(e) => setAnticoagulantBatch(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Adverse Reaction Reporting */}
              <div className="border border-slate-200 rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="hasReaction"
                    checked={hasReaction}
                    onChange={(e) => setHasReaction(e.target.checked)}
                    className="rounded text-red-800 focus:ring-red-800 cursor-pointer"
                  />
                  <label htmlFor="hasReaction" className="font-semibold text-slate-800 cursor-pointer">
                    Record Donor Adverse Reaction during / after phlebotomy
                  </label>
                </div>
                {hasReaction && (
                  <div className="mt-2.5">
                    <label className="block text-[11px] text-slate-500 mb-1">Reaction Details & Clinical Management:</label>
                    <textarea
                      value={reactionNotes}
                      onChange={(e) => setReactionNotes(e.target.value)}
                      placeholder="e.g. Mild vasovagal episode, donor rested in Trendelenburg position for 15 mins, juice given, vitals normalized."
                      className="w-full p-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                      rows={2}
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowDonationModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Save & Quarantine Unit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
