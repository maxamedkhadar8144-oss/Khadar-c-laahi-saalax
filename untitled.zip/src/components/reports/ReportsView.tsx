import React, { useState } from 'react';
import { 
  BarChart3, 
  Download, 
  Printer, 
  Calendar, 
  Filter, 
  FileSpreadsheet, 
  CheckCircle2, 
  PieChart 
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { BloodGroup, ComponentCode } from '../../types';

export const ReportsView: React.FC = () => {
  const [selectedReportId, setSelectedReportId] = useState<number>(1);
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('all');
  const [selectedComponent, setSelectedComponent] = useState<string>('all');
  const [dateRange, setDateRange] = useState<'today' | 'month' | 'year' | 'all'>('month');

  const donors = StorageService.getDonors();
  const units = StorageService.getBloodUnits();
  const requests = StorageService.getBloodRequests();
  const hospitals = StorageService.getHospitals();
  const labTests = StorageService.getLabTests();
  const auditLogs = StorageService.getAuditLogs();
  const recalls = StorageService.getRecalls();

  const reportList = [
    { id: 1, title: 'Current Available Stock by Group & Component', category: 'Inventory' },
    { id: 2, title: 'Total Registered Donors by Blood Group', category: 'Donors' },
    { id: 3, title: 'Blood Collections by Center & Volume', category: 'Donations' },
    { id: 4, title: 'Hospital Blood Requisition Fulfillment Rates', category: 'Distribution' },
    { id: 5, title: 'Quarantined & Pending Testing Inventory', category: 'Laboratory' },
    { id: 6, title: 'Expiring & Expired Stock Ledger (FEFO)', category: 'Safety' },
    { id: 7, title: 'Blood Wastage & Discard Reason Analysis', category: 'Governance' },
    { id: 8, title: 'Issued Units by Hospital Destination', category: 'Distribution' },
    { id: 9, title: 'Donor Deferrals & Clinical Reasons', category: 'Donors' },
    { id: 10, title: 'Transfusion-Transmissible Infection Sero-prevalence', category: 'Laboratory' },
    { id: 11, title: 'Emergency vs Routine Order Lead Times', category: 'Distribution' },
    { id: 12, title: 'Product Recall & Quarantine Investigation Log', category: 'Safety' },
    { id: 13, title: 'Component Fractionation Efficiency', category: 'Inventory' },
    { id: 14, title: 'Daily Appointment Show-Rate & Booking Register', category: 'Donors' },
    { id: 15, title: 'Cold-Chain Delivery Temperature Verification Log', category: 'Distribution' },
    { id: 16, title: 'Staff Activity & Regulatory Audit Trail', category: 'Governance' },
  ];

  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const components: ComponentCode[] = ['WB', 'PRBC', 'PLT', 'FFP', 'CRYO'];

  const exportCurrentReportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    const reportMeta = reportList.find(r => r.id === selectedReportId)?.title || 'Report';

    if (selectedReportId === 1) {
      csvContent += 'Blood Group,Component,Available Units,Quarantined,Reserved,Total in System\n';
      bloodGroups.forEach(bg => {
        components.forEach(c => {
          const avail = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Released').length;
          const quar = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Quarantined').length;
          const res = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Reserved').length;
          const total = units.filter(u => u.bloodGroup === bg && u.componentCode === c).length;
          if (total > 0) {
            csvContent += `${bg},${c},${avail},${quar},${res},${total}\n`;
          }
        });
      });
    } else {
      csvContent += 'Timestamp,Entity,Details\n';
      auditLogs.forEach(l => {
        csvContent += `"${l.timestamp}","${l.entityId}","${l.details}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LifeBlood_${reportMeta.replace(/[^a-zA-Z0-9]/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Governance</span>
            <span aria-hidden="true">·</span>
            <span>Analytics & Reports</span>
            <span aria-hidden="true">·</span>
            <span>16 Standardized Regulatory Registers</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Reports & Clinical Analytics Center
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCurrentReportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Main Split: Report Selector & Report Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Column: 16 Standardized Reports Selector */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-xs space-y-1 no-print">
          <div className="px-3 py-2 text-xs font-semibold text-slate-900 border-b border-slate-100">
            Standard Clinical Reports
          </div>
          <div className="max-h-[600px] overflow-y-auto space-y-0.5 pt-1">
            {reportList.map(r => (
              <button
                key={r.id}
                onClick={() => setSelectedReportId(r.id)}
                className={`w-full text-left px-3 py-2 text-xs rounded-md transition-colors cursor-pointer flex items-center justify-between ${
                  selectedReportId === r.id 
                    ? 'bg-red-50 text-red-900 font-semibold' 
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span className="truncate pr-2">{r.id}. {r.title}</span>
                <span className="text-[10px] text-slate-400 font-mono shrink-0">{r.category}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right 3 Cols: Active Report View */}
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-lg p-6 shadow-xs space-y-5 printable-area">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <span className="text-xs text-red-800 font-mono font-semibold uppercase tracking-wider">
                Official Report #{selectedReportId}
              </span>
              <h2 className="text-lg font-bold text-slate-900">
                {reportList.find(r => r.id === selectedReportId)?.title}
              </h2>
              <div className="text-xs text-slate-500 mt-0.5">
                Calculated dynamically from real database records · Generated on {new Date().toLocaleString()}
              </div>
            </div>
            
            <div className="flex items-center gap-2 no-print">
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as any)}
                className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white cursor-pointer"
              >
                <option value="month">Current Month</option>
                <option value="year">Current Year</option>
                <option value="all">All Historical Data</option>
              </select>
            </div>
          </div>

          {/* Dynamic Content Based on Selected Report */}
          {selectedReportId === 1 && (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                    <tr>
                      <th className="py-2.5 px-3">ABO/Rh Group</th>
                      <th className="py-2.5 px-3">Component Type</th>
                      <th className="py-2.5 px-3 text-right">Available (Released)</th>
                      <th className="py-2.5 px-3 text-right">Quarantined</th>
                      <th className="py-2.5 px-3 text-right">Reserved</th>
                      <th className="py-2.5 px-3 text-right">Total Units</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {bloodGroups.map(bg => {
                      return components.map(c => {
                        const avail = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Released').length;
                        const quar = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Quarantined').length;
                        const res = units.filter(u => u.bloodGroup === bg && u.componentCode === c && u.status === 'Reserved').length;
                        const total = units.filter(u => u.bloodGroup === bg && u.componentCode === c).length;

                        if (total === 0) return null;

                        return (
                          <tr key={`${bg}-${c}`} className="hover:bg-slate-50/70">
                            <td className="py-2.5 px-3 font-bold text-slate-900">{bg}</td>
                            <td className="py-2.5 px-3 font-sans text-slate-700">{c}</td>
                            <td className="py-2.5 px-3 text-right text-emerald-800 font-bold">{avail}</td>
                            <td className="py-2.5 px-3 text-right text-amber-700">{quar}</td>
                            <td className="py-2.5 px-3 text-right text-blue-700">{res}</td>
                            <td className="py-2.5 px-3 text-right font-bold text-slate-900">{total}</td>
                          </tr>
                        );
                      });
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {selectedReportId === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {bloodGroups.map(bg => {
                  const count = donors.filter(d => d.bloodGroup === bg).length;
                  return (
                    <div key={bg} className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-center">
                      <div className="text-2xl font-bold font-mono text-slate-900">{bg}</div>
                      <div className="text-base font-bold font-mono text-red-900 mt-1">{count} donors</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {donors.length > 0 ? Math.round((count / donors.length) * 100) : 0}% of registry
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {selectedReportId === 4 && (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                    <tr>
                      <th className="py-2.5 px-3">Order Reference</th>
                      <th className="py-2.5 px-3">Hospital</th>
                      <th className="py-2.5 px-3">Priority</th>
                      <th className="py-2.5 px-3">Requested</th>
                      <th className="py-2.5 px-3">Dispatched</th>
                      <th className="py-2.5 px-3 text-right">Fulfillment Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {requests.map(req => {
                      const pct = Math.round((req.unitsIssued / req.unitsRequested) * 100);
                      return (
                        <tr key={req.id}>
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{req.requestNumber}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-800">{req.hospitalName}</td>
                          <td className="py-2.5 px-3">{req.priority}</td>
                          <td className="py-2.5 px-3 font-mono">{req.unitsRequested} units</td>
                          <td className="py-2.5 px-3 font-mono">{req.unitsIssued} units</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-800">{pct}%</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {selectedReportId > 4 && (
            <div className="space-y-3">
              <div className="text-xs text-slate-600">
                Displaying live filtered records for <strong className="text-slate-900">{reportList.find(r => r.id === selectedReportId)?.title}</strong>:
              </div>
              <div className="border border-slate-200 rounded-lg p-4 bg-slate-50 font-mono text-xs max-h-96 overflow-y-auto space-y-2">
                {auditLogs.map(l => (
                  <div key={l.id} className="text-slate-700 border-b border-slate-200 pb-1.5">
                    <span className="text-slate-400">[{l.timestamp}]</span> <strong className="text-red-900">{l.action}</strong>: {l.details}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Institutional Sign-off footer */}
          <div className="pt-8 border-t border-slate-200 text-xs text-slate-500 flex justify-between">
            <div>
              <span>LifeBlood Quality Management System</span>
              <span className="block text-[11px] text-slate-400">ISO 15189 Medical Laboratories & AABB Accredited</span>
            </div>
            <div className="text-right">
              <span className="block">Authorized Clinical Release Officer</span>
              <span className="font-mono text-slate-800 font-semibold">Dr. Amina Yusuf, Chief Hematologist</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
