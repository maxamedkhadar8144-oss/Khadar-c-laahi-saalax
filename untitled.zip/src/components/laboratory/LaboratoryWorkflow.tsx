import React, { useState } from 'react';
import { 
  Microscope, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Clock, 
  Barcode, 
  Filter, 
  FileCheck,
  Ban
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { LabTest, User } from '../../types';

interface LaboratoryWorkflowProps {
  currentUser: User;
}

export const LaboratoryWorkflow: React.FC<LaboratoryWorkflowProps> = ({ currentUser }) => {
  const [tests, setTests] = useState<LabTest[]>(StorageService.getLabTests());
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Editable test form state
  const [hivResult, setHivResult] = useState<'Non-Reactive' | 'Reactive' | 'Pending'>('Non-Reactive');
  const [hbsagResult, setHbsagResult] = useState<'Non-Reactive' | 'Reactive' | 'Pending'>('Non-Reactive');
  const [hcvResult, setHcvResult] = useState<'Non-Reactive' | 'Reactive' | 'Pending'>('Non-Reactive');
  const [syphilisResult, setSyphilisResult] = useState<'Non-Reactive' | 'Reactive' | 'Pending'>('Non-Reactive');
  const [antibodyScreen, setAntibodyScreen] = useState<'Negative' | 'Positive' | 'Inconclusive'>('Negative');
  const [aboVerified, setAboVerified] = useState<'A' | 'B' | 'AB' | 'O'>('O');
  const [rhVerified, setRhVerified] = useState<'Positive' | 'Negative'>('Negative');
  const [decision, setDecision] = useState<'Released' | 'Rejected' | 'Pending'>('Released');
  const [techNotes, setTechNotes] = useState('');

  const openTestEditor = (t: LabTest) => {
    setSelectedTest(t);
    setHivResult(t.hivResult);
    setHbsagResult(t.hbsagResult);
    setHcvResult(t.hcvResult);
    setSyphilisResult(t.syphilisResult);
    setAntibodyScreen(t.antibodyScreen);
    setAboVerified(t.aboVerified);
    setRhVerified(t.rhVerified);
    setDecision(t.overallDecision);
    setTechNotes(t.notes || '');
    setErrorMessage('');
  };

  const handleSaveResults = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTest) return;
    setErrorMessage('');

    const updated: LabTest = {
      ...selectedTest,
      hivResult,
      hbsagResult,
      hcvResult,
      syphilisResult,
      antibodyScreen,
      aboVerified,
      rhVerified,
      overallDecision: decision,
      notes: techNotes
    };

    const res = StorageService.updateLabTest(updated);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to save laboratory results.');
      return;
    }

    setTests(StorageService.getLabTests());
    setSuccessMessage(`Laboratory verification complete for Sample ${selectedTest.sampleBarcode} (Unit ${selectedTest.unitBarcode}): Decision ${decision}.`);
    setSelectedTest(null);
    setTimeout(() => setSuccessMessage(''), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Governance</span>
            <span aria-hidden="true">·</span>
            <span>Laboratory Testing</span>
            <span aria-hidden="true">·</span>
            <span>Fourfold Infectious Screening & Confirmatory Typing</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Laboratory Testing & Clinical Release Barrier
          </h1>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-4 bg-red-50/50 border border-red-200 rounded-lg text-xs text-red-900 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Strict Transfusion Release Barrier:</span> Every collected unit undergoes mandatory fourfold screening: HIV-1/2, HBsAg (Hepatitis B), Anti-HCV (Hepatitis C), and Syphilis (RPR/Treponemal). Units cannot be released to available inventory while tests remain "Pending" or if any screening is "Reactive".
        </div>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Laboratory Worklist Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-900">Laboratory Assay Worklist</span>
          <span className="text-xs text-slate-500 font-mono">{tests.length} Samples</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Sample ID</th>
                <th className="py-3 px-4">Unit Barcode</th>
                <th className="py-3 px-4">ABO / Rh Confirmed</th>
                <th className="py-3 px-4">HIV</th>
                <th className="py-3 px-4">HBsAg</th>
                <th className="py-3 px-4">HCV</th>
                <th className="py-3 px-4">Syphilis</th>
                <th className="py-3 px-4">Antibody</th>
                <th className="py-3 px-4">Decision</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {tests.map(t => (
                <tr key={t.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-bold text-slate-900">{t.sampleBarcode}</td>
                  <td className="py-3 px-4 text-slate-700">{t.unitBarcode}</td>
                  <td className="py-3 px-4 font-bold text-red-900">{t.aboVerified} {t.rhVerified === 'Positive' ? '(+)' : '(-)'}</td>
                  <td className="py-3 px-4">
                    <span className={t.hivResult === 'Non-Reactive' ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                      {t.hivResult}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={t.hbsagResult === 'Non-Reactive' ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                      {t.hbsagResult}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={t.hcvResult === 'Non-Reactive' ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                      {t.hcvResult}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={t.syphilisResult === 'Non-Reactive' ? 'text-emerald-700 font-semibold' : 'text-amber-700 font-semibold'}>
                      {t.syphilisResult}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans text-slate-600">{t.antibodyScreen}</td>
                  <td className="py-3 px-4 font-sans">
                    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                      t.overallDecision === 'Released' ? 'bg-emerald-50 text-emerald-800' :
                      t.overallDecision === 'Pending' ? 'bg-amber-100 text-amber-900' :
                      'bg-red-50 text-red-800'
                    }`}>
                      {t.overallDecision}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-sans">
                    <button
                      onClick={() => openTestEditor(t)}
                      className="px-2.5 py-1 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded cursor-pointer transition-colors shadow-xs"
                    >
                      Process / Release
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assay Verification & Decision Modal */}
      {selectedTest && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-semibold text-slate-900">
                  Laboratory Serology & Release Authorization
                </h3>
                <div className="text-xs text-slate-500 font-mono">
                  Sample: {selectedTest.sampleBarcode} · Unit: {selectedTest.unitBarcode}
                </div>
              </div>
              <button 
                onClick={() => setSelectedTest(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveResults} className="p-6 space-y-4 text-xs">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Confirmatory ABO & Rh Typing */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <span className="font-semibold text-slate-900">1. Confirmatory Forward & Reverse Grouping</span>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Confirmed ABO Group *</label>
                    <select
                      value={aboVerified}
                      onChange={(e) => setAboVerified(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-bold cursor-pointer"
                    >
                      <option value="A">Group A</option>
                      <option value="B">Group B</option>
                      <option value="AB">Group AB</option>
                      <option value="O">Group O</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Confirmed RhD Factor *</label>
                    <select
                      value={rhVerified}
                      onChange={(e) => setRhVerified(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-bold cursor-pointer"
                    >
                      <option value="Positive">RhD Positive (+)</option>
                      <option value="Negative">RhD Negative (-)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* 4 Mandatory Infectious Disease Panels */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <span className="font-semibold text-slate-900">2. Transfusion-Transmissible Infection (TTI) Assays</span>
                
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">HIV-1/2 Antigen/Antibody *</label>
                    <select
                      value={hivResult}
                      onChange={(e) => setHivResult(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
                    >
                      <option value="Non-Reactive">Non-Reactive (Safe)</option>
                      <option value="Reactive">Reactive (Positive - REJECT)</option>
                      <option value="Pending">Pending Run</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Hepatitis B (HBsAg) *</label>
                    <select
                      value={hbsagResult}
                      onChange={(e) => setHbsagResult(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
                    >
                      <option value="Non-Reactive">Non-Reactive (Safe)</option>
                      <option value="Reactive">Reactive (Positive - REJECT)</option>
                      <option value="Pending">Pending Run</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Hepatitis C (Anti-HCV) *</label>
                    <select
                      value={hcvResult}
                      onChange={(e) => setHcvResult(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
                    >
                      <option value="Non-Reactive">Non-Reactive (Safe)</option>
                      <option value="Reactive">Reactive (Positive - REJECT)</option>
                      <option value="Pending">Pending Run</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-500 text-[11px] mb-1">Syphilis (RPR / Treponema) *</label>
                    <select
                      value={syphilisResult}
                      onChange={(e) => setSyphilisResult(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
                    >
                      <option value="Non-Reactive">Non-Reactive (Safe)</option>
                      <option value="Reactive">Reactive (Positive - REJECT)</option>
                      <option value="Pending">Pending Run</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2">
                  <label className="block text-slate-500 text-[11px] mb-1">Irregular Atypical Antibody Screen *</label>
                  <select
                    value={antibodyScreen}
                    onChange={(e) => setAntibodyScreen(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
                  >
                    <option value="Negative">Negative (No clinically significant antibodies)</option>
                    <option value="Positive">Positive (Atypical antibodies detected)</option>
                    <option value="Inconclusive">Inconclusive</option>
                  </select>
                </div>
              </div>

              {/* Release / Discard Decision */}
              <div>
                <label className="block font-semibold text-slate-900 mb-1">Clinical Release Determination *</label>
                <select
                  value={decision}
                  onChange={(e) => setDecision(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md bg-white font-bold cursor-pointer"
                >
                  <option value="Released">AUTHORIZE RELEASE (Move from Quarantine to Active Stock)</option>
                  <option value="Rejected">REJECT & DISCARD (Destroy Unit as Bio-Hazard)</option>
                  <option value="Pending">RETAIN IN QUARANTINE (Await confirmatory repeat)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Laboratory Technologist Notes:</label>
                <textarea
                  value={techNotes}
                  onChange={(e) => setTechNotes(e.target.value)}
                  placeholder="e.g. Abbott Architect ELISA assay Batch #882 run complete. Dual technician verification performed."
                  className="w-full p-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                  rows={2}
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedTest(null)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Authorize Determination
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
