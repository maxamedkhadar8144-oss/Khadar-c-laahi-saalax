import React, { useState } from 'react';
import { 
  Grid, 
  AlertTriangle, 
  ShieldCheck, 
  Sliders, 
  CheckCircle2, 
  Info,
  Droplet
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { BloodGroup } from '../../types';

export const BloodGroupsView: React.FC = () => {
  const units = StorageService.getBloodUnits();
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup>('O-');
  const [thresholds, setThresholds] = useState<Record<BloodGroup, number>>({
    'A+': 25,
    'A-': 15,
    'B+': 20,
    'B-': 12,
    'AB+': 15,
    'AB-': 10,
    'O+': 35,
    'O-': 30
  });
  const [editingThreshold, setEditingThreshold] = useState<BloodGroup | null>(null);
  const [newThresholdVal, setNewThresholdVal] = useState<number>(20);
  const [successMessage, setSuccessMessage] = useState('');

  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  // Calculate detailed inventory statistics per blood group
  const groupStats = bloodGroups.map(bg => {
    const groupUnits = units.filter(u => u.bloodGroup === bg);
    const available = groupUnits.filter(u => u.status === 'Released').length;
    const reserved = groupUnits.filter(u => u.status === 'Reserved').length;
    const quarantined = groupUnits.filter(u => u.status === 'Quarantined').length;
    const issued = groupUnits.filter(u => u.status === 'Issued').length;
    const expired = groupUnits.filter(u => u.status === 'Expired').length;
    const threshold = thresholds[bg] || 15;
    const isCritical = available < 5;
    const isLow = available < threshold;

    return {
      group: bg,
      available,
      reserved,
      quarantined,
      issued,
      expired,
      threshold,
      isCritical,
      isLow,
      totalUnits: groupUnits.length
    };
  });

  const saveThreshold = (bg: BloodGroup) => {
    setThresholds({ ...thresholds, [bg]: newThresholdVal });
    setEditingThreshold(null);
    setSuccessMessage(`Updated minimum stock threshold for ${bg} to ${newThresholdVal} units.`);
    StorageService.logAudit('Stock Threshold Updated', 'BloodGroups', bg, `Threshold set to ${newThresholdVal} units`);
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  // Clinical Compatibility Matrix Data
  const compatibilityData: Record<BloodGroup, {
    redCellCanGiveTo: BloodGroup[];
    redCellCanReceiveFrom: BloodGroup[];
    plasmaCanGiveTo: BloodGroup[];
    plasmaCanReceiveFrom: BloodGroup[];
    notes: string;
  }> = {
    'O-': {
      redCellCanGiveTo: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      redCellCanReceiveFrom: ['O-'],
      plasmaCanGiveTo: ['O+', 'O-'],
      plasmaCanReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      notes: 'Universal Red Blood Cell Donor. High priority for emergency trauma uncrossmatched release.'
    },
    'O+': {
      redCellCanGiveTo: ['A+', 'B+', 'AB+', 'O+'],
      redCellCanReceiveFrom: ['O+', 'O-'],
      plasmaCanGiveTo: ['O+', 'O-'],
      plasmaCanReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      notes: 'Most common blood group in clinical populations. High routine inventory turnover.'
    },
    'A-': {
      redCellCanGiveTo: ['A+', 'A-', 'AB+', 'AB-'],
      redCellCanReceiveFrom: ['A-', 'O-'],
      plasmaCanGiveTo: ['A+', 'A-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['A+', 'A-', 'AB+', 'AB-'],
      notes: 'Can safely provide red cells to A and AB recipients.'
    },
    'A+': {
      redCellCanGiveTo: ['A+', 'AB+'],
      redCellCanReceiveFrom: ['A+', 'A-', 'O+', 'O-'],
      plasmaCanGiveTo: ['A+', 'A-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['A+', 'A-', 'AB+', 'AB-'],
      notes: 'Second most common red cell type requested for elective surgical suites.'
    },
    'B-': {
      redCellCanGiveTo: ['B+', 'B-', 'AB+', 'AB-'],
      redCellCanReceiveFrom: ['B-', 'O-'],
      plasmaCanGiveTo: ['B+', 'B-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['B+', 'B-', 'AB+', 'AB-'],
      notes: 'Rare group; requires proactive recruitment for platelet and red cell pools.'
    },
    'B+': {
      redCellCanGiveTo: ['B+', 'AB+'],
      redCellCanReceiveFrom: ['B+', 'B-', 'O+', 'O-'],
      plasmaCanGiveTo: ['B+', 'B-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['B+', 'B-', 'AB+', 'AB-'],
      notes: 'Critical component of pediatric and trauma support inventory.'
    },
    'AB-': {
      redCellCanGiveTo: ['AB+', 'AB-'],
      redCellCanReceiveFrom: ['AB-', 'A-', 'B-', 'O-'],
      plasmaCanGiveTo: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['AB+', 'AB-'],
      notes: 'Rare red cell type; plasma is universal for negative/positive recipients.'
    },
    'AB+': {
      redCellCanGiveTo: ['AB+'],
      redCellCanReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      plasmaCanGiveTo: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      plasmaCanReceiveFrom: ['AB+'],
      notes: 'Universal Red Cell Recipient. Universal Plasma Donor.'
    }
  };

  const selectedCompat = compatibilityData[selectedGroup];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>ABO / RhD Management</span>
            <span aria-hidden="true">·</span>
            <span>Safety Thresholds & Compatibility</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Blood Groups & Transfusion Compatibility
          </h1>
        </div>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* 8 Blood Group Stock Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {groupStats.map(stat => (
          <div 
            key={stat.group}
            className={`bg-white border rounded-lg p-4 shadow-xs transition-all cursor-pointer ${
              selectedGroup === stat.group ? 'ring-2 ring-red-800 border-red-800' : 'border-slate-200 hover:border-slate-300'
            }`}
            onClick={() => setSelectedGroup(stat.group)}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-2xl font-black font-mono text-slate-900">{stat.group}</span>
              <div className="flex items-center gap-1.5">
                {stat.isCritical ? (
                  <span className="text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                    CRITICAL
                  </span>
                ) : stat.isLow ? (
                  <span className="text-[10px] font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                    LOW STOCK
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    ADEQUATE
                  </span>
                )}
              </div>
            </div>

            <div className="text-3xl font-bold font-mono tabular-nums text-slate-800 mb-2">
              {stat.available} <span className="text-xs font-normal text-slate-500 font-sans">available units</span>
            </div>

            <div className="space-y-1 text-xs text-slate-600 pt-2 border-t border-slate-100">
              <div className="flex justify-between">
                <span>Quarantined:</span>
                <span className="font-mono font-medium">{stat.quarantined}</span>
              </div>
              <div className="flex justify-between">
                <span>Reserved:</span>
                <span className="font-mono font-medium">{stat.reserved}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Issued:</span>
                <span className="font-mono font-medium">{stat.issued}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Threshold:</span>
                <span className="font-mono">{stat.threshold} min</span>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setEditingThreshold(stat.group);
                setNewThresholdVal(stat.threshold);
              }}
              className="w-full mt-3 py-1.5 text-[11px] font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded transition-colors"
            >
              Configure Threshold
            </button>
          </div>
        ))}
      </div>

      {/* Threshold Editor Modal */}
      {editingThreshold && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-sm p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Configure Stock Threshold for {editingThreshold}
            </h3>
            <p className="text-xs text-slate-500">
              Set the minimum stock level before an alert is triggered across the hospital system.
            </p>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Minimum Units *</label>
              <input
                type="number"
                min="1"
                max="500"
                value={newThresholdVal}
                onChange={(e) => setNewThresholdVal(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono text-xs focus:ring-1 focus:ring-red-800"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setEditingThreshold(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={() => saveThreshold(editingThreshold)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md"
              >
                Save Threshold
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clinical Compatibility Detail Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Clinical Transfusion Compatibility Matrix: <span className="font-mono text-red-900">{selectedGroup}</span>
            </h2>
            <div className="text-xs text-slate-500">
              Separate rules for Red Blood Cells vs. Plasma & Platelet products
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 bg-slate-100 text-slate-700 font-medium rounded self-start sm:self-auto">
            Clinical Reference Model
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          
          {/* Red Blood Cell Compatibility */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
            <div className="text-xs font-bold text-red-900 uppercase tracking-wider flex items-center gap-1.5">
              <Droplet className="w-4 h-4 text-red-700" />
              <span>Red Blood Cells (Erythrocytes)</span>
            </div>

            <div className="text-xs space-y-2">
              <div>
                <span className="text-slate-500 block text-[11px]">Can Donate Red Cells To:</span>
                <div className="flex flex-wrap gap-1.5 mt-1 font-mono">
                  {selectedCompat.redCellCanGiveTo.map(g => (
                    <span key={g} className="px-2 py-0.5 bg-red-100 text-red-900 font-bold rounded text-xs">
                      {g}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <span className="text-slate-500 block text-[11px]">Can Receive Red Cells From:</span>
                <div className="flex flex-wrap gap-1.5 mt-1 font-mono">
                  {selectedCompat.redCellCanReceiveFrom.map(g => (
                    <span key={g} className="px-2 py-0.5 bg-emerald-100 text-emerald-900 font-bold rounded text-xs">
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Plasma & Cryoprecipitate Compatibility */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
            <div className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
              <Droplet className="w-4 h-4 text-blue-700" />
              <span>Fresh Frozen Plasma (FFP) & Platelets</span>
            </div>

            <div className="text-xs space-y-2">
              <div>
                <span className="text-slate-500 block text-[11px]">Can Donate Plasma To:</span>
                <div className="flex flex-wrap gap-1.5 mt-1 font-mono">
                  {selectedCompat.plasmaCanGiveTo.map(g => (
                    <span key={g} className="px-2 py-0.5 bg-blue-100 text-blue-900 font-bold rounded text-xs">
                      {g}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <span className="text-slate-500 block text-[11px]">Can Receive Plasma From:</span>
                <div className="flex flex-wrap gap-1.5 mt-1 font-mono">
                  {selectedCompat.plasmaCanReceiveFrom.map(g => (
                    <span key={g} className="px-2 py-0.5 bg-indigo-100 text-indigo-900 font-bold rounded text-xs">
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Clinical Disclaimer */}
        <div className="p-3 bg-red-50/60 border border-red-200 rounded-lg text-xs text-red-900 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
          <div>
            <strong>Laboratory Verification Warning:</strong> Never authorize clinical transfusion solely on ABO/Rh compatibility charts. Routine transfusion requires verified antibody screening, immediate spin or antiglobulin crossmatching, and patient wristband identification.
          </div>
        </div>

      </div>

    </div>
  );
};
