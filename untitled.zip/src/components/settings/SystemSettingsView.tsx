import React, { useState, useRef } from 'react';
import { 
  Settings, 
  Globe, 
  Clock, 
  ShieldCheck, 
  Database, 
  CheckCircle2, 
  Save, 
  RefreshCw,
  Sliders,
  Users,
  UserCheck,
  UserX,
  Plus,
  Trash2,
  Edit3,
  Download,
  Upload,
  AlertTriangle,
  RotateCcw,
  Building2,
  Phone,
  Mail,
  KeyRound,
  Lock,
  Layers,
  FileText,
  Search,
  Filter,
  X,
  Archive,
  HardDrive,
  ShieldAlert,
  Sparkles,
  HelpCircle,
  Activity
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { SystemSettings, User, RoleSlug, BackupSnapshot } from '../../types';
import { ProfilePictureUploader } from '../common/ProfilePictureUploader';

interface SystemSettingsViewProps {
  isArabic: boolean;
  onToggleArabic: () => void;
  currentUser?: User;
  onUserUpdate?: (user: User) => void;
}

export const SystemSettingsView: React.FC<SystemSettingsViewProps> = ({ 
  isArabic, 
  onToggleArabic,
  currentUser: initialCurrentUser,
  onUserUpdate
}) => {
  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'admin' | 'users' | 'system' | 'management' | 'backup'>('admin');

  // Core Data States
  const [settings, setSettings] = useState<SystemSettings>(() => StorageService.getSettings());
  const [users, setUsers] = useState<User[]>(() => StorageService.getUsers());
  const [backups, setBackups] = useState<BackupSnapshot[]>(() => StorageService.getBackups());
  const [currentUser, setCurrentUser] = useState<User>(() => initialCurrentUser || StorageService.getCurrentUser());

  // Feedback notifications
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Admin Profile Edit State
  const [adminName, setAdminName] = useState(currentUser.name);
  const [adminEmail, setAdminEmail] = useState(currentUser.email);
  const [adminPhone, setAdminPhone] = useState(currentUser.phone || '+1-555-BLOOD-01');
  const [adminJobTitle, setAdminJobTitle] = useState(currentUser.jobTitle || 'Chief Transfusion Officer');
  const [adminDepartment, setAdminDepartment] = useState(currentUser.department);
  const [adminFacility, setAdminFacility] = useState(currentUser.facility || 'Central Transfusion Authority');
  const [adminAvatarUrl, setAdminAvatarUrl] = useState<string | undefined>(currentUser.avatarUrl);

  // Users Filter & Search State
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  const [userStatusFilter, setUserStatusFilter] = useState<string>('all');

  // User Add / Edit Modal States
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [showDeleteUserModal, setShowDeleteUserModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // User Form State (Used for Add & Edit)
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formJobTitle, setFormJobTitle] = useState('');
  const [formRole, setFormRole] = useState<RoleSlug>('blood-bank-tech');
  const [formDepartment, setFormDepartment] = useState('Laboratory & Processing');
  const [formFacility, setFormFacility] = useState('Central Blood Bank');
  const [formAvatarUrl, setFormAvatarUrl] = useState<string | undefined>(undefined);
  const [formIsActive, setFormIsActive] = useState(true);

  // Management Add Field States
  const [newDepartmentName, setNewDepartmentName] = useState('');
  const [newStorageLocationName, setNewStorageLocationName] = useState('');

  // Backup Modals & Actions States
  const [showCreateBackupModal, setShowCreateBackupModal] = useState(false);
  const [showEditBackupModal, setShowEditBackupModal] = useState(false);
  const [showDeleteBackupModal, setShowDeleteBackupModal] = useState(false);
  const [showRestoreBackupModal, setShowRestoreBackupModal] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<BackupSnapshot | null>(null);

  const [backupFormName, setBackupFormName] = useState('');
  const [backupFormNotes, setBackupFormNotes] = useState('');
  const backupFileInputRef = useRef<HTMLInputElement>(null);

  const roleLabels: Record<RoleSlug, string> = {
    'super-admin': 'Super Administrator',
    'blood-bank-admin': 'Blood Bank Administrator',
    'blood-bank-tech': 'Blood Bank Technician',
    'lab-tech': 'Laboratory Technician',
    'donor-officer': 'Donor Registration Officer',
    'hospital-officer': 'Hospital Requesting Officer',
    'report-viewer': 'Report Viewer'
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setErrorMessage('');
    setTimeout(() => setSuccessMessage(''), 4500);
  };

  const showError = (msg: string) => {
    setErrorMessage(msg);
    setTimeout(() => setErrorMessage(''), 5500);
  };

  // --- 1. Admin Profile Save ---
  const handleSaveAdminProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedUser: User = {
      ...currentUser,
      name: adminName.trim(),
      email: adminEmail.trim(),
      phone: adminPhone.trim(),
      jobTitle: adminJobTitle.trim(),
      department: adminDepartment.trim(),
      facility: adminFacility.trim(),
      avatarUrl: adminAvatarUrl
    };

    StorageService.saveUser(updatedUser);
    StorageService.setCurrentUser(updatedUser);
    setCurrentUser(updatedUser);
    setUsers(StorageService.getUsers());
    if (onUserUpdate) onUserUpdate(updatedUser);

    showSuccess('Administrator profile data & avatar updated successfully.');
  };

  // --- 2. System Settings Save ---
  const handleSaveSystemSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    StorageService.saveSettings(settings);
    showSuccess('Clinical system parameters and operational policies updated successfully.');
  };

  // --- 3. User Management Actions ---
  const handleOpenAddUser = () => {
    setFormName('');
    setFormEmail('');
    setFormPhone('');
    setFormJobTitle('');
    setFormRole('blood-bank-tech');
    setFormDepartment('Immunohematology & Viral Serology');
    setFormFacility('Central Blood Bank');
    setFormAvatarUrl(undefined);
    setFormIsActive(true);
    setShowAddUserModal(true);
  };

  const handleOpenEditUser = (user: User) => {
    setSelectedUser(user);
    setFormName(user.name);
    setFormEmail(user.email);
    setFormPhone(user.phone || '');
    setFormJobTitle(user.jobTitle || '');
    setFormRole(user.role);
    setFormDepartment(user.department);
    setFormFacility(user.facility || 'Central Blood Bank');
    setFormAvatarUrl(user.avatarUrl);
    setFormIsActive(user.isActive);
    setShowEditUserModal(true);
  };

  const handleSaveAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formEmail.trim()) {
      showError('Please provide both staff member name and email.');
      return;
    }

    const currentUsers = StorageService.getUsers();
    const newId = currentUsers.length > 0 ? Math.max(...currentUsers.map(u => u.id)) + 1 : 1;
    const staffId = `STAFF-${String(newId).padStart(3, '0')}`;

    const newUser: User = {
      id: newId,
      staffId,
      name: formName.trim(),
      email: formEmail.trim(),
      phone: formPhone.trim() || undefined,
      jobTitle: formJobTitle.trim() || undefined,
      role: formRole,
      roleName: roleLabels[formRole],
      department: formDepartment.trim(),
      facility: formFacility.trim() || undefined,
      avatarUrl: formAvatarUrl,
      isActive: formIsActive,
      lastLoginAt: 'Never logged in'
    };

    StorageService.saveUser(newUser);
    setUsers(StorageService.getUsers());
    setShowAddUserModal(false);
    showSuccess(`Staff user account created: ${newUser.name} (${newUser.staffId})`);
  };

  const handleSaveEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;

    const updated: User = {
      ...selectedUser,
      name: formName.trim(),
      email: formEmail.trim(),
      phone: formPhone.trim() || undefined,
      jobTitle: formJobTitle.trim() || undefined,
      role: formRole,
      roleName: roleLabels[formRole],
      department: formDepartment.trim(),
      facility: formFacility.trim() || undefined,
      avatarUrl: formAvatarUrl,
      isActive: formIsActive
    };

    StorageService.saveUser(updated);
    setUsers(StorageService.getUsers());

    // If updated user is the active user
    if (currentUser.id === updated.id) {
      setCurrentUser(updated);
      if (onUserUpdate) onUserUpdate(updated);
    }

    setShowEditUserModal(false);
    showSuccess(`User account updated: ${updated.name} (${updated.staffId})`);
  };

  const handleOpenDeleteUser = (user: User) => {
    setSelectedUser(user);
    setShowDeleteUserModal(true);
  };

  const handleConfirmDeleteUser = () => {
    if (!selectedUser) return;
    const result = StorageService.deleteUser(selectedUser.id);
    if (!result.success) {
      showError(result.error || 'Could not delete user account.');
      setShowDeleteUserModal(false);
      return;
    }

    setUsers(StorageService.getUsers());
    setShowDeleteUserModal(false);
    showSuccess(`Staff account ${selectedUser.name} (${selectedUser.staffId}) deleted successfully.`);
    setSelectedUser(null);
  };

  const handleToggleUserStatus = (user: User) => {
    const nextStatus = !user.isActive;
    const updated = { ...user, isActive: nextStatus };
    StorageService.saveUser(updated);
    setUsers(StorageService.getUsers());
    if (currentUser.id === updated.id) {
      setCurrentUser(updated);
      if (onUserUpdate) onUserUpdate(updated);
    }
    showSuccess(`User ${user.name} is now ${nextStatus ? 'Active' : 'Suspended'}.`);
  };

  // --- 4. Management Config (Departments & Storage Locations) ---
  const handleAddDepartment = () => {
    if (!newDepartmentName.trim()) return;
    const currentDepts = settings.departments || [
      'Executive Administration',
      'Immunohematology & Viral Serology',
      'Component Separation & Cold Chain',
      'Donor Recruitment & Mobile Drives',
      'Transfusion Clinical Safety',
      'Hospital Distribution & Logistics',
      'Quality Assurance & Regulatory'
    ];

    if (currentDepts.includes(newDepartmentName.trim())) {
      showError('This department already exists.');
      return;
    }

    const updatedDepts = [...currentDepts, newDepartmentName.trim()];
    const updatedSettings = { ...settings, departments: updatedDepts };
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);
    setNewDepartmentName('');
    showSuccess(`Department "${newDepartmentName.trim()}" added to clinical directory.`);
  };

  const handleRemoveDepartment = (deptName: string) => {
    const currentDepts = settings.departments || [];
    if (currentDepts.length <= 1) {
      showError('At least one primary department must remain registered.');
      return;
    }
    const updatedDepts = currentDepts.filter(d => d !== deptName);
    const updatedSettings = { ...settings, departments: updatedDepts };
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);
    showSuccess(`Department "${deptName}" removed.`);
  };

  const handleAddStorageLocation = () => {
    if (!newStorageLocationName.trim()) return;
    const currentLocs = settings.storageLocations || [
      'Main Red Cell Cold Room #1 (FRIDGE-A1)',
      'Emergency O- Reserve Fridge (FRIDGE-A2)',
      'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
      'Platelet Incubator & Agitator (AGITATOR-C1)'
    ];

    if (currentLocs.includes(newStorageLocationName.trim())) {
      showError('This storage unit already exists.');
      return;
    }

    const updatedLocs = [...currentLocs, newStorageLocationName.trim()];
    const updatedSettings = { ...settings, storageLocations: updatedLocs };
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);
    setNewStorageLocationName('');
    showSuccess(`Storage unit "${newStorageLocationName.trim()}" registered.`);
  };

  const handleRemoveStorageLocation = (locName: string) => {
    const currentLocs = settings.storageLocations || [];
    if (currentLocs.length <= 1) {
      showError('At least one blood storage location is mandatory.');
      return;
    }
    const updatedLocs = currentLocs.filter(l => l !== locName);
    const updatedSettings = { ...settings, storageLocations: updatedLocs };
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);
    showSuccess(`Storage location "${locName}" removed.`);
  };

  // --- 5. Data Backup Management (Add, Edit, Delete, Restore, Download, Import) ---
  const handleOpenCreateBackup = () => {
    const dateStr = new Date().toISOString().slice(0, 10);
    setBackupFormName(`Full Database Snapshot (${dateStr})`);
    setBackupFormNotes('Automated pre-maintenance snapshot of all clinical registries.');
    setShowCreateBackupModal(true);
  };

  const handleConfirmCreateBackup = (e: React.FormEvent) => {
    e.preventDefault();
    const created = StorageService.createBackup(backupFormName, backupFormNotes);
    setBackups(StorageService.getBackups());
    setShowCreateBackupModal(false);
    showSuccess(`Backup snapshot created: "${created.name}" (${created.sizeKb} KB, ${created.recordCount} total records)`);
  };

  const handleOpenEditBackup = (bkp: BackupSnapshot) => {
    setSelectedBackup(bkp);
    setBackupFormName(bkp.name);
    setBackupFormNotes(bkp.notes || '');
    setShowEditBackupModal(true);
  };

  const handleConfirmEditBackup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBackup) return;
    StorageService.updateBackup(selectedBackup.id, backupFormName, backupFormNotes);
    setBackups(StorageService.getBackups());
    setShowEditBackupModal(false);
    showSuccess(`Backup details updated for ${selectedBackup.id}`);
  };

  const handleOpenDeleteBackup = (bkp: BackupSnapshot) => {
    setSelectedBackup(bkp);
    setShowDeleteBackupModal(true);
  };

  const handleConfirmDeleteBackup = () => {
    if (!selectedBackup) return;
    StorageService.deleteBackup(selectedBackup.id);
    setBackups(StorageService.getBackups());
    setShowDeleteBackupModal(false);
    showSuccess(`Backup snapshot ${selectedBackup.name} (${selectedBackup.id}) was permanently deleted.`);
    setSelectedBackup(null);
  };

  const handleOpenRestoreBackup = (bkp: BackupSnapshot) => {
    setSelectedBackup(bkp);
    setShowRestoreBackupModal(true);
  };

  const handleConfirmRestoreBackup = () => {
    if (!selectedBackup) return;
    const result = StorageService.restoreBackup(selectedBackup.id);
    if (!result.success) {
      showError(result.error || 'Failed to restore database from backup.');
      setShowRestoreBackupModal(false);
      return;
    }

    // Refresh all states
    setUsers(StorageService.getUsers());
    setSettings(StorageService.getSettings());
    setCurrentUser(StorageService.getCurrentUser());
    setShowRestoreBackupModal(false);
    showSuccess(`System database state restored successfully to: "${selectedBackup.name}".`);
    setTimeout(() => {
      window.location.reload();
    }, 1200);
  };

  const handleDownloadBackup = (bkp: BackupSnapshot) => {
    try {
      const dataStr = bkp.data || JSON.stringify(bkp, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `lifeblood_backup_${bkp.id}_${bkp.createdAt.split(' ')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showSuccess(`Exported snapshot file: ${bkp.id}.json`);
    } catch {
      showError('Failed to generate file download.');
    }
  };

  const handleDownloadSQLDump = (bkp: BackupSnapshot) => {
    try {
      const sqlContent = `-- LIFEBLOOD BBMS MYSQL DUMP
-- Snapshot ID: ${bkp.id}
-- Generated: ${bkp.createdAt}
-- Created By: ${bkp.createdBy}

SET FOREIGN_KEY_CHECKS=0;
-- DUMP TIMESTAMP: ${new Date().toISOString()}
-- COMPATIBLE WITH MYSQL 8.0+ / MARIADB 10.4+ ON XAMPP

${bkp.data ? `-- JSON ARCHIVE DATA ATTACHED:\n/*\n${bkp.data}\n*/` : '-- Initial snapshot baseline'}

SET FOREIGN_KEY_CHECKS=1;
`;
      const blob = new Blob([sqlContent], { type: 'text/sql' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `lifeblood_mysqldump_${bkp.id}.sql`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showSuccess(`Exported MySQL SQL dump: lifeblood_mysqldump_${bkp.id}.sql`);
    } catch {
      showError('Failed to generate SQL export.');
    }
  };

  const handleImportBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) {
        showError('Empty backup file.');
        return;
      }
      const result = StorageService.importBackupData(content, file.name.replace(/\.[^/.]+$/, ''));
      if (result.success && result.backup) {
        setBackups(StorageService.getBackups());
        showSuccess(`Backup file imported: "${result.backup.name}" (${result.backup.sizeKb} KB)`);
      } else {
        showError(result.error || 'Failed to parse backup archive.');
      }
    };
    reader.onerror = () => showError('Failed to read selected file.');
    reader.readAsText(file);
    e.target.value = '';
  };

  // Filtered users
  const filteredUsers = users.filter(u => {
    const matchSearch = 
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.staffId.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.department.toLowerCase().includes(userSearch.toLowerCase());
    const matchRole = userRoleFilter === 'all' || u.role === userRoleFilter;
    const matchStatus = userStatusFilter === 'all' || 
      (userStatusFilter === 'active' && u.isActive) ||
      (userStatusFilter === 'suspended' && !u.isActive);
    return matchSearch && matchRole && matchStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Administration</span>
            <span aria-hidden="true">·</span>
            <span>Governance & Architecture</span>
            <span aria-hidden="true">·</span>
            <span>Settings & Backups</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            System Settings & Administration Center
          </h1>
        </div>

        {/* Global Action / Quick Status */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleSaveSystemSettings()}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
          >
            <Save className="w-4 h-4" />
            <span>Save All Configuration</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center justify-between gap-2 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage('')} className="text-emerald-600 hover:text-emerald-900 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-md text-xs flex items-center justify-between gap-2 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="font-medium">{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage('')} className="text-rose-600 hover:text-rose-900 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1 text-xs font-medium">
        <button
          onClick={() => setActiveTab('admin')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-t-md transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'admin'
              ? 'bg-white border-t border-x border-slate-200 text-red-800 font-bold border-b-2 border-b-white -mb-1 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-red-800" />
          <span>Administrator Profile & Avatar</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-t-md transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'bg-white border-t border-x border-slate-200 text-red-800 font-bold border-b-2 border-b-white -mb-1 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4 text-red-800" />
          <span>All Users & Staff ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('system')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-t-md transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'system'
              ? 'bg-white border-t border-x border-slate-200 text-red-800 font-bold border-b-2 border-b-white -mb-1 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4 text-red-800" />
          <span>Clinical & Transfusion Policies</span>
        </button>

        <button
          onClick={() => setActiveTab('management')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-t-md transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'management'
              ? 'bg-white border-t border-x border-slate-200 text-red-800 font-bold border-b-2 border-b-white -mb-1 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4 text-red-800" />
          <span>Departments & Storage Management</span>
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-t-md transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'backup'
              ? 'bg-white border-t border-x border-slate-200 text-red-800 font-bold border-b-2 border-b-white -mb-1 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Database className="w-4 h-4 text-red-800" />
          <span>Data Backup & Recovery ({backups.length})</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: ADMINISTRATOR DATA & PROFILE PICTURE UPLOADER */}
      {/* ========================================================================= */}
      {activeTab === 'admin' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Admin Identity Card Preview */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs flex flex-col items-center text-center space-y-4">
            <div className="relative">
              {adminAvatarUrl ? (
                <img 
                  src={adminAvatarUrl} 
                  alt={adminName} 
                  className="w-24 h-24 rounded-full object-cover border-4 border-red-100 shadow-md" 
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-red-800 text-white flex items-center justify-center text-2xl font-bold shadow-md">
                  {adminName.substring(0, 2).toUpperCase()}
                </div>
              )}
              <span className="absolute bottom-0 right-0 w-5 h-5 bg-emerald-500 border-2 border-white rounded-full" title="Online & Active" />
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-900">{adminName}</h2>
              <div className="text-xs font-semibold text-red-800">{adminJobTitle}</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">{currentUser.staffId} · {currentUser.roleName}</div>
            </div>

            <div className="w-full pt-3 border-t border-slate-100 text-left space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-600">
                <span className="text-slate-400">Department:</span>
                <span className="font-medium text-slate-800">{adminDepartment}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="text-slate-400">Facility:</span>
                <span className="font-medium text-slate-800">{adminFacility}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="text-slate-400">Official Email:</span>
                <span className="font-mono text-[11px] text-slate-800 truncate max-w-[170px]">{adminEmail}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="text-slate-400">Direct Hotline:</span>
                <span className="font-mono text-slate-800">{adminPhone}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="text-slate-400">Session Status:</span>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700">Authenticated (RBAC Super-Admin)</span>
              </div>
            </div>
          </div>

          {/* Administrator Profile Editor Form */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-5 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-red-800" />
                <h3 className="text-sm font-bold text-slate-900">Edit Administrator Data & Picture</h3>
              </div>
              <span className="text-[11px] text-slate-400">Changes reflect immediately across Top Bar & Audit Trails</span>
            </div>

            <form onSubmit={handleSaveAdminProfile} className="space-y-4">
              
              {/* Profile Picture Uploader */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                <ProfilePictureUploader
                  currentAvatarUrl={adminAvatarUrl}
                  userName={adminName}
                  onChange={(url) => setAdminAvatarUrl(url)}
                  size="md"
                  label="Administrator Profile Picture / Clinical Badge"
                  helpText="Upload a photo from your computer (PNG, JPG, SVG) or select a clinical preset avatar."
                />
              </div>

              {/* Text Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Administrator Full Name *</label>
                  <input
                    type="text"
                    required
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Official Work Email *</label>
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Direct Emergency Phone / Extension</label>
                  <input
                    type="text"
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Executive Clinical Job Title</label>
                  <input
                    type="text"
                    value={adminJobTitle}
                    onChange={(e) => setAdminJobTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Assigned Department</label>
                  <input
                    type="text"
                    value={adminDepartment}
                    onChange={(e) => setAdminDepartment(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Primary Healthcare Facility</label>
                  <input
                    type="text"
                    value={adminFacility}
                    onChange={(e) => setAdminFacility(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>
              </div>

              {/* Password / Pin Simulation */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-500">
                  <KeyRound className="w-4 h-4 text-slate-400" />
                  <span>Two-Factor Authentication (2FA) & Transfusion Authorization Key: <strong className="text-emerald-700">Enforced</strong></span>
                </div>

                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Administrator Profile</span>
                </button>
              </div>

            </form>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: ALL USERS & STAFF MANAGEMENT (ADD, EDIT, DELETE, PICTURE UPLOADER) */}
      {/* ========================================================================= */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          
          {/* Controls: Search, Filters & Add Staff Button */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
            
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              {/* Search */}
              <div className="relative flex-1 sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search staff by name, email, ID..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                />
              </div>

              {/* Role Filter */}
              <select
                value={userRoleFilter}
                onChange={(e) => setUserRoleFilter(e.target.value)}
                className="px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700"
              >
                <option value="all">All Roles</option>
                <option value="super-admin">Super Administrator</option>
                <option value="blood-bank-admin">Blood Bank Administrator</option>
                <option value="blood-bank-tech">Blood Bank Technician</option>
                <option value="lab-tech">Laboratory Technician</option>
                <option value="donor-officer">Donor Registration Officer</option>
                <option value="hospital-officer">Hospital Requesting Officer</option>
                <option value="report-viewer">Report Viewer</option>
              </select>

              {/* Status Filter */}
              <select
                value={userStatusFilter}
                onChange={(e) => setUserStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="suspended">Suspended Only</option>
              </select>
            </div>

            <button
              onClick={handleOpenAddUser}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-end md:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add New User Account</span>
            </button>
          </div>

          {/* Users Table */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden text-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                  <tr>
                    <th className="py-3 px-4">Staff Member</th>
                    <th className="py-3 px-4">Staff ID</th>
                    <th className="py-3 px-4">Role Title</th>
                    <th className="py-3 px-4">Department & Facility</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Last Login</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map((u) => {
                    const isSelf = currentUser.id === u.id;
                    return (
                      <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                        
                        {/* Member + Avatar */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full overflow-hidden shrink-0 border border-slate-200 bg-slate-100 flex items-center justify-center font-bold text-slate-700">
                              {u.avatarUrl ? (
                                <img src={u.avatarUrl} alt={u.name} className="w-full h-full object-cover" />
                              ) : (
                                <span>{u.name.substring(0, 2).toUpperCase()}</span>
                              )}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                                <span>{u.name}</span>
                                {isSelf && (
                                  <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-red-100 text-red-800">You</span>
                                )}
                              </div>
                              <div className="text-slate-500 font-mono text-[11px]">{u.email}</div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{u.staffId}</td>

                        <td className="py-3 px-4">
                          <span className="font-medium text-slate-800">{u.roleName}</span>
                          {u.jobTitle && <span className="block text-slate-400 text-[11px]">{u.jobTitle}</span>}
                        </td>

                        <td className="py-3 px-4 text-slate-600">
                          <div>{u.department}</div>
                          <div className="text-[11px] text-slate-400">{u.facility || 'Central Blood Bank'}</div>
                        </td>

                        <td className="py-3 px-4">
                          <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                            u.isActive ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                          }`}>
                            {u.isActive ? 'Active' : 'Suspended'}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">{u.lastLoginAt || 'Recent'}</td>

                        {/* Action buttons: Edit, Toggle Active, Delete */}
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            
                            <button
                              onClick={() => handleToggleUserStatus(u)}
                              title={u.isActive ? 'Deactivate user' : 'Activate user'}
                              className={`p-1.5 rounded transition-colors cursor-pointer ${
                                u.isActive 
                                  ? 'text-slate-400 hover:text-amber-600 hover:bg-amber-50' 
                                  : 'text-emerald-600 hover:bg-emerald-50'
                              }`}
                            >
                              {u.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                            </button>

                            <button
                              onClick={() => handleOpenEditUser(u)}
                              title="Edit user details & profile picture"
                              className="p-1.5 text-slate-500 hover:text-red-800 hover:bg-red-50 rounded transition-colors cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleOpenDeleteUser(u)}
                              disabled={isSelf}
                              title={isSelf ? 'Cannot delete your active session' : 'Delete user account'}
                              className={`p-1.5 rounded transition-colors ${
                                isSelf 
                                  ? 'text-slate-300 cursor-not-allowed' 
                                  : 'text-slate-400 hover:text-rose-700 hover:bg-rose-50 cursor-pointer'
                              }`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>

                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {filteredUsers.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        No staff members match the selected filter criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-slate-500 text-[11px]">
              <span>Showing {filteredUsers.length} of {users.length} registered system accounts</span>
              <span className="font-mono">RBAC Security Mode: Strict Authorization</span>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: CLINICAL & TRANSFUSION POLICIES (ALL SYSTEM PARAMETERS) */}
      {/* ========================================================================= */}
      {activeTab === 'system' && (
        <form onSubmit={handleSaveSystemSettings} className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          
          {/* Organization Identity */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-red-800" />
              <span>Transfusion Authority & Organization Identity</span>
            </h3>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Transfusion Service Authority Name *</label>
              <input
                type="text"
                required
                value={settings.organizationName}
                onChange={(e) => setSettings({ ...settings, organizationName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Clinical Accreditation & License Registration</label>
              <input
                type="text"
                value={settings.licenseNumber || ''}
                onChange={(e) => setSettings({ ...settings, licenseNumber: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                placeholder="CLIN-REG-2026-NTS88"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Emergency Dispatch Hotline (24/7) *</label>
              <input
                type="tel"
                required
                value={settings.hotlinePhone}
                onChange={(e) => setSettings({ ...settings, hotlinePhone: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Official Clinical Email</label>
              <input
                type="email"
                value={settings.officialEmail || ''}
                onChange={(e) => setSettings({ ...settings, officialEmail: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                placeholder="transfusion-dispatch@lifeblood.org"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Headquarters Campus Address</label>
              <input
                type="text"
                value={settings.headquartersAddress || ''}
                onChange={(e) => setSettings({ ...settings, headquartersAddress: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                placeholder="Building 4, National Health Complex, Clinical Boulevard"
              />
            </div>

            {/* Language & RTL */}
            <div>
              <label className="block font-medium text-slate-700 mb-1">System Language & Localization</label>
              <div className="flex items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setSettings({ ...settings, defaultLanguage: 'en' });
                    if (isArabic) onToggleArabic();
                  }}
                  className={`px-3 py-1.5 rounded-md border font-medium cursor-pointer transition-colors ${
                    !isArabic ? 'bg-red-800 text-white border-red-800' : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  English (LTR)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSettings({ ...settings, defaultLanguage: 'ar' });
                    if (!isArabic) onToggleArabic();
                  }}
                  className={`px-3 py-1.5 rounded-md border font-medium cursor-pointer transition-colors ${
                    isArabic ? 'bg-red-800 text-white border-red-800' : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  العربية (Arabic RTL)
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Immediate bidirectional RTL layout support for Somali, Arabic, and regional centers.
              </p>
            </div>
          </div>

          {/* Operational Safety Policies */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-red-800" />
              <span>Transfusion & Stock Accounting Policies</span>
            </h3>

            <div className="space-y-3 pt-1">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.enableFefo}
                  onChange={(e) => setSettings({ ...settings, enableFefo: e.target.checked })}
                  className="mt-0.5 rounded text-red-800 focus:ring-red-800"
                />
                <div>
                  <span className="font-semibold text-slate-900">Enforce First Expired, First Out (FEFO)</span>
                  <span className="block text-slate-500 text-[11px]">Units nearest expiration are strictly prioritized for issue to reduce clinical blood spoilage.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.autoQuarantineTesting}
                  onChange={(e) => setSettings({ ...settings, autoQuarantineTesting: e.target.checked })}
                  className="mt-0.5 rounded text-red-800 focus:ring-red-800"
                />
                <div>
                  <span className="font-semibold text-slate-900">Mandatory Quarantine on Intake</span>
                  <span className="block text-slate-500 text-[11px]">All fresh collections enter locked quarantine until 4-fold viral screening is validated.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.maintenanceMode || false}
                  onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                  className="mt-0.5 rounded text-red-800 focus:ring-red-800"
                />
                <div>
                  <span className="font-semibold text-slate-900">System Maintenance Mode (Read-Only)</span>
                  <span className="block text-slate-500 text-[11px]">Temporarily locks order modifications for scheduled cold-chain database maintenance.</span>
                </div>
              </label>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Universal O- Emergency Buffer (Units)</label>
                <input
                  type="number"
                  min="5"
                  max="100"
                  value={settings.emergencyONegativeReserve}
                  onChange={(e) => setSettings({ ...settings, emergencyONegativeReserve: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                />
                <span className="text-[11px] text-slate-400 mt-0.5 block">Minimum reserve held strictly for massive transfusion protocol trauma resus.</span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Session Inactivity Timeout (Minutes)</label>
                <input
                  type="number"
                  min="5"
                  max="120"
                  value={settings.sessionTimeoutMinutes}
                  onChange={(e) => setSettings({ ...settings, sessionTimeoutMinutes: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Maximum Failed Login Attempts (Security Lockout)</label>
                <input
                  type="number"
                  min="3"
                  max="10"
                  value={settings.maxFailedLoginAttempts || 5}
                  onChange={(e) => setSettings({ ...settings, maxFailedLoginAttempts: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                <Save className="w-4 h-4" />
                <span>Save Clinical Parameters</span>
              </button>
            </div>
          </div>

        </form>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: DEPARTMENTS & STORAGE LOCATIONS (ADD MANAGEMENT CONFIG) */}
      {/* ========================================================================= */}
      {activeTab === 'management' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          
          {/* Departments Management */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-red-800" />
                <span>Clinical Departments Directory</span>
              </h3>
              <span className="text-slate-400 font-mono text-[11px]">{settings.departments?.length || 7} Registered</span>
            </div>

            <p className="text-slate-500 text-[11px]">
              Add or remove hospital and laboratory operational departments for staff assignment and routing.
            </p>

            {/* Add Department Input */}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="New department name (e.g. Apheresis Unit)..."
                value={newDepartmentName}
                onChange={(e) => setNewDepartmentName(e.target.value)}
                className="flex-1 px-3 py-1.5 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
              />
              <button
                type="button"
                onClick={handleAddDepartment}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5 inline mr-1" />
                Add Dept
              </button>
            </div>

            {/* Departments List */}
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-md overflow-hidden max-h-80 overflow-y-auto">
              {(settings.departments || [
                'Executive Administration',
                'Immunohematology & Viral Serology',
                'Component Separation & Cold Chain',
                'Donor Recruitment & Mobile Drives',
                'Transfusion Clinical Safety',
                'Hospital Distribution & Logistics',
                'Quality Assurance & Regulatory'
              ]).map((dept, index) => (
                <div key={index} className="flex items-center justify-between p-2.5 hover:bg-slate-50 transition-colors">
                  <span className="font-medium text-slate-800">{dept}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveDepartment(dept)}
                    title="Remove department"
                    className="text-slate-400 hover:text-rose-700 p-1 rounded hover:bg-rose-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Storage Locations & Cold Chain Units Management */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-red-800" />
                <span>Cold Storage Units & Freezers</span>
              </h3>
              <span className="text-slate-400 font-mono text-[11px]">{settings.storageLocations?.length || 6} Units</span>
            </div>

            <p className="text-slate-500 text-[11px]">
              Register physical cold rooms, platelet agitators, and ultra-low freezers monitored under cold-chain compliance.
            </p>

            {/* Add Storage Location Input */}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="New storage location (e.g. Cryo Freezer C3)..."
                value={newStorageLocationName}
                onChange={(e) => setNewStorageLocationName(e.target.value)}
                className="flex-1 px-3 py-1.5 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
              />
              <button
                type="button"
                onClick={handleAddStorageLocation}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5 inline mr-1" />
                Add Unit
              </button>
            </div>

            {/* Storage Locations List */}
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-md overflow-hidden max-h-80 overflow-y-auto">
              {(settings.storageLocations || [
                'Main Red Cell Cold Room #1 (FRIDGE-A1)',
                'Emergency O- Reserve Fridge (FRIDGE-A2)',
                'Ultra-Low Plasma Freezer #1 (FREEZER-B1)',
                'Platelet Incubator & Agitator (AGITATOR-C1)',
                'Pre-Testing Quarantine Cooler (QUARANTINE-Q1)',
                'Cryoprecipitate Sub-Zero Box (FREEZER-B2)'
              ]).map((loc, index) => (
                <div key={index} className="flex items-center justify-between p-2.5 hover:bg-slate-50 transition-colors">
                  <span className="font-mono text-slate-800 font-medium">{loc}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveStorageLocation(loc)}
                    title="Remove storage unit"
                    className="text-slate-400 hover:text-rose-700 p-1 rounded hover:bg-rose-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: DATA BACKUP MANAGEMENT (ADD, EDIT, DELETE, RESTORE, DOWNLOAD, IMPORT) */}
      {/* ========================================================================= */}
      {activeTab === 'backup' && (
        <div className="space-y-5 text-xs">
          
          {/* Top Actions: Create Instant Snapshot & Import File */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-4 h-4 text-red-800" />
                <span>Data Backup & Disaster Recovery Center</span>
              </h3>
              <p className="text-slate-500 text-[11px] mt-0.5">
                Create point-in-time database snapshots, edit metadata, download SQL/JSON archives, or restore state.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <input
                type="file"
                ref={backupFileInputRef}
                onChange={handleImportBackupFile}
                accept=".json,.sql"
                className="hidden"
              />

              <button
                type="button"
                onClick={() => backupFileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                <Upload className="w-3.5 h-3.5 text-slate-500" />
                <span>Upload / Import Backup</span>
              </button>

              <button
                type="button"
                onClick={handleOpenCreateBackup}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Backup Snapshot</span>
              </button>
            </div>
          </div>

          {/* Backup Snapshots Table */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-900">Historical Backup Snapshots</span>
              <span className="text-xs text-slate-500 font-mono">{backups.length} Snapshots Available</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                  <tr>
                    <th className="py-3 px-4">Snapshot Name & Notes</th>
                    <th className="py-3 px-4">Snapshot ID</th>
                    <th className="py-3 px-4">Created Date</th>
                    <th className="py-3 px-4">Size & Records</th>
                    <th className="py-3 px-4">Created By</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {backups.map((bkp) => (
                    <tr key={bkp.id} className="hover:bg-slate-50/80 transition-colors">
                      
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{bkp.name}</div>
                        {bkp.notes && (
                          <div className="text-slate-500 text-[11px] truncate max-w-sm mt-0.5">{bkp.notes}</div>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{bkp.id}</td>

                      <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">{bkp.createdAt}</td>

                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-800">{bkp.sizeKb} KB</span>
                        <span className="text-slate-400 text-[11px] block">{bkp.recordCount || 80} records</span>
                      </td>

                      <td className="py-3 px-4 text-slate-600">{bkp.createdBy}</td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Edit Backup */}
                          <button
                            onClick={() => handleOpenEditBackup(bkp)}
                            title="Edit snapshot title & notes"
                            className="p-1.5 text-slate-500 hover:text-red-800 hover:bg-red-50 rounded transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Download JSON */}
                          <button
                            onClick={() => handleDownloadBackup(bkp)}
                            title="Download JSON Snapshot Archive"
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                          >
                            <Download className="w-4 h-4" />
                          </button>

                          {/* Download SQL Dump */}
                          <button
                            onClick={() => handleDownloadSQLDump(bkp)}
                            title="Download MySQL .sql Dump"
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors cursor-pointer font-mono text-[10px] font-bold"
                          >
                            SQL
                          </button>

                          {/* Restore */}
                          <button
                            onClick={() => handleOpenRestoreBackup(bkp)}
                            title="Restore system data to this snapshot"
                            className="p-1.5 text-amber-700 hover:text-amber-900 hover:bg-amber-50 rounded transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => handleOpenDeleteBackup(bkp)}
                            title="Delete snapshot"
                            className="p-1.5 text-slate-400 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                        </div>
                      </td>

                    </tr>
                  ))}

                  {backups.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        No backup snapshots created yet. Click "Create New Backup Snapshot" to capture current state.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between text-slate-500 text-[11px] gap-2">
              <span>Automatic XAMPP Daily cron scheduled at 04:00 AM UTC</span>
              <span className="font-mono text-emerald-700 font-semibold">Integrity: SHA-256 Verified</span>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: ADD NEW USER */}
      {/* ========================================================================= */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-lg p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-red-800" />
                <span>Provision New Staff User Account</span>
              </h3>
              <button onClick={() => setShowAddUserModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAddUser} className="space-y-4">
              
              {/* Profile Picture Uploader */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <ProfilePictureUploader
                  currentAvatarUrl={formAvatarUrl}
                  userName={formName || 'New User'}
                  onChange={(url) => setFormAvatarUrl(url)}
                  size="md"
                  label="User Profile Picture"
                  helpText="Upload a staff photo or pick a medical role preset avatar."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Omar Barre"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Official Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="omar.barre@lifeblood.org"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Direct Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+1-555-882-9011"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Job Designation</label>
                  <input
                    type="text"
                    placeholder="Senior Immunohematologist"
                    value={formJobTitle}
                    onChange={(e) => setFormJobTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">RBAC System Role *</label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as RoleSlug)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-medium"
                  >
                    <option value="super-admin">Super Administrator</option>
                    <option value="blood-bank-admin">Blood Bank Administrator</option>
                    <option value="blood-bank-tech">Blood Bank Technician</option>
                    <option value="lab-tech">Laboratory Technician</option>
                    <option value="donor-officer">Donor Registration Officer</option>
                    <option value="hospital-officer">Hospital Requesting Officer</option>
                    <option value="report-viewer">Report Viewer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Department</label>
                  <select
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white"
                  >
                    {(settings.departments || [
                      'Executive Administration',
                      'Immunohematology & Viral Serology',
                      'Component Separation & Cold Chain',
                      'Donor Recruitment & Mobile Drives',
                      'Transfusion Clinical Safety',
                      'Hospital Distribution & Logistics',
                      'Quality Assurance & Regulatory'
                    ]).map((dept, i) => (
                      <option key={i} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">Assigned Facility</label>
                  <input
                    type="text"
                    value={formFacility}
                    onChange={(e) => setFormFacility(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                    placeholder="Central Blood Bank"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsActive}
                    onChange={(e) => setFormIsActive(e.target.checked)}
                    className="rounded text-red-800 focus:ring-red-800"
                  />
                  <span className="font-semibold text-slate-800">Account Active Immediately</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddUserModal(false)}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                  >
                    Create User
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EDIT USER (FULL DETAILS + PICTURE UPLOADER) */}
      {/* ========================================================================= */}
      {showEditUserModal && selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-lg p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-red-800" />
                  <span>Edit Staff Account Details</span>
                </h3>
                <div className="text-[11px] text-slate-500 font-mono">{selectedUser.staffId}</div>
              </div>
              <button onClick={() => setShowEditUserModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditUser} className="space-y-4">
              
              {/* Profile Picture Uploader */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <ProfilePictureUploader
                  currentAvatarUrl={formAvatarUrl}
                  userName={formName || selectedUser.name}
                  onChange={(url) => setFormAvatarUrl(url)}
                  size="md"
                  label="Update Profile Picture"
                  helpText="Upload a new photo or select from clinical presets."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Official Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Direct Phone</label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Job Designation</label>
                  <input
                    type="text"
                    value={formJobTitle}
                    onChange={(e) => setFormJobTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">RBAC System Role *</label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as RoleSlug)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-medium"
                  >
                    <option value="super-admin">Super Administrator</option>
                    <option value="blood-bank-admin">Blood Bank Administrator</option>
                    <option value="blood-bank-tech">Blood Bank Technician</option>
                    <option value="lab-tech">Laboratory Technician</option>
                    <option value="donor-officer">Donor Registration Officer</option>
                    <option value="hospital-officer">Hospital Requesting Officer</option>
                    <option value="report-viewer">Report Viewer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Department</label>
                  <select
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white"
                  >
                    {(settings.departments || [
                      'Executive Administration',
                      'Immunohematology & Viral Serology',
                      'Component Separation & Cold Chain',
                      'Donor Recruitment & Mobile Drives',
                      'Transfusion Clinical Safety',
                      'Hospital Distribution & Logistics',
                      'Quality Assurance & Regulatory'
                    ]).map((dept, i) => (
                      <option key={i} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">Assigned Facility</label>
                  <input
                    type="text"
                    value={formFacility}
                    onChange={(e) => setFormFacility(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsActive}
                    onChange={(e) => setFormIsActive(e.target.checked)}
                    className="rounded text-red-800 focus:ring-red-800"
                  />
                  <span className="font-semibold text-slate-800">Account Active</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowEditUserModal(false)}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                  >
                    Save Changes
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DELETE USER CONFIRMATION */}
      {/* ========================================================================= */}
      {showDeleteUserModal && selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md p-6 space-y-4 text-xs animate-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="p-2 bg-rose-50 rounded-full">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Confirm Account Deletion</h3>
                <div className="text-[11px] text-slate-500">Security Governance Protocol</div>
              </div>
            </div>

            <p className="text-slate-600">
              Are you sure you want to permanently remove the staff account for{' '}
              <strong className="text-slate-900">{selectedUser.name}</strong> ({selectedUser.staffId})?
            </p>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-1">
              <div><strong>Role:</strong> {selectedUser.roleName}</div>
              <div><strong>Email:</strong> <span className="font-mono">{selectedUser.email}</span></div>
              <div><strong>Department:</strong> {selectedUser.department}</div>
            </div>

            <div className="text-[11px] text-rose-600 font-medium">
              This action will be permanently recorded in immutable audit logs.
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteUserModal(false)}
                className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteUser}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-700 hover:bg-rose-800 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                Permanently Delete User
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE BACKUP SNAPSHOT (ADD DATA BACKUP) */}
      {/* ========================================================================= */}
      {showCreateBackupModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md p-6 space-y-4 text-xs animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-red-800" />
                <span>Create Database Backup Snapshot</span>
              </h3>
              <button onClick={() => setShowCreateBackupModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmCreateBackup} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Snapshot Label / Title *</label>
                <input
                  type="text"
                  required
                  value={backupFormName}
                  onChange={(e) => setBackupFormName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  placeholder="e.g. Pre-Upgrade Full System State"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Operational Notes / Reason</label>
                <textarea
                  rows={3}
                  value={backupFormNotes}
                  onChange={(e) => setBackupFormNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                  placeholder="Describe reason for this snapshot..."
                />
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md text-[11px] text-slate-600 space-y-1">
                <div className="font-semibold text-slate-800">Included In Snapshot:</div>
                <div>• All registered staff & RBAC governance roles ({users.length} accounts)</div>
                <div>• Complete blood donor registry and vitals screenings</div>
                <div>• Real-time blood inventory, quarantine units, and barcodes</div>
                <div>• Hospital requests, issue manifests, and cold-chain dispatches</div>
                <div>• Audit logs and system parameters</div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateBackupModal(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                >
                  Generate Snapshot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EDIT BACKUP SNAPSHOT (EDIT DATA BACKUP) */}
      {/* ========================================================================= */}
      {showEditBackupModal && selectedBackup && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md p-6 space-y-4 text-xs animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-red-800" />
                <span>Edit Backup Metadata</span>
              </h3>
              <button onClick={() => setShowEditBackupModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmEditBackup} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Snapshot Label *</label>
                <input
                  type="text"
                  required
                  value={backupFormName}
                  onChange={(e) => setBackupFormName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Notes / Changelog</label>
                <textarea
                  rows={3}
                  value={backupFormNotes}
                  onChange={(e) => setBackupFormNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800"
                />
              </div>

              <div className="text-[11px] text-slate-500 font-mono">
                ID: {selectedBackup.id} · Created: {selectedBackup.createdAt}
              </div>

              <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditBackupModal(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                >
                  Save Metadata
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DELETE BACKUP SNAPSHOT (DELETE DATA BACKUP) */}
      {/* ========================================================================= */}
      {showDeleteBackupModal && selectedBackup && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md p-6 space-y-4 text-xs animate-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="p-2 bg-rose-50 rounded-full">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Backup Snapshot</h3>
                <div className="text-[11px] text-slate-500">Disaster Recovery Archive</div>
              </div>
            </div>

            <p className="text-slate-600">
              Are you sure you want to delete backup snapshot{' '}
              <strong className="text-slate-900">"{selectedBackup.name}"</strong>?
            </p>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-md text-[11px] space-y-1 font-mono text-slate-700">
              <div>ID: {selectedBackup.id}</div>
              <div>Created: {selectedBackup.createdAt}</div>
              <div>Size: {selectedBackup.sizeKb} KB ({selectedBackup.recordCount || 80} records)</div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteBackupModal(false)}
                className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteBackup}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-700 hover:bg-rose-800 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                Delete Snapshot
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: RESTORE BACKUP SNAPSHOT */}
      {/* ========================================================================= */}
      {showRestoreBackupModal && selectedBackup && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md p-6 space-y-4 text-xs animate-in zoom-in-95">
            <div className="flex items-center gap-3 text-amber-700">
              <div className="p-2 bg-amber-50 rounded-full">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Restore System State</h3>
                <div className="text-[11px] text-slate-500">Database Rollback Protocol</div>
              </div>
            </div>

            <p className="text-slate-600">
              This will restore all active records, donors, inventory units, and clinical settings to the point in time when snapshot{' '}
              <strong className="text-slate-900">"{selectedBackup.name}"</strong> was created.
            </p>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-800 text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Notice on Database Rollback:</span>
              </div>
              <div>Current live transactions added after {selectedBackup.createdAt} will be overwritten by this snapshot.</div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowRestoreBackupModal(false)}
                className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRestoreBackup}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-amber-700 hover:bg-amber-800 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                Confirm & Restore State
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
