import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  Plus, 
  Download, 
  Printer, 
  AlertCircle, 
  CheckCircle, 
  Phone, 
  Mail, 
  Calendar, 
  MapPin, 
  X,
  CreditCard,
  QrCode,
  ShieldCheck
} from 'lucide-react';
import { Donor, BloodGroup } from '../../types';
import { StorageService } from '../../services/storage';

export const DonorManagement: React.FC = () => {
  const [donors, setDonors] = useState<Donor[]>(StorageService.getDonors());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedDonor, setSelectedDonor] = useState<Donor | null>(null);
  
  // Modals
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showPrintCardModal, setShowPrintCardModal] = useState<Donor | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Form State for new registration
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    nationalId: '',
    dateOfBirth: '1995-05-15',
    sex: 'Male' as 'Male' | 'Female' | 'Other',
    bloodGroup: 'O+' as BloodGroup,
    phone: '',
    email: '',
    address: '',
    city: 'Capital City',
    emergencyContactName: '',
    emergencyContactPhone: '',
    preferredContact: 'SMS' as 'SMS' | 'Email' | 'Phone'
  });

  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  // Filtered donors
  const filteredDonors = donors.filter(d => {
    const q = searchQuery.toLowerCase();
    const matchesSearch = 
      d.firstName.toLowerCase().includes(q) ||
      d.lastName.toLowerCase().includes(q) ||
      d.donorNumber.toLowerCase().includes(q) ||
      d.phone.includes(q) ||
      d.nationalId.toLowerCase().includes(q);

    const matchesGroup = selectedGroup === 'all' || d.bloodGroup === selectedGroup;
    const matchesStatus = selectedStatus === 'all' || d.status === selectedStatus;

    return matchesSearch && matchesGroup && matchesStatus;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.firstName || !formData.lastName || !formData.phone || !formData.nationalId) {
      setErrorMessage('Please fill in all required clinical identification fields.');
      return;
    }

    const res = StorageService.saveDonor(formData);
    if (!res.success) {
      setErrorMessage(res.error || 'Registration failed');
      return;
    }

    setDonors(StorageService.getDonors());
    setSuccessMessage(`Donor registered successfully: ${res.donor?.donorNumber}`);
    setShowRegisterModal(false);
    // Reset form
    setFormData({
      firstName: '',
      lastName: '',
      nationalId: '',
      dateOfBirth: '1995-05-15',
      sex: 'Male',
      bloodGroup: 'O+',
      phone: '',
      email: '',
      address: '',
      city: 'Capital City',
      emergencyContactName: '',
      emergencyContactPhone: '',
      preferredContact: 'SMS'
    });
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  const exportCSV = () => {
    const headers = ['Donor Number', 'First Name', 'Last Name', 'National ID', 'Blood Group', 'Phone', 'Status', 'Total Donations', 'Last Donation'];
    const rows = filteredDonors.map(d => [
      d.donorNumber,
      `"${d.firstName}"`,
      `"${d.lastName}"`,
      d.nationalId,
      d.bloodGroup,
      d.phone,
      d.status,
      d.totalDonations,
      d.lastDonationDate || 'None'
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LifeBlood_Donors_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>Donor Registry</span>
            <span aria-hidden="true">·</span>
            <span>{filteredDonors.length} Records</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Donor Management & Registry
          </h1>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowRegisterModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Register New Donor</span>
          </button>
        </div>
      </div>

      {/* Alert Messages */}
      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 border border-slate-200 rounded-lg shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by donor ID, name, national ID, or phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-red-800"
          />
        </div>

        {/* Blood Group Filter */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 whitespace-nowrap">Blood Group:</span>
          <select
            value={selectedGroup}
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white focus:outline-none focus:ring-1 focus:ring-red-800 cursor-pointer"
          >
            <option value="all">All Groups</option>
            {bloodGroups.map(bg => (
              <option key={bg} value={bg}>{bg}</option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 whitespace-nowrap">Status:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white focus:outline-none focus:ring-1 focus:ring-red-800 cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="Active">Active Eligible</option>
            <option value="Temporarily Deferred">Temporarily Deferred</option>
            <option value="Permanently Deferred">Permanently Deferred</option>
          </select>
        </div>
      </div>

      {/* Donor Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Donor ID</th>
                <th className="py-3 px-4">Full Name</th>
                <th className="py-3 px-4">ABO / RhD</th>
                <th className="py-3 px-4">National ID</th>
                <th className="py-3 px-4">Phone</th>
                <th className="py-3 px-4">Total Donations</th>
                <th className="py-3 px-4">Last Donated</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDonors.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No registered donors found matching your search criteria.
                  </td>
                </tr>
              ) : (
                filteredDonors.map(donor => (
                  <tr key={donor.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{donor.donorNumber}</td>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {donor.firstName} {donor.lastName}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      <span className="px-2 py-0.5 bg-red-50 text-red-900 rounded border border-red-200">
                        {donor.bloodGroup}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">{donor.nationalId}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{donor.phone}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-700">{donor.totalDonations}</td>
                    <td className="py-3 px-4 text-slate-600">{donor.lastDonationDate || 'First time'}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                        donor.status === 'Active' ? 'bg-emerald-50 text-emerald-800' :
                        donor.status === 'Temporarily Deferred' ? 'bg-amber-50 text-amber-800' :
                        'bg-red-50 text-red-800'
                      }`}>
                        {donor.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => setSelectedDonor(donor)}
                        className="text-xs text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
                      >
                        Profile
                      </button>
                      <button
                        onClick={() => setShowPrintCardModal(donor)}
                        className="text-xs text-red-800 hover:underline font-semibold cursor-pointer"
                      >
                        Print Card
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Register New Donor Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-semibold text-slate-900">New Donor Registration</h3>
                <div className="text-xs text-slate-500">Record clinical intake with duplicate prevention checks</div>
              </div>
              <button 
                onClick={() => setShowRegisterModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                    placeholder="e.g. Abdi"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                    placeholder="e.g. Warsame"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">National ID / Passport Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.nationalId}
                    onChange={(e) => setFormData({ ...formData, nationalId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none font-mono"
                    placeholder="e.g. NAT-8829104"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Date of Birth *</label>
                  <input
                    type="date"
                    required
                    value={formData.dateOfBirth}
                    onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Biological Sex *</label>
                  <select
                    value={formData.sex}
                    onChange={(e) => setFormData({ ...formData, sex: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none bg-white cursor-pointer"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Declared Blood Group & RhD *</label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none bg-white cursor-pointer font-bold"
                  >
                    {bloodGroups.map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Phone Number (SMS Notifications) *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none font-mono"
                    placeholder="e.g. +1-555-201-9988"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                    placeholder="e.g. abdi@example.com"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">Residential Address *</label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                    placeholder="e.g. 14 Ocean View Avenue"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Emergency Contact Person</label>
                  <input
                    type="text"
                    value={formData.emergencyContactName}
                    onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none"
                    placeholder="e.g. Hodan Warsame"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Emergency Contact Phone</label>
                  <input
                    type="tel"
                    value={formData.emergencyContactPhone}
                    onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-red-800 focus:outline-none font-mono"
                    placeholder="e.g. +1-555-201-9989"
                  />
                </div>
              </div>

              {/* Informed Consent Checkbox */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-2.5 text-xs text-slate-600">
                <input
                  type="checkbox"
                  id="consent"
                  defaultChecked
                  required
                  className="mt-0.5 rounded text-red-800 focus:ring-red-800 cursor-pointer"
                />
                <label htmlFor="consent" className="cursor-pointer">
                  <span className="font-semibold text-slate-800">Informed Voluntary Consent:</span> The donor confirms they are donating blood voluntarily, have read the health risks, and consent to mandatory infectious disease testing (HIV, Hepatitis B, Hepatitis C, Syphilis).
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Complete Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Complete Donor Profile Drawer */}
      {selectedDonor && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-full max-w-lg h-full shadow-2xl p-6 overflow-y-auto space-y-5 animate-in slide-in-from-right duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="text-xs text-slate-500 font-mono">{selectedDonor.donorNumber}</span>
                <h2 className="text-xl font-bold text-slate-900">{selectedDonor.firstName} {selectedDonor.lastName}</h2>
              </div>
              <button 
                onClick={() => setSelectedDonor(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Status Tag & Blood Group Banner */}
            <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-lg">
              <div>
                <div className="text-xs text-slate-500">Blood Group (ABO/Rh)</div>
                <div className="text-3xl font-extrabold text-red-900 font-mono mt-0.5">{selectedDonor.bloodGroup}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">Clinical Status</div>
                <div className="text-sm font-semibold text-emerald-800 mt-0.5">{selectedDonor.status}</div>
              </div>
            </div>

            {/* Donor Information Grid */}
            <div className="space-y-3 text-xs">
              <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">Personal Demographics</h3>
              <div className="grid grid-cols-2 gap-3 p-3 bg-white border border-slate-200 rounded-lg">
                <div>
                  <div className="text-slate-400">Date of Birth</div>
                  <div className="font-medium text-slate-800 mt-0.5">{selectedDonor.dateOfBirth}</div>
                </div>
                <div>
                  <div className="text-slate-400">Biological Sex</div>
                  <div className="font-medium text-slate-800 mt-0.5">{selectedDonor.sex}</div>
                </div>
                <div>
                  <div className="text-slate-400">National ID</div>
                  <div className="font-mono text-slate-800 mt-0.5">{selectedDonor.nationalId}</div>
                </div>
                <div>
                  <div className="text-slate-400">City</div>
                  <div className="font-medium text-slate-800 mt-0.5">{selectedDonor.city}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-slate-400">Address</div>
                  <div className="font-medium text-slate-800 mt-0.5">{selectedDonor.address}</div>
                </div>
              </div>
            </div>

            {/* Contact Details */}
            <div className="space-y-3 text-xs">
              <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">Communications & Emergency</h3>
              <div className="space-y-2 p-3 bg-white border border-slate-200 rounded-lg">
                <div className="flex items-center gap-2 text-slate-700">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span className="font-mono">{selectedDonor.phone}</span>
                </div>
                {selectedDonor.email && (
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>{selectedDonor.email}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-100">
                  <div className="text-slate-400">Emergency Contact:</div>
                  <div className="font-medium text-slate-800">{selectedDonor.emergencyContactName} ({selectedDonor.emergencyContactPhone})</div>
                </div>
              </div>
            </div>

            {/* Donation Records */}
            <div className="space-y-3 text-xs">
              <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">Donation History</h3>
              <div className="grid grid-cols-3 gap-2 text-center p-3 bg-white border border-slate-200 rounded-lg">
                <div>
                  <div className="text-slate-400 text-[10px]">Total Collections</div>
                  <div className="text-lg font-bold font-mono text-slate-900 mt-0.5">{selectedDonor.totalDonations}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Last Donated</div>
                  <div className="text-xs font-semibold text-slate-800 mt-1">{selectedDonor.lastDonationDate || 'None'}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Next Eligible</div>
                  <div className="text-xs font-semibold text-emerald-700 mt-1">{selectedDonor.nextEligibleDate || 'Eligible Now'}</div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-slate-200 flex items-center gap-3">
              <button
                onClick={() => {
                  setShowPrintCardModal(selectedDonor);
                  setSelectedDonor(null);
                }}
                className="w-full py-2.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Donor Identification Card</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Donor Card Modal */}
      {showPrintCardModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 bg-slate-50 no-print">
              <span className="text-xs font-semibold text-slate-900">Official Donor Identification Card</span>
              <button 
                onClick={() => setShowPrintCardModal(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Physical Card Area */}
            <div className="p-6 printable-area bg-white">
              <div className="border-2 border-red-800 rounded-xl p-5 bg-gradient-to-br from-red-50/30 to-white shadow-xs relative overflow-hidden">
                <div className="flex items-center justify-between pb-3 border-b border-red-100">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-md bg-red-800 text-white flex items-center justify-center font-bold text-xs">
                      LB
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 leading-tight">LifeBlood Authority</div>
                      <div className="text-[9px] text-slate-500 uppercase tracking-widest">National Blood Donor Card</div>
                    </div>
                  </div>
                  <div className="text-2xl font-black font-mono text-red-900 px-2 py-0.5 bg-red-100 rounded border border-red-200">
                    {showPrintCardModal.bloodGroup}
                  </div>
                </div>

                <div className="py-4 space-y-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Donor Name</span>
                    <span className="text-base font-bold text-slate-900">{showPrintCardModal.firstName} {showPrintCardModal.lastName}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">Donor Number</span>
                      <span className="font-bold text-slate-800">{showPrintCardModal.donorNumber}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-sans">National ID</span>
                      <span className="font-bold text-slate-800">{showPrintCardModal.nationalId}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="text-[10px] text-slate-500">
                      Emergency Contact: <span className="font-semibold text-slate-700">{showPrintCardModal.emergencyContactPhone}</span>
                    </div>
                  </div>
                </div>

                {/* Simulated Barcode and Security Seal */}
                <div className="pt-3 border-t border-red-100 flex items-center justify-between">
                  <div className="font-mono text-[9px] text-slate-400">
                    ||| | ||||| || |||| |||| || | |||||
                    <div className="tracking-wider">{showPrintCardModal.donorNumber}</div>
                  </div>
                  <div className="text-[9px] text-emerald-700 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified Donor
                  </div>
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3 no-print">
              <button
                onClick={() => setShowPrintCardModal(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-md cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Card</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
