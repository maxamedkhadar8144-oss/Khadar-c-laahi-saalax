import React, { useState } from 'react';
import { 
  PackageCheck, 
  Search, 
  Filter, 
  Barcode, 
  Trash2, 
  ArrowRightLeft, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  X,
  Thermometer,
  ShieldAlert
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { BloodUnit, ComponentCode, BloodGroup, UnitStatus } from '../../types';

export const InventoryManagement: React.FC = () => {
  const [units, setUnits] = useState<BloodUnit[]>(StorageService.getBloodUnits());
  const [searchBarcode, setSearchBarcode] = useState('');
  const [selectedComponent, setSelectedComponent] = useState<string>('all');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'fefo' | 'fifo' | 'barcode'>('fefo');

  // Modals
  const [selectedUnit, setSelectedUnit] = useState<BloodUnit | null>(null);
  const [discardModalUnit, setDiscardModalUnit] = useState<BloodUnit | null>(null);
  const [discardReason, setDiscardReason] = useState('Expired beyond approved shelf-life');
  const [successMessage, setSuccessMessage] = useState('');

  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const components: ComponentCode[] = ['WB', 'PRBC', 'PLT', 'FFP', 'CRYO'];

  // Filter & Sort
  const filteredUnits = units.filter(u => {
    const matchesSearch = 
      u.unitBarcode.toLowerCase().includes(searchBarcode.toLowerCase()) ||
      u.donationNumber.toLowerCase().includes(searchBarcode.toLowerCase());

    const matchesComp = selectedComponent === 'all' || u.componentCode === selectedComponent;
    const matchesGroup = selectedGroup === 'all' || u.bloodGroup === selectedGroup;
    const matchesStatus = selectedStatus === 'all' || u.status === selectedStatus;

    return matchesSearch && matchesComp && matchesGroup && matchesStatus;
  }).sort((a, b) => {
    if (sortBy === 'fefo') {
      return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
    }
    if (sortBy === 'fifo') {
      return new Date(a.collectionDate).getTime() - new Date(b.collectionDate).getTime();
    }
    return a.unitBarcode.localeCompare(b.unitBarcode);
  });

  const handleDiscard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!discardModalUnit) return;

    discardModalUnit.status = 'Discarded';
    discardModalUnit.discardReason = discardReason;

    const allUnits = StorageService.getBloodUnits();
    const idx = allUnits.findIndex(u => u.id === discardModalUnit.id);
    if (idx >= 0) {
      allUnits[idx] = { ...discardModalUnit };
      localStorage.setItem('lifeblood_units', JSON.stringify(allUnits));
      StorageService.logAudit('Blood Unit Discarded', 'Inventory', discardModalUnit.unitBarcode, `Unit discarded: ${discardReason}`);
    }

    setUnits(StorageService.getBloodUnits());
    setSuccessMessage(`Unit ${discardModalUnit.unitBarcode} recorded as Discarded / Spoilage.`);
    setDiscardModalUnit(null);
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>Stock Ledger</span>
            <span aria-hidden="true">·</span>
            <span>FEFO Enforced Protocol</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Blood Stock & FEFO Inventory Register
          </h1>
        </div>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Filter & Search Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 bg-white p-3 border border-slate-200 rounded-lg shadow-xs">
        
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search barcode or donation #..."
            value={searchBarcode}
            onChange={(e) => setSearchBarcode(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-red-800"
          />
        </div>

        {/* Component */}
        <div>
          <select
            value={selectedComponent}
            onChange={(e) => setSelectedComponent(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white cursor-pointer"
          >
            <option value="all">All Components</option>
            {components.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        {/* Blood Group */}
        <div>
          <select
            value={selectedGroup}
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white cursor-pointer"
          >
            <option value="all">All ABO Groups</option>
            {bloodGroups.map(bg => (
              <option key={bg} value={bg}>{bg}</option>
            ))}
          </select>
        </div>

        {/* Status */}
        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="Released">Released (Available)</option>
            <option value="Quarantined">Quarantined</option>
            <option value="Reserved">Reserved</option>
            <option value="Issued">Issued</option>
            <option value="Expired">Expired</option>
            <option value="Discarded">Discarded</option>
            <option value="Recalled">Recalled</option>
          </select>
        </div>

        {/* Sorting Engine (FEFO vs FIFO) */}
        <div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white font-medium cursor-pointer"
          >
            <option value="fefo">FEFO: First Expired, First Out</option>
            <option value="fifo">FIFO: First In, First Out</option>
            <option value="barcode">Barcode Order</option>
          </select>
        </div>

      </div>

      {/* Inventory Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Barcode</th>
                <th className="py-3 px-4">Component</th>
                <th className="py-3 px-4">ABO/Rh</th>
                <th className="py-3 px-4">Volume</th>
                <th className="py-3 px-4">Expiry Date (FEFO)</th>
                <th className="py-3 px-4">Storage Equipment</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUnits.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No units matching active filters.
                  </td>
                </tr>
              ) : (
                filteredUnits.map(unit => {
                  const now = new Date();
                  const exp = new Date(unit.expiryDate);
                  const isExpiringSoon = exp > now && exp.getTime() - now.getTime() < 7 * 24 * 3600 * 1000;
                  const isExpired = exp <= now && unit.status !== 'Issued' && unit.status !== 'Discarded';

                  return (
                    <tr key={unit.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                        <Barcode className="w-4 h-4 text-slate-400" />
                        <span>{unit.unitBarcode}</span>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">{unit.componentName}</td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{unit.bloodGroup}</td>
                      <td className="py-3 px-4 font-mono tabular-nums">{unit.volumeMl} ml</td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {unit.expiryDate.split('T')[0]}
                        {isExpiringSoon && (
                          <span className="ml-1.5 text-[10px] text-amber-700 font-semibold bg-amber-50 px-1 py-0.5 rounded">
                            $\le 7$d
                          </span>
                        )}
                        {isExpired && (
                          <span className="ml-1.5 text-[10px] text-red-700 font-semibold bg-red-50 px-1 py-0.5 rounded">
                            EXPIRED
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-600 truncate max-w-xs">{unit.storageLocation}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                          unit.status === 'Released' ? 'bg-emerald-50 text-emerald-800' :
                          unit.status === 'Quarantined' ? 'bg-amber-100 text-amber-900' :
                          unit.status === 'Reserved' ? 'bg-blue-50 text-blue-800' :
                          unit.status === 'Issued' ? 'bg-slate-100 text-slate-700' :
                          'bg-red-50 text-red-800'
                        }`}>
                          {unit.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => setSelectedUnit(unit)}
                          className="text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
                        >
                          Details
                        </button>
                        {unit.status !== 'Discarded' && unit.status !== 'Issued' && (
                          <button
                            onClick={() => setDiscardModalUnit(unit)}
                            className="text-red-700 hover:text-red-900 font-medium cursor-pointer"
                          >
                            Discard
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unit Details Modal */}
      {selectedUnit && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="text-xs text-slate-400 font-mono">Unit Barcode</span>
                <h3 className="text-base font-bold text-slate-900 font-mono">{selectedUnit.unitBarcode}</h3>
              </div>
              <button 
                onClick={() => setSelectedUnit(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Component:</span>
                <span className="font-semibold text-slate-800">{selectedUnit.componentName} ({selectedUnit.componentCode})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">ABO & RhD Group:</span>
                <span className="font-bold text-red-900 font-mono">{selectedUnit.bloodGroup}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Volume:</span>
                <span className="font-mono">{selectedUnit.volumeMl} ml</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Parent Donation No.:</span>
                <span className="font-mono">{selectedUnit.donationNumber}</span>
              </div>
              {selectedUnit.parentUnitBarcode && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Parent Whole Blood Unit:</span>
                  <span className="font-mono text-slate-800">{selectedUnit.parentUnitBarcode}</span>
                </div>
              )}
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Collection Date:</span>
                <span className="font-mono">{selectedUnit.collectionDate.replace('T', ' ').substring(0, 16)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Expiration Date:</span>
                <span className="font-mono">{selectedUnit.expiryDate.replace('T', ' ').substring(0, 16)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Storage Location:</span>
                <span className="text-slate-800 font-medium">{selectedUnit.storageLocation}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Current Status:</span>
                <span className="font-bold text-slate-800">{selectedUnit.status}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setSelectedUnit(null)}
                className="w-full py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Discard / Spoilage Modal */}
      {discardModalUnit && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-sm p-6 space-y-4">
            <div className="flex items-center gap-2 text-red-800 font-bold text-sm">
              <Trash2 className="w-4 h-4" />
              <span>Record Stock Discard / Wastage</span>
            </div>
            <p className="text-xs text-slate-500">
              Unit <strong className="font-mono text-slate-900">{discardModalUnit.unitBarcode}</strong> will be moved out of active stock and logged as medical bio-waste.
            </p>

            <form onSubmit={handleDiscard} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Reason for Disposal *</label>
                <select
                  value={discardReason}
                  onChange={(e) => setDiscardReason(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white cursor-pointer"
                >
                  <option value="Expired beyond approved shelf-life">Expired beyond approved shelf-life</option>
                  <option value="Clotting or abnormal appearance detected">Clotting or abnormal appearance detected</option>
                  <option value="Cold chain rupture / Temperature excursion">Cold chain rupture / Temperature excursion</option>
                  <option value="Collection bag leak or port damage">Collection bag leak or port damage</option>
                  <option value="Positive / reactive viral serology">Positive / reactive viral serology</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDiscardModalUnit(null)}
                  className="px-3 py-1.5 font-semibold text-slate-600 bg-white border border-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer"
                >
                  Confirm Discard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
