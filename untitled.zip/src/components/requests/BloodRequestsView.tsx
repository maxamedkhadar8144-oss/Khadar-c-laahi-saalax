import React, { useState } from 'react';
import { 
  ClipboardList, 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Clock, 
  Building2, 
  ShieldCheck,
  Check,
  Ban,
  ArrowRight
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { BloodRequest, BloodGroup, ComponentCode, User, BloodUnit } from '../../types';

interface BloodRequestsViewProps {
  currentUser: User;
  onNavigate: (view: string) => void;
}

export const BloodRequestsView: React.FC<BloodRequestsViewProps> = ({ currentUser, onNavigate }) => {
  const [requests, setRequests] = useState<BloodRequest[]>(StorageService.getBloodRequests());
  const [hospitals] = useState(StorageService.getHospitals());
  const [units] = useState(StorageService.getBloodUnits());

  const [showNewModal, setShowNewModal] = useState(false);
  const [selectedReq, setSelectedReq] = useState<BloodRequest | null>(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Form state
  const [hospitalId, setHospitalId] = useState<number>(hospitals[0]?.id || 1);
  const [clinicianName, setClinicianName] = useState(currentUser.name);
  const [clinicianPhone, setClinicianPhone] = useState('+1-555-882-1044');
  const [patientRef, setPatientRef] = useState('');
  const [patientMasked, setPatientMasked] = useState('');
  const [patientGroup, setPatientGroup] = useState<BloodGroup>('O-');
  const [componentCode, setComponentCode] = useState<ComponentCode>('PRBC');
  const [unitsRequested, setUnitsRequested] = useState<number>(2);
  const [clinicalIndication, setClinicalIndication] = useState('');
  const [priority, setPriority] = useState<'Routine' | 'Urgent' | 'Emergency'>('Urgent');

  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const components: ComponentCode[] = ['WB', 'PRBC', 'PLT', 'FFP', 'CRYO'];

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!patientRef || !clinicalIndication) {
      setErrorMessage('Please provide patient reference ID and clinical indication.');
      return;
    }

    const hosp = hospitals.find(h => h.id === hospitalId);

    const res = StorageService.saveBloodRequest({
      hospitalId,
      hospitalName: hosp?.name || 'St. Jude General Hospital',
      requestingClinician: clinicianName,
      clinicianPhone,
      patientReference: patientRef,
      patientNameMasked: patientMasked || 'Patient Confidential',
      patientBloodGroup: patientGroup,
      componentCode,
      unitsRequested,
      clinicalIndication,
      priority,
      status: 'Submitted'
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Failed to submit blood request.');
      return;
    }

    setRequests(StorageService.getBloodRequests());
    setSuccessMessage(`Hospital requisition ${res.request?.requestNumber} submitted successfully.`);
    setShowNewModal(false);
    // Reset
    setPatientRef('');
    setPatientMasked('');
    setClinicalIndication('');
    setTimeout(() => setSuccessMessage(''), 5000);
  };

  const handleApproveAndReserve = (req: BloodRequest) => {
    // Find eligible available units matching group and component
    const available = units.filter(u => u.bloodGroup === req.patientBloodGroup && u.componentCode === req.componentCode && u.status === 'Released');
    
    if (available.length < req.unitsRequested && req.priority !== 'Emergency') {
      alert(`Stock Shortage Notice: Only ${available.length} units of ${req.patientBloodGroup} ${req.componentCode} are currently in Available status. Approving partial availability.`);
    }

    // Reserve up to requested count
    const toReserve = available.slice(0, req.unitsRequested);
    toReserve.forEach(u => {
      u.status = 'Reserved';
      u.reservedForRequestId = req.id;
    });

    req.status = 'Approved';
    req.reservedUnitBarcodes = toReserve.map(r => r.unitBarcode);

    const allReqs = StorageService.getBloodRequests();
    const idx = allReqs.findIndex(r => r.id === req.id);
    if (idx >= 0) {
      allReqs[idx] = { ...req };
      localStorage.setItem('lifeblood_requests', JSON.stringify(allReqs));
      localStorage.setItem('lifeblood_units', JSON.stringify(units));
      StorageService.logAudit('Blood Request Approved & Reserved', 'Requests', req.requestNumber, `Approved ${req.requestNumber}: ${toReserve.length} units reserved.`);
    }

    setRequests(StorageService.getBloodRequests());
    setSuccessMessage(`Request ${req.requestNumber} approved: ${toReserve.length} units reserved in cold storage.`);
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  const handleReject = (req: BloodRequest) => {
    const reason = prompt('Please specify the clinical reason for rejecting this blood requisition:');
    if (!reason) return;

    req.status = 'Rejected';
    req.rejectionReason = reason;

    const allReqs = StorageService.getBloodRequests();
    const idx = allReqs.findIndex(r => r.id === req.id);
    if (idx >= 0) {
      allReqs[idx] = { ...req };
      localStorage.setItem('lifeblood_requests', JSON.stringify(allReqs));
      StorageService.logAudit('Blood Request Rejected', 'Requests', req.requestNumber, `Rejected with reason: ${reason}`);
    }

    setRequests(StorageService.getBloodRequests());
    setSuccessMessage(`Request ${req.requestNumber} marked as Rejected.`);
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Distribution & Hospital Service</span>
            <span aria-hidden="true">·</span>
            <span>Blood Requisitions</span>
            <span aria-hidden="true">·</span>
            <span>Priority Triage & Stock Reservation</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Hospital Blood Requests & Distribution Triage
          </h1>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Hospital Requisition</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Requests Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-900">Hospital Requisitions Register</span>
          <span className="text-xs text-slate-500 font-mono">{requests.length} Orders</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Request No.</th>
                <th className="py-3 px-4">Hospital Facility</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Patient Ref</th>
                <th className="py-3 px-4">ABO/Rh</th>
                <th className="py-3 px-4">Component</th>
                <th className="py-3 px-4">Qty</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {requests.map(req => (
                <tr key={req.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{req.requestNumber}</td>
                  <td className="py-3 px-4 font-medium text-slate-900">{req.hospitalName}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                      req.priority === 'Emergency' ? 'bg-red-100 text-red-900 border border-red-300' :
                      req.priority === 'Urgent' ? 'bg-amber-100 text-amber-900' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {req.priority}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">{req.patientReference}</td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{req.patientBloodGroup}</td>
                  <td className="py-3 px-4 font-medium text-slate-700">{req.componentCode}</td>
                  <td className="py-3 px-4 font-mono tabular-nums">
                    {req.unitsIssued} / {req.unitsRequested}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                      req.status === 'Fulfilled' ? 'bg-emerald-50 text-emerald-800' :
                      req.status === 'Approved' ? 'bg-blue-50 text-blue-800' :
                      req.status === 'Rejected' ? 'bg-red-50 text-red-800' :
                      'bg-amber-50 text-amber-800'
                    }`}>
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-1.5 font-sans">
                    {req.status === 'Submitted' || req.status === 'Under Review' ? (
                      <>
                        <button
                          onClick={() => handleApproveAndReserve(req)}
                          className="px-2.5 py-1 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded cursor-pointer shadow-xs"
                        >
                          Approve & Reserve
                        </button>
                        <button
                          onClick={() => handleReject(req)}
                          className="px-2 py-1 text-xs font-semibold text-slate-600 hover:text-red-700 cursor-pointer"
                        >
                          Reject
                        </button>
                      </>
                    ) : req.status === 'Approved' || req.status === 'Partially Fulfilled' ? (
                      <button
                        onClick={() => onNavigate('issues')}
                        className="px-2.5 py-1 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded cursor-pointer shadow-xs inline-flex items-center gap-1"
                      >
                        <span>Dispatch Issue</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <span className="text-slate-400 text-xs">Closed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Request Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Hospital Blood Requisition</h3>
                <div className="text-xs text-slate-500">Submit clinician requisition with clinical priority level</div>
              </div>
              <button 
                onClick={() => setShowNewModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitRequest} className="p-6 space-y-4 text-xs">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">Requesting Facility *</label>
                  <select
                    value={hospitalId}
                    onChange={(e) => setHospitalId(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white cursor-pointer font-medium"
                  >
                    {hospitals.map(h => (
                      <option key={h.id} value={h.id}>
                        {h.name} ({h.facilityType})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Clinical Priority *</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-bold cursor-pointer"
                  >
                    <option value="Routine">Routine (Elective surgery / Ward)</option>
                    <option value="Urgent">Urgent (Within 4 hours)</option>
                    <option value="Emergency">EMERGENCY (Immediate Trauma / MTP)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Patient Blood Group *</label>
                  <select
                    value={patientGroup}
                    onChange={(e) => setPatientGroup(e.target.value as BloodGroup)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-mono font-bold cursor-pointer"
                  >
                    {bloodGroups.map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Patient Reference Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. PT-TRAUMA-991"
                    value={patientRef}
                    onChange={(e) => setPatientRef(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Patient Masked Identity / Initials</label>
                  <input
                    type="text"
                    placeholder="e.g. J. D. (Redacted for privacy)"
                    value={patientMasked}
                    onChange={(e) => setPatientMasked(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Requested Component *</label>
                  <select
                    value={componentCode}
                    onChange={(e) => setComponentCode(e.target.value as ComponentCode)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white cursor-pointer font-medium"
                  >
                    <option value="PRBC">Packed Red Blood Cells (PRBC)</option>
                    <option value="PLT">Platelets (PLT)</option>
                    <option value="FFP">Fresh Frozen Plasma (FFP)</option>
                    <option value="CRYO">Cryoprecipitate (CRYO)</option>
                    <option value="WB">Whole Blood (WB)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Number of Units Requested *</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    required
                    value={unitsRequested}
                    onChange={(e) => setUnitsRequested(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-700 mb-1">Clinical Indication & Diagnosis *</label>
                  <textarea
                    required
                    placeholder="e.g. Ruptured ectopic pregnancy with hemorrhagic shock, Hb 6.8 g/dL"
                    value={clinicalIndication}
                    onChange={(e) => setClinicalIndication(e.target.value)}
                    className="w-full p-2 border border-slate-200 rounded-md"
                    rows={2}
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Submit Blood Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
