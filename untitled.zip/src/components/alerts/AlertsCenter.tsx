import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  Flame, 
  RotateCcw, 
  X, 
  Plus, 
  Barcode 
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { RecallRecord, BloodUnit, User } from '../../types';

interface AlertsCenterProps {
  currentUser: User;
}

export const AlertsCenter: React.FC<AlertsCenterProps> = ({ currentUser }) => {
  const [recalls, setRecalls] = useState<RecallRecord[]>(StorageService.getRecalls());
  const [units] = useState<BloodUnit[]>(StorageService.getBloodUnits());
  const [showRecallModal, setShowRecallModal] = useState(false);
  const [unitBarcodeToRecall, setUnitBarcodeToRecall] = useState('');
  const [recallReason, setRecallReason] = useState('Post-donation donor medical report: Infectious illness diagnosis');
  const [recallSeverity, setRecallSeverity] = useState<'Critical' | 'High' | 'Moderate'>('Critical');
  const [successMessage, setSuccessMessage] = useState('');

  const now = new Date();
  const sevenDaysLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  // Expiring units
  const expiringUnits = units.filter(u => {
    if (u.status !== 'Released' && u.status !== 'Reserved') return false;
    const exp = new Date(u.expiryDate);
    return exp > now && exp <= sevenDaysLater;
  });

  // Expired units
  const expiredUnits = units.filter(u => {
    if (u.status === 'Issued' || u.status === 'Discarded') return false;
    const exp = new Date(u.expiryDate);
    return exp <= now;
  });

  const handleInitiateRecall = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitBarcodeToRecall) return;

    const res = StorageService.initiateRecall(recallReason, recallSeverity, unitBarcodeToRecall);
    if (res.success) {
      setRecalls(StorageService.getRecalls());
      setSuccessMessage(`Recall successfully executed. Unit ${unitBarcodeToRecall} and all derived components placed in emergency quarantine.`);
      setShowRecallModal(false);
      setUnitBarcodeToRecall('');
      setTimeout(() => setSuccessMessage(''), 5000);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Governance</span>
            <span aria-hidden="true">·</span>
            <span>Safety Alerts & Hemovigilance</span>
            <span aria-hidden="true">·</span>
            <span>Product Recalls & Expiry Alerts</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Safety, Expiry & Product Recall Center
          </h1>
        </div>

        <button
          onClick={() => setShowRecallModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Initiate Product Recall</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* 3 Alert Severity Sections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Critical Recalls */}
        <div className="bg-white border border-red-200 rounded-lg p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-900 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-red-700" />
              <span>Active Product Recalls</span>
            </span>
            <span className="font-mono text-xs font-bold text-red-800 bg-red-50 px-2 py-0.5 rounded">
              {recalls.length} Critical
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Recalls trigger automatic immediate quarantine across all sibling products derived from the same donor collection.
          </p>

          <div className="space-y-2.5 pt-1">
            {recalls.map(r => (
              <div key={r.id} className="p-3 bg-red-50/50 border border-red-200 rounded-md text-xs space-y-1">
                <div className="flex justify-between font-mono font-bold text-red-900">
                  <span>{r.recallCode}</span>
                  <span className="text-[10px] font-sans px-1.5 py-0.2 bg-red-100 rounded">{r.severity}</span>
                </div>
                <div className="text-slate-800 font-medium">{r.reason}</div>
                <div className="text-slate-500 text-[11px] pt-1">
                  Affected Barcodes: <span className="font-mono text-slate-700">{r.affectedUnitBarcodes.join(', ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Expiring Soon */}
        <div className="bg-white border border-amber-200 rounded-lg p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-600" />
              <span>Expiring $\le 7$ Days</span>
            </span>
            <span className="font-mono text-xs font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
              {expiringUnits.length} Units
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Units nearing maximum allowable shelf-life; prioritize via FEFO distribution before wastage occurs.
          </p>

          <div className="space-y-2 pt-1 max-h-72 overflow-y-auto">
            {expiringUnits.length === 0 ? (
              <div className="text-xs text-slate-400 py-6 text-center">No units expiring within 7 days.</div>
            ) : (
              expiringUnits.map(u => (
                <div key={u.id} className="p-2.5 bg-amber-50/40 border border-amber-200 rounded-md text-xs flex justify-between items-center">
                  <div>
                    <div className="font-mono font-bold text-slate-900">{u.unitBarcode}</div>
                    <div className="text-slate-600">{u.bloodGroup} {u.componentName}</div>
                  </div>
                  <div className="text-right text-[11px] font-mono text-amber-900 font-semibold">
                    {u.expiryDate.split('T')[0]}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Expired Stock */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-slate-600" />
              <span>Expired Inventory</span>
            </span>
            <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
              {expiredUnits.length} Units
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Units exceeding validated shelf-life. Must be isolated and recorded in the bio-hazard discard ledger.
          </p>

          <div className="space-y-2 pt-1 max-h-72 overflow-y-auto">
            {expiredUnits.length === 0 ? (
              <div className="text-xs text-slate-400 py-6 text-center">No expired units currently in active stock.</div>
            ) : (
              expiredUnits.map(u => (
                <div key={u.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-md text-xs flex justify-between items-center">
                  <div>
                    <div className="font-mono font-bold text-slate-900">{u.unitBarcode}</div>
                    <div className="text-slate-600">{u.bloodGroup} {u.componentName}</div>
                  </div>
                  <span className="text-[10px] text-red-700 bg-red-50 font-semibold px-2 py-0.5 rounded">
                    SLATED DISCARD
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Initiate Recall Modal */}
      {showRecallModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-red-900 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-red-700" />
                <span>Initiate Product Recall</span>
              </h3>
              <button 
                onClick={() => setShowRecallModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleInitiateRecall} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Target Blood Unit Barcode *</label>
                <select
                  value={unitBarcodeToRecall}
                  onChange={(e) => setUnitBarcodeToRecall(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-mono cursor-pointer"
                >
                  <option value="">-- Choose Unit to Flag for Recall --</option>
                  {units.filter(u => u.status !== 'Discarded').map(u => (
                    <option key={u.unitBarcode} value={u.unitBarcode}>
                      {u.unitBarcode} · {u.bloodGroup} · {u.componentCode} · Donation {u.donationNumber}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Recall will automatically locate all components sharing this donation collection ID and place them in locked quarantine.
                </p>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Severity Level *</label>
                <select
                  value={recallSeverity}
                  onChange={(e) => setRecallSeverity(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white font-bold cursor-pointer"
                >
                  <option value="Critical">Critical (Immediate Patient Risk / Viral Sero-conversion)</option>
                  <option value="High">High (Labeling or Contamination Suspicion)</option>
                  <option value="Moderate">Moderate (Cold-Chain Ambiguity)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Clinical Recall Justification *</label>
                <textarea
                  required
                  value={recallReason}
                  onChange={(e) => setRecallReason(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-md"
                  rows={2}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowRecallModal(false)}
                  className="px-3 py-1.5 font-semibold text-slate-600 bg-white border border-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md cursor-pointer shadow-xs"
                >
                  Execute Recall Lock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
