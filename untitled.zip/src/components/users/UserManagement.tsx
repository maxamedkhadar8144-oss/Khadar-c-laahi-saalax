import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  UserCheck, 
  UserX, 
  Lock, 
  KeyRound, 
  Plus, 
  CheckCircle2, 
  X,
  ShieldAlert,
  Edit3,
  Trash2,
  Search,
  Filter,
  AlertTriangle
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { User, RoleSlug } from '../../types';
import { ProfilePictureUploader } from '../common/ProfilePictureUploader';

export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>(() => StorageService.getUsers());
  const [currentUser] = useState<User>(() => StorageService.getCurrentUser());
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [role, setRole] = useState<RoleSlug>('blood-bank-tech');
  const [department, setDepartment] = useState('Laboratory & Processing');
  const [facility, setFacility] = useState('Central Blood Bank');
  const [avatarUrl, setAvatarUrl] = useState<string | undefined>(undefined);
  const [isActive, setIsActive] = useState(true);

  const roleLabels: Record<RoleSlug, string> = {
    'super-admin': 'Super Administrator',
    'blood-bank-admin': 'Blood Bank Administrator',
    'blood-bank-tech': 'Blood Bank Technician',
    'lab-tech': 'Laboratory Technician',
    'donor-officer': 'Donor Registration Officer',
    'hospital-officer': 'Hospital Requesting Officer',
    'report-viewer': 'Report Viewer'
  };

  const showSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setErrorMessage('');
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  const showError = (msg: string) => {
    setErrorMessage(msg);
    setTimeout(() => setErrorMessage(''), 5000);
  };

  const handleToggleActive = (user: User) => {
    user.isActive = !user.isActive;
    StorageService.saveUser(user);
    setUsers([...StorageService.getUsers()]);
    showSuccess(`User ${user.name} status updated to ${user.isActive ? 'Active' : 'Deactivated'}.`);
  };

  const handleOpenAdd = () => {
    setName('');
    setEmail('');
    setPhone('');
    setJobTitle('');
    setRole('blood-bank-tech');
    setDepartment('Immunohematology & Viral Serology');
    setFacility('Central Blood Bank');
    setAvatarUrl(undefined);
    setIsActive(true);
    setShowAddModal(true);
  };

  const handleOpenEdit = (user: User) => {
    setSelectedUser(user);
    setName(user.name);
    setEmail(user.email);
    setPhone(user.phone || '');
    setJobTitle(user.jobTitle || '');
    setRole(user.role);
    setDepartment(user.department);
    setFacility(user.facility || 'Central Blood Bank');
    setAvatarUrl(user.avatarUrl);
    setIsActive(user.isActive);
    setShowEditModal(true);
  };

  const handleOpenDelete = (user: User) => {
    setSelectedUser(user);
    setShowDeleteModal(true);
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
    const staffId = `STAFF-${String(newId).padStart(3, '0')}`;
    const newUser: User = {
      id: newId,
      staffId,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim() || undefined,
      jobTitle: jobTitle.trim() || undefined,
      role,
      roleName: roleLabels[role],
      department: department.trim(),
      facility: facility.trim() || undefined,
      avatarUrl,
      isActive,
      lastLoginAt: 'Never logged in'
    };

    StorageService.saveUser(newUser);
    setUsers([...StorageService.getUsers()]);
    setShowAddModal(false);
    showSuccess(`Staff account created: ${newUser.name} (${newUser.staffId})`);
  };

  const handleEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;

    const updatedUser: User = {
      ...selectedUser,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim() || undefined,
      jobTitle: jobTitle.trim() || undefined,
      role,
      roleName: roleLabels[role],
      department: department.trim(),
      facility: facility.trim() || undefined,
      avatarUrl,
      isActive
    };

    StorageService.saveUser(updatedUser);
    setUsers([...StorageService.getUsers()]);
    setShowEditModal(false);
    showSuccess(`Staff account updated: ${updatedUser.name} (${updatedUser.staffId})`);
  };

  const handleConfirmDelete = () => {
    if (!selectedUser) return;
    const result = StorageService.deleteUser(selectedUser.id);
    if (!result.success) {
      showError(result.error || 'Failed to delete user.');
      setShowDeleteModal(false);
      return;
    }

    setUsers([...StorageService.getUsers()]);
    setShowDeleteModal(false);
    showSuccess(`Staff account ${selectedUser.name} (${selectedUser.staffId}) has been deleted.`);
    setSelectedUser(null);
  };

  // RBAC Permission Matrix data
  const permissionModules = [
    { module: 'Donor Management', superAdmin: true, bbAdmin: true, bbTech: false, labTech: false, donorOfficer: true, hospOfficer: false, reportViewer: false },
    { module: 'Blood Donation Intake', superAdmin: true, bbAdmin: true, bbTech: true, labTech: false, donorOfficer: true, hospOfficer: false, reportViewer: false },
    { module: 'Component Fractionation', superAdmin: true, bbAdmin: true, bbTech: true, labTech: false, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'Inventory Stock Management', superAdmin: true, bbAdmin: true, bbTech: true, labTech: false, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'Laboratory Serology & Release', superAdmin: true, bbAdmin: true, bbTech: false, labTech: true, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'Hospital Requisition Approval', superAdmin: true, bbAdmin: true, bbTech: false, labTech: false, donorOfficer: false, hospOfficer: true, reportViewer: false },
    { module: 'Blood Issue & Cold Chain', superAdmin: true, bbAdmin: true, bbTech: true, labTech: false, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'Safety & Product Recalls', superAdmin: true, bbAdmin: true, bbTech: false, labTech: true, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'System Settings & Audit Logs', superAdmin: true, bbAdmin: false, bbTech: false, labTech: false, donorOfficer: false, hospOfficer: false, reportViewer: false },
    { module: 'Statistical Report Views', superAdmin: true, bbAdmin: true, bbTech: true, labTech: true, donorOfficer: true, hospOfficer: true, reportViewer: true }
  ];

  const filteredUsers = users.filter(u => {
    const matchSearch = 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.staffId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Security & Governance</span>
            <span aria-hidden="true">·</span>
            <span>Role-Based Access Control</span>
            <span aria-hidden="true">·</span>
            <span>7 RBAC Staff Roles</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            User & Staff Governance (RBAC)
          </h1>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Staff Account</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage('')} className="text-emerald-700 hover:text-emerald-900">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-md text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage('')} className="text-rose-700 hover:text-rose-900">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Staff User Accounts Table with Search & Filter */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-sm font-semibold text-slate-900">Registered Staff Accounts</span>
            <span className="text-xs text-slate-500 font-mono">({users.length} Users)</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-48 text-xs">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search staff..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 border border-slate-200 rounded-md text-xs"
              />
            </div>

            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="text-xs px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700"
            >
              <option value="all">All Roles</option>
              <option value="super-admin">Super Admin</option>
              <option value="blood-bank-admin">BB Admin</option>
              <option value="blood-bank-tech">BB Tech</option>
              <option value="lab-tech">Lab Tech</option>
              <option value="donor-officer">Donor Off.</option>
              <option value="hospital-officer">Hosp Off.</option>
              <option value="report-viewer">Report View</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Staff ID</th>
                <th className="py-3 px-4">Role Title</th>
                <th className="py-3 px-4">Department & Facility</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Last Login</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map(u => {
                const isCurrent = currentUser?.id === u.id;
                return (
                  <tr key={u.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center font-bold text-slate-700 shrink-0">
                          {u.avatarUrl ? (
                            <img src={u.avatarUrl} alt={u.name} className="w-full h-full object-cover" />
                          ) : (
                            <span>{u.name.substring(0, 2).toUpperCase()}</span>
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                            <span>{u.name}</span>
                            {isCurrent && (
                              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-red-100 text-red-800">You</span>
                            )}
                          </div>
                          <div className="text-slate-500 font-mono text-[11px]">{u.email}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{u.staffId}</td>

                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">{u.roleName}</span>
                      {u.jobTitle && <span className="block text-[11px] text-slate-400">{u.jobTitle}</span>}
                    </td>

                    <td className="py-3 px-4 text-slate-600">
                      <div>{u.department}</div>
                      <div className="text-[11px] text-slate-400">{u.facility || 'Central Blood Bank'}</div>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                        u.isActive ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                      }`}>
                        {u.isActive ? 'Active' : 'Suspended'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">{u.lastLoginAt || 'Recent'}</td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        
                        <button
                          onClick={() => handleToggleActive(u)}
                          title={u.isActive ? 'Deactivate user' : 'Activate user'}
                          className={`p-1.5 rounded transition-colors cursor-pointer ${
                            u.isActive 
                              ? 'text-slate-400 hover:text-amber-700 hover:bg-amber-50' 
                              : 'text-emerald-700 hover:bg-emerald-50'
                          }`}
                        >
                          {u.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>

                        <button
                          onClick={() => handleOpenEdit(u)}
                          title="Edit staff details and profile picture"
                          className="p-1.5 text-slate-500 hover:text-red-800 hover:bg-red-50 rounded transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleOpenDelete(u)}
                          disabled={isCurrent}
                          title={isCurrent ? 'Cannot delete current session' : 'Delete user account'}
                          className={`p-1.5 rounded transition-colors ${
                            isCurrent 
                              ? 'text-slate-300 cursor-not-allowed' 
                              : 'text-slate-400 hover:text-rose-700 hover:bg-rose-50 cursor-pointer'
                          }`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* RBAC Permission Matrix Table */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Role-Based Access Control (RBAC) Permission Matrix</h2>
          <div className="text-xs text-slate-500">
            Strict principle of least privilege enforced across the application
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">System Module / Capability</th>
                <th className="py-2.5 px-2 text-center">Super Admin</th>
                <th className="py-2.5 px-2 text-center">BB Admin</th>
                <th className="py-2.5 px-2 text-center">BB Tech</th>
                <th className="py-2.5 px-2 text-center">Lab Tech</th>
                <th className="py-2.5 px-2 text-center">Donor Off.</th>
                <th className="py-2.5 px-2 text-center">Hosp Off.</th>
                <th className="py-2.5 px-2 text-center">Report View</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[11px]">
              {permissionModules.map((pm, i) => (
                <tr key={i} className="hover:bg-slate-50/50">
                  <td className="py-2 px-3 font-medium text-slate-900">{pm.module}</td>
                  <td className="py-2 px-2 text-center">{pm.superAdmin ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.bbAdmin ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.bbTech ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.labTech ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.donorOfficer ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.hospOfficer ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                  <td className="py-2 px-2 text-center">{pm.reportViewer ? <span className="text-emerald-700 font-bold">✓</span> : <span className="text-slate-300">-</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900">Provision Staff Account</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-3">
              
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <ProfilePictureUploader
                  currentAvatarUrl={avatarUrl}
                  userName={name || 'Staff User'}
                  onChange={(url) => setAvatarUrl(url)}
                  size="md"
                  label="Profile Picture / Clinical Avatar"
                  helpText="Choose a photo or preset badge."
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Staff Member Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  placeholder="e.g. Dr. Omar Barre"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Work Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  placeholder="omar.barre@lifeblood.org"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Direct Phone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                  placeholder="+1-555-882-9011"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Job Designation</label>
                <input
                  type="text"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                  placeholder="Clinical Serology Tech"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Assigned RBAC Role *</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as RoleSlug)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-medium"
                >
                  <option value="super-admin">Super Administrator</option>
                  <option value="blood-bank-admin">Blood Bank Administrator</option>
                  <option value="blood-bank-tech">Blood Bank Technician</option>
                  <option value="lab-tech">Laboratory Technician</option>
                  <option value="donor-officer">Donor Registration Officer</option>
                  <option value="hospital-officer">Hospital Requesting Officer</option>
                  <option value="report-viewer">Report Viewer</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Assigned Department *</label>
                <input
                  type="text"
                  required
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                >
                  Provision User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Staff Modal */}
      {showEditModal && selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">Edit Staff Account</h3>
                <span className="font-mono text-[11px] text-slate-500">{selectedUser.staffId}</span>
              </div>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditUser} className="space-y-3">
              
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <ProfilePictureUploader
                  currentAvatarUrl={avatarUrl}
                  userName={name || selectedUser.name}
                  onChange={(url) => setAvatarUrl(url)}
                  size="md"
                  label="Profile Picture / Clinical Avatar"
                  helpText="Choose a photo or preset badge."
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Staff Member Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Work Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Direct Phone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Job Designation</label>
                <input
                  type="text"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Assigned RBAC Role *</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as RoleSlug)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-medium"
                >
                  <option value="super-admin">Super Administrator</option>
                  <option value="blood-bank-admin">Blood Bank Administrator</option>
                  <option value="blood-bank-tech">Blood Bank Technician</option>
                  <option value="lab-tech">Laboratory Technician</option>
                  <option value="donor-officer">Donor Registration Officer</option>
                  <option value="hospital-officer">Hospital Requesting Officer</option>
                  <option value="report-viewer">Report Viewer</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Assigned Department *</label>
                <input
                  type="text"
                  required
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Staff Modal */}
      {showDeleteModal && selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xl w-full max-w-md p-6 space-y-4 text-xs">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="p-2 bg-rose-50 rounded-full">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Staff Account</h3>
                <div className="text-[11px] text-slate-500 font-mono">{selectedUser.staffId}</div>
              </div>
            </div>

            <p className="text-slate-600">
              Are you sure you want to permanently delete the account for{' '}
              <strong className="text-slate-900">{selectedUser.name}</strong> ({selectedUser.roleName})?
            </p>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-700 hover:bg-rose-800 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
