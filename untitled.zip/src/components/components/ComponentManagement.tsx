import React, { useState } from 'react';
import { 
  Layers, 
  Split, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Thermometer, 
  Activity, 
  Barcode, 
  HelpCircle 
} from 'lucide-react';
import { COMPONENT_DEFINITIONS, StorageService } from '../../services/storage';
import { BloodUnit, ComponentCode } from '../../types';

export const ComponentManagement: React.FC = () => {
  const [units, setUnits] = useState<BloodUnit[]>(StorageService.getBloodUnits());
  const [selectedParentBarcode, setSelectedParentBarcode] = useState<string>('');
  const [makePRBC, setMakePRBC] = useState(true);
  const [makePlatelets, setMakePlatelets] = useState(true);
  const [makeFFP, setMakeFFP] = useState(true);
  const [makeCryo, setMakeCryo] = useState(false);

  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [derivedResult, setDerivedResult] = useState<BloodUnit[]>([]);

  // Find candidate Whole Blood units available for separation
  const wholeBloodUnits = units.filter(u => u.componentCode === 'WB' && u.status !== 'Issued' && u.status !== 'Discarded');

  const handleFractionate = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setDerivedResult([]);

    if (!selectedParentBarcode) {
      setErrorMessage('Please select a parent Whole Blood unit to process.');
      return;
    }

    if (!makePRBC && !makePlatelets && !makeFFP && !makeCryo) {
      setErrorMessage('Please select at least one component to derive.');
      return;
    }

    const res = StorageService.fractionateUnit(selectedParentBarcode, {
      makePRBC,
      makePlatelets,
      makeFFP,
      makeCryo
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Fractionation failed');
      return;
    }

    setUnits(StorageService.getBloodUnits());
    setDerivedResult(res.derivedUnits || []);
    setSuccessMessage(`Whole Blood unit ${selectedParentBarcode} successfully fractionated into ${res.derivedUnits?.length} components.`);
    setSelectedParentBarcode('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>Component Separation</span>
            <span aria-hidden="true">·</span>
            <span>Vein-to-Vein Traceability</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Blood Component Management & Fractionation
          </h1>
        </div>
      </div>

      {/* Component Type Specifications Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        {Object.values(COMPONENT_DEFINITIONS).map(c => (
          <div key={c.code} className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-base font-bold text-red-900">{c.code}</span>
              <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                {c.standardVolumeMl} ml
              </span>
            </div>
            <div className="font-semibold text-slate-900 text-xs">{c.name}</div>
            
            <div className="space-y-1 text-[11px] text-slate-600 pt-1 border-t border-slate-100">
              <div className="flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-slate-400" />
                <span>{c.storageTemp}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Shelf Life: {c.shelfLifeDays} days</span>
              </div>
              {c.requiresAgitation && (
                <div className="text-amber-700 font-semibold text-[10px]">
                  Requires continuous mechanical agitation
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Fractionation Laboratory Tool */}
      <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-xs space-y-5">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Split className="w-5 h-5 text-red-800" />
            <span>Component Fractionation & Separation Station</span>
          </h2>
          <div className="text-xs text-slate-500 mt-0.5">
            Fractionate Whole Blood collections into Packed Red Blood Cells (PRBC), Platelets, and Plasma. The parent unit is automatically retired to prevent double-counting.
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleFractionate} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Select Whole Blood Parent */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Select Whole Blood Unit to Fractionate *
              </label>
              {wholeBloodUnits.length === 0 ? (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-md text-xs text-slate-500">
                  No Whole Blood units available for separation. Record a new donation first.
                </div>
              ) : (
                <select
                  value={selectedParentBarcode}
                  onChange={(e) => setSelectedParentBarcode(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-red-800 cursor-pointer font-mono font-medium"
                >
                  <option value="">-- Choose Whole Blood Unit --</option>
                  {wholeBloodUnits.map(u => (
                    <option key={u.unitBarcode} value={u.unitBarcode}>
                      {u.unitBarcode} · {u.bloodGroup} · {u.volumeMl}ml · Status: {u.status}
                    </option>
                  ))}
                </select>
              )}
            </div>

            {/* Components Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Target Derived Components
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={makePRBC}
                    onChange={(e) => setMakePRBC(e.target.checked)}
                    className="text-red-800 focus:ring-red-800 rounded"
                  />
                  <span>Packed Red Cells (PRBC)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={makePlatelets}
                    onChange={(e) => setMakePlatelets(e.target.checked)}
                    className="text-red-800 focus:ring-red-800 rounded"
                  />
                  <span>Platelets (PLT)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={makeFFP}
                    onChange={(e) => setMakeFFP(e.target.checked)}
                    className="text-red-800 focus:ring-red-800 rounded"
                  />
                  <span>Fresh Frozen Plasma (FFP)</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={makeCryo}
                    onChange={(e) => setMakeCryo(e.target.checked)}
                    className="text-red-800 focus:ring-red-800 rounded"
                  />
                  <span>Cryoprecipitate (CRYO)</span>
                </label>
              </div>
            </div>

          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={wholeBloodUnits.length === 0}
              className="px-5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs disabled:opacity-50"
            >
              Perform Fractionation & Generate Component Barcodes
            </button>
          </div>
        </form>

        {/* Derived Result Display */}
        {derivedResult.length > 0 && (
          <div className="mt-5 p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Derived Component Units Produced:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {derivedResult.map(du => (
                <div key={du.unitBarcode} className="p-3 bg-white border border-slate-200 rounded-md text-xs space-y-1">
                  <div className="font-mono font-bold text-slate-900 flex items-center gap-1.5">
                    <Barcode className="w-3.5 h-3.5 text-slate-400" />
                    <span>{du.unitBarcode}</span>
                  </div>
                  <div className="font-medium text-slate-800">{du.componentName} ({du.bloodGroup})</div>
                  <div className="text-slate-500 text-[11px]">Storage: {du.storageLocation}</div>
                  <div className="text-slate-500 text-[11px]">Expires: {du.expiryDate.split('T')[0]}</div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
