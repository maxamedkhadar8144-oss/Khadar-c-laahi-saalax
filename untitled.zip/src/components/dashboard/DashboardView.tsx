import React, { useState } from 'react';
import {
  Users,
  Droplet,
  PackageCheck,
  ClipboardList,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  PlusCircle,
  Building2,
  ShieldAlert,
  Calendar,
  CheckCircle2,
  Flame,
  ArrowRight
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { User, BloodGroup } from '../../types';

interface DashboardViewProps {
  currentUser: User;
  onNavigate: (view: string) => void;
  onOpenQuickAction: (action: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentUser,
  onNavigate,
  onOpenQuickAction
}) => {
  const donors = StorageService.getDonors();
  const units = StorageService.getBloodUnits();
  const requests = StorageService.getBloodRequests();
  const hospitals = StorageService.getHospitals();
  const auditLogs = StorageService.getAuditLogs();

  // Metrics calculations
  const totalDonors = donors.length;
  const activeDonors = donors.filter(d => d.status === 'Active').length;

  const totalUnits = units.length;
  const availableUnits = units.filter(u => u.status === 'Released').length;
  const quarantinedUnits = units.filter(u => u.status === 'Quarantined').length;
  const reservedUnits = units.filter(u => u.status === 'Reserved').length;
  const issuedUnits = units.filter(u => u.status === 'Issued').length;

  const pendingRequests = requests.filter(r => r.status === 'Submitted' || r.status === 'Under Review').length;
  const approvedRequests = requests.filter(r => r.status === 'Approved').length;

  const now = new Date();
  const sevenDaysLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const expiringSoonUnits = units.filter(u => {
    if (u.status !== 'Released' && u.status !== 'Reserved') return false;
    const exp = new Date(u.expiryDate);
    return exp > now && exp <= sevenDaysLater;
  });

  const expiredUnits = units.filter(u => {
    if (u.status === 'Issued' || u.status === 'Discarded') return false;
    const exp = new Date(u.expiryDate);
    return exp <= now;
  });

  // Calculate stock by blood group
  const bloodGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const stockByGroup = bloodGroups.map(bg => {
    const count = units.filter(u => u.bloodGroup === bg && u.status === 'Released').length;
    const isCritical = count < 5;
    return { group: bg, count, isCritical };
  });

  const criticalShortages = stockByGroup.filter(s => s.isCritical).length;

  // Urgent & Emergency pending requests
  const priorityRequests = requests.filter(r => (r.priority === 'Emergency' || r.priority === 'Urgent') && r.status !== 'Fulfilled');

  return (
    <div className="space-y-6">
      
      {/* View Header with Contextual Breadcrumbs & Quick Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Clinical Operations</span>
            <span aria-hidden="true">·</span>
            <span>National Transfusion Hub</span>
            <span aria-hidden="true">·</span>
            <span>Real-time Live Feed</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Transfusion Dashboard & Stock Overview
          </h1>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => onOpenQuickAction('register-donor')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
          >
            <PlusCircle className="w-4 h-4 text-slate-500" />
            <span>Register Donor</span>
          </button>
          <button
            onClick={() => onOpenQuickAction('record-donation')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
          >
            <Droplet className="w-4 h-4 text-red-200" />
            <span>Record Donation</span>
          </button>
          <button
            onClick={() => onOpenQuickAction('new-request')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
          >
            <ClipboardList className="w-4 h-4 text-slate-500" />
            <span>Hospital Order</span>
          </button>
        </div>
      </div>

      {/* 12 Real-Time Key Operational Indicator Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        
        {/* 1. Total Registered Donors */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Registered Donors</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">{totalDonors}</div>
          <div className="text-[11px] text-slate-400 mt-1">{activeDonors} active donors</div>
        </div>

        {/* 2. Available Units (Released) */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Available Units</div>
          <div className="text-2xl font-bold text-emerald-700 font-mono tabular-nums">{availableUnits}</div>
          <div className="text-[11px] text-slate-400 mt-1">Verified & safe to issue</div>
        </div>

        {/* 3. Quarantined Units */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Quarantined Stock</div>
          <div className="text-2xl font-bold text-amber-700 font-mono tabular-nums">{quarantinedUnits}</div>
          <div className="text-[11px] text-slate-400 mt-1">Pending viral testing</div>
        </div>

        {/* 4. Reserved Units */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Reserved Units</div>
          <div className="text-2xl font-bold text-blue-700 font-mono tabular-nums">{reservedUnits}</div>
          <div className="text-[11px] text-slate-400 mt-1">Assigned to surgery</div>
        </div>

        {/* 5. Pending Hospital Requests */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Pending Orders</div>
          <div className="text-2xl font-bold text-red-700 font-mono tabular-nums">{pendingRequests}</div>
          <div className="text-[11px] text-slate-400 mt-1">{approvedRequests} approved ready</div>
        </div>

        {/* 6. Critical Stock Shortages */}
        <div className={`p-4 rounded-lg shadow-xs border ${
          criticalShortages > 0 ? 'bg-red-50/50 border-red-300' : 'bg-white border-slate-200'
        }`}>
          <div className="text-xs font-medium text-slate-500 mb-1">Stock Shortages</div>
          <div className="text-2xl font-bold text-red-800 font-mono tabular-nums">{criticalShortages}</div>
          <div className="text-[11px] text-red-600 font-medium mt-1">Groups below 5 units</div>
        </div>

        {/* 7. Blood Units Expiring Soon */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Expiring $\le 7$ Days</div>
          <div className="text-2xl font-bold text-amber-600 font-mono tabular-nums">{expiringSoonUnits.length}</div>
          <div className="text-[11px] text-slate-400 mt-1">Prioritize FEFO issue</div>
        </div>

        {/* 8. Expired Units */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Expired Units</div>
          <div className="text-2xl font-bold text-slate-700 font-mono tabular-nums">{expiredUnits.length}</div>
          <div className="text-[11px] text-slate-400 mt-1">Slated for safe discard</div>
        </div>

        {/* 9. Issued Today */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Issued Units</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">{issuedUnits}</div>
          <div className="text-[11px] text-slate-400 mt-1">Vein-to-vein tracked</div>
        </div>

        {/* 10. Affiliated Hospitals */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Partner Facilities</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">{hospitals.length}</div>
          <div className="text-[11px] text-slate-400 mt-1">Licensed hospitals</div>
        </div>

        {/* 11. O- Emergency Reserve */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">O- Universal Reserve</div>
          <div className="text-2xl font-bold text-red-800 font-mono tabular-nums">
            {units.filter(u => u.bloodGroup === 'O-' && u.status === 'Released').length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Trauma emergency cache</div>
        </div>

        {/* 12. Total Inventory Units */}
        <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">Total Unit Database</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">{totalUnits}</div>
          <div className="text-[11px] text-slate-400 mt-1">All stages recorded</div>
        </div>

      </div>

      {/* Main Operational Split: Blood Group Stock Matrix & Urgent Clinical Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Blood Group Inventory Matrix */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-slate-900">ABO & RhD Inventory by Blood Group</h2>
              <div className="text-xs text-slate-500">Live inventory status against national safety thresholds</div>
            </div>
            <button
              onClick={() => onNavigate('blood-groups')}
              className="text-xs text-red-800 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View Group Details</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            {stockByGroup.map(item => (
              <div
                key={item.group}
                className={`p-3.5 rounded-lg border transition-all ${
                  item.isCritical 
                    ? 'border-red-300 bg-red-50/40' 
                    : 'border-slate-200 bg-slate-50/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-lg font-bold text-slate-900 font-mono">{item.group}</span>
                  {item.isCritical && (
                    <span className="text-[10px] font-semibold text-red-700 bg-red-100 px-1.5 py-0.5 rounded">
                      Low Stock
                    </span>
                  )}
                </div>
                <div className="text-2xl font-bold font-mono tabular-nums text-slate-800">
                  {item.count} <span className="text-xs font-normal text-slate-500">units</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2.5 overflow-hidden">
                  <div 
                    className={`h-full ${item.isCritical ? 'bg-red-600' : 'bg-emerald-600'}`} 
                    style={{ width: `${Math.min(100, (item.count / 25) * 100)}%` }} 
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Clinical Reference Banner */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-start gap-3">
            <Flame className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-800">Transfusion Safety Policy:</span> ABO/Rh compatibility suggestions provide reference guidance only. Every clinical transfusion requires laboratory antibody screening, patient crossmatch verification, and clinician release authorization.
            </div>
          </div>
        </div>

        {/* Right Col: High Priority & Emergency Hospital Requests */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-semibold text-slate-900">Urgent Hospital Requests</h2>
              <span className="text-xs font-medium text-red-700 font-mono">{priorityRequests.length} Pending</span>
            </div>

            <div className="space-y-3">
              {priorityRequests.length === 0 ? (
                <div className="text-xs text-slate-500 py-8 text-center">
                  No urgent or emergency requests pending fulfillment.
                </div>
              ) : (
                priorityRequests.slice(0, 3).map(req => (
                  <div key={req.id} className="p-3 border border-slate-200 rounded-lg bg-slate-50/60 text-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-red-800 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                        {req.priority} Requisition
                      </span>
                      <span className="font-mono text-slate-500">{req.requestNumber}</span>
                    </div>
                    <div className="font-medium text-slate-900">{req.hospitalName}</div>
                    <div className="text-slate-600">
                      Patient: {req.patientNameMasked} · Blood Group: <span className="font-bold">{req.patientBloodGroup}</span>
                    </div>
                    <div className="text-slate-500 text-[11px] pt-1 border-t border-slate-200 flex items-center justify-between">
                      <span>Requested: {req.unitsRequested} units {req.componentCode}</span>
                      <span className="font-semibold text-slate-700">{req.status}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('requests')}
            className="w-full mt-4 py-2 text-xs font-semibold text-center text-red-800 bg-red-50 hover:bg-red-100 rounded-md transition-colors cursor-pointer"
          >
            Manage All Hospital Requisitions
          </button>
        </div>

      </div>

      {/* Secondary Split: Expiring Inventory & Real-Time Audit Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Expiring Units & FEFO Priority Queue */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">FEFO Expiry Queue (First Expired, First Out)</h2>
              <div className="text-xs text-slate-500">Units prioritized for clinical dispatch to avoid wastage</div>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-red-800 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View Full Inventory</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="pb-2 font-medium">Unit Barcode</th>
                  <th className="pb-2 font-medium">Component</th>
                  <th className="pb-2 font-medium">Group</th>
                  <th className="pb-2 font-medium">Expiry Date</th>
                  <th className="pb-2 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {units.slice(0, 5).map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/60">
                    <td className="py-2.5 font-bold text-slate-900">{u.unitBarcode}</td>
                    <td className="py-2.5 font-sans text-slate-700">{u.componentCode}</td>
                    <td className="py-2.5 font-bold text-slate-800">{u.bloodGroup}</td>
                    <td className="py-2.5 text-slate-600">{u.expiryDate.split('T')[0]}</td>
                    <td className="py-2.5 text-right font-sans">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                        u.status === 'Released' ? 'bg-emerald-50 text-emerald-800' :
                        u.status === 'Quarantined' ? 'bg-amber-50 text-amber-800' :
                        u.status === 'Reserved' ? 'bg-blue-50 text-blue-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {u.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Real-time System Audit Stream */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Recent Immutable Audit Activity</h2>
              <div className="text-xs text-slate-500">Cryptographically verifiable actions & compliance log</div>
            </div>
            <button
              onClick={() => onNavigate('audit')}
              className="text-xs text-red-800 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View Audit Logs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {auditLogs.slice(0, 4).map(log => (
              <div key={log.id} className="flex items-start gap-3 text-xs pb-2 border-b border-slate-100 last:border-0">
                <div className="w-2 h-2 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900">{log.action}</span>
                    <span className="text-[11px] text-slate-400 font-mono">{log.timestamp.split(' ')[1]}</span>
                  </div>
                  <div className="text-slate-600 truncate">{log.details}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    User: {log.userName} · Module: {log.module}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
