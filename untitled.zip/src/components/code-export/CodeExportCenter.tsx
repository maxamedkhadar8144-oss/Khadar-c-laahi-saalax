import React, { useState } from 'react';
import { 
  FileCode2, 
  Copy, 
  Check, 
  Download, 
  Database, 
  FolderTree, 
  Terminal, 
  CheckCircle2, 
  ExternalLink,
  BookOpen,
  Layers,
  ShieldCheck,
  KeyRound,
  ShieldAlert,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { User, RoleSlug } from '../../types';

interface CodeExportCenterProps {
  onUserChange?: (user: User) => void;
}

export const CodeExportCenter: React.FC<CodeExportCenterProps> = ({ onUserChange }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [selectedFileKey, setSelectedFileKey] = useState<string>('schema.sql');
  const [showAuthTester, setShowAuthTester] = useState<boolean>(true);
  const [testEmail, setTestEmail] = useState<string>('admin@lifeblood.org');
  const [testPassword, setTestPassword] = useState<string>('Admin@12345');
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [authTestResult, setAuthTestResult] = useState<{
    status: 'success' | 'error';
    message: string;
    details?: any;
    allowedModules?: string[];
    restrictedModules?: string[];
  } | null>(null);

  const files: Record<string, { title: string; path: string; lang: string; content: string }> = {
    'schema.sql': {
      title: 'MySQL Relational Schema (30+ Tables)',
      path: 'database/schema.sql',
      lang: 'sql',
      content: `-- ==============================================================================
-- LIFEBLOOD — ADVANCED BLOOD BANK MANAGEMENT SYSTEM (BBMS)
-- DATABASE SCHEMA FOR MYSQL 8.0+ / MARIADB 10.4+ (XAMPP WINDOWS COMPLIANT)
-- ENGINE: InnoDB | CHARSET: utf8mb4 | COLLATION: utf8mb4_unicode_ci
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS \`blood_bank_db\` 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE \`blood_bank_db\`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. ROLES & PERMISSIONS
CREATE TABLE \`roles\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`slug\` VARCHAR(50) NOT NULL UNIQUE,
    \`name\` VARCHAR(100) NOT NULL,
    \`description\` VARCHAR(255) NULL,
    \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. USERS & STAFF ACCOUNTS
CREATE TABLE \`users\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`staff_id\` VARCHAR(30) NOT NULL UNIQUE,
    \`name\` VARCHAR(120) NOT NULL,
    \`email\` VARCHAR(150) NOT NULL UNIQUE,
    \`password_hash\` VARCHAR(255) NOT NULL,
    \`role_id\` INT UNSIGNED NOT NULL,
    \`department\` VARCHAR(80) NULL,
    \`is_active\` TINYINT(1) DEFAULT 1,
    \`failed_login_attempts\` INT UNSIGNED DEFAULT 0,
    \`lockout_until\` DATETIME NULL,
    \`last_login_at\` DATETIME NULL,
    FOREIGN KEY (\`role_id\`) REFERENCES \`roles\` (\`id\`)
) ENGINE=InnoDB;

-- 3. BLOOD GROUPS & COMPONENTS
CREATE TABLE \`blood_groups\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`group_name\` VARCHAR(10) NOT NULL UNIQUE,
    \`abo_type\` ENUM('A', 'B', 'AB', 'O') NOT NULL,
    \`rh_factor\` ENUM('Positive', 'Negative') NOT NULL,
    \`min_stock_threshold\` INT UNSIGNED DEFAULT 15,
    \`critical_shortage_threshold\` INT UNSIGNED DEFAULT 5
) ENGINE=InnoDB;

CREATE TABLE \`blood_components\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`code\` VARCHAR(20) NOT NULL UNIQUE,
    \`name\` VARCHAR(100) NOT NULL,
    \`storage_temp_celsius\` VARCHAR(50) NOT NULL,
    \`default_shelf_life_days\` INT UNSIGNED NOT NULL,
    \`standard_unit_volume_ml\` INT UNSIGNED NOT NULL,
    \`requires_agitation\` TINYINT(1) DEFAULT 0
) ENGINE=InnoDB;

-- 4. DONORS & DEFERRALS
CREATE TABLE \`donors\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`donor_number\` VARCHAR(30) NOT NULL UNIQUE,
    \`first_name\` VARCHAR(80) NOT NULL,
    \`last_name\` VARCHAR(80) NOT NULL,
    \`national_id\` VARCHAR(50) NULL UNIQUE,
    \`date_of_birth\` DATE NOT NULL,
    \`sex\` ENUM('Male', 'Female', 'Other') NOT NULL,
    \`blood_group_id\` INT UNSIGNED NOT NULL,
    \`phone\` VARCHAR(30) NOT NULL,
    \`email\` VARCHAR(120) NULL,
    \`status\` ENUM('Active', 'Temporarily Deferred', 'Permanently Deferred') DEFAULT 'Active',
    \`total_donations\` INT UNSIGNED DEFAULT 0,
    FOREIGN KEY (\`blood_group_id\`) REFERENCES \`blood_groups\` (\`id\`)
) ENGINE=InnoDB;

-- 5. DONATIONS & BLOOD UNITS
CREATE TABLE \`blood_units\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`unit_barcode\` VARCHAR(40) NOT NULL UNIQUE,
    \`donation_id\` INT UNSIGNED NOT NULL,
    \`component_id\` INT UNSIGNED NOT NULL,
    \`blood_group_id\` INT UNSIGNED NOT NULL,
    \`volume_ml\` INT UNSIGNED NOT NULL,
    \`collection_date\` DATETIME NOT NULL,
    \`expiry_date\` DATETIME NOT NULL,
    \`storage_location_id\` INT UNSIGNED NOT NULL,
    \`status\` ENUM('Collected', 'Quarantined', 'Under Testing', 'Released', 'Reserved', 'Issued', 'Expired', 'Discarded', 'Recalled') DEFAULT 'Quarantined',
    \`version\` INT UNSIGNED DEFAULT 1,
    FOREIGN KEY (\`component_id\`) REFERENCES \`blood_components\` (\`id\`),
    FOREIGN KEY (\`blood_group_id\`) REFERENCES \`blood_groups\` (\`id\`)
) ENGINE=InnoDB;

-- 6. LABORATORY SCREENING ASSAYS
CREATE TABLE \`laboratory_tests\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`unit_id\` INT UNSIGNED NOT NULL,
    \`sample_barcode\` VARCHAR(45) NOT NULL UNIQUE,
    \`abo_verified\` ENUM('A', 'B', 'AB', 'O') NULL,
    \`rh_verified\` ENUM('Positive', 'Negative') NULL,
    \`antibody_screen_result\` ENUM('Negative', 'Positive', 'Inconclusive') DEFAULT 'Negative',
    \`hiv_result\` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    \`hbsag_result\` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    \`hcv_result\` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    \`syphilis_result\` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    \`overall_decision\` ENUM('Pending', 'Released', 'Rejected') DEFAULT 'Pending',
    \`tested_by_user_id\` INT UNSIGNED NOT NULL,
    FOREIGN KEY (\`unit_id\` ) REFERENCES \`blood_units\` (\`id\`)
) ENGINE=InnoDB;

-- 7. HOSPITALS & REQUISITIONS
CREATE TABLE \`hospitals\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`hospital_code\` VARCHAR(30) NOT NULL UNIQUE,
    \`name\` VARCHAR(150) NOT NULL,
    \`facility_type\` ENUM('Tertiary Hospital', 'Regional Referral Hospital', 'Specialized Trauma Center', 'Maternity Hospital') NOT NULL,
    \`address\` TEXT NOT NULL,
    \`phone\` VARCHAR(30) NOT NULL,
    \`license_number\` VARCHAR(60) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE \`blood_requests\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`request_number\` VARCHAR(35) NOT NULL UNIQUE,
    \`hospital_id\` INT UNSIGNED NOT NULL,
    \`requesting_clinician\` VARCHAR(120) NOT NULL,
    \`patient_reference_number\` VARCHAR(50) NOT NULL,
    \`priority\` ENUM('Routine', 'Urgent', 'Emergency') NOT NULL DEFAULT 'Routine',
    \`status\` ENUM('Draft', 'Submitted', 'Under Review', 'Approved', 'Partially Fulfilled', 'Fulfilled', 'Rejected') DEFAULT 'Submitted',
    FOREIGN KEY (\`hospital_id\`) REFERENCES \`hospitals\` (\`id\`)
) ENGINE=InnoDB;

-- 8. CONTROLLED ISSUE & COLD-CHAIN DELIVERY
CREATE TABLE \`blood_issues\` (
    \`id\` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`issue_slip_number\` VARCHAR(35) NOT NULL UNIQUE,
    \`request_id\` INT UNSIGNED NOT NULL,
    \`unit_id\` INT UNSIGNED NOT NULL,
    \`hospital_id\` INT UNSIGNED NOT NULL,
    \`transport_temperature_celsius\` DECIMAL(4,1) NOT NULL,
    \`transport_box_id\` VARCHAR(40) NOT NULL,
    \`issue_datetime\` DATETIME NOT NULL,
    FOREIGN KEY (\`request_id\`) REFERENCES \`blood_requests\` (\`id\`),
    FOREIGN KEY (\`unit_id\`) REFERENCES \`blood_units\` (\`id\`)
) ENGINE=InnoDB;

-- 9. AUDIT TRAIL LOGS
CREATE TABLE \`audit_logs\` (
    \`id\` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    \`user_id\` INT UNSIGNED NULL,
    \`action\` VARCHAR(100) NOT NULL,
    \`entity_type\` VARCHAR(60) NOT NULL,
    \`entity_id\` VARCHAR(50) NOT NULL,
    \`details\` TEXT NULL,
    \`ip_address\` VARCHAR(45) NOT NULL,
    \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;`
    },
    'seed.sql': {
      title: 'Database Initial Seed Data',
      path: 'database/seed.sql',
      lang: 'sql',
      content: `-- LIFEBLOOD SEED DATA
USE \`blood_bank_db\`;

INSERT INTO \`roles\` (\`id\`, \`slug\`, \`name\`, \`description\`) VALUES
(1, 'super-admin', 'Super Administrator', 'Full system access and audit control'),
(2, 'blood-bank-admin', 'Blood Bank Administrator', 'Operations supervision and thresholds'),
(3, 'blood-bank-tech', 'Blood Bank Technician', 'Component fractionation and inventory'),
(4, 'lab-tech', 'Laboratory Technician', 'Immunohematology and infectious disease testing'),
(5, 'donor-officer', 'Donor Registration Officer', 'Donor intake and deferrals'),
(6, 'hospital-officer', 'Hospital Requesting Officer', 'Hospital requisitions'),
(7, 'report-viewer', 'Report Viewer', 'Statistical reports');

INSERT INTO \`blood_groups\` (\`id\`, \`group_name\`, \`abo_type\`, \`rh_factor\`, \`min_stock_threshold\`) VALUES
(1, 'A+', 'A', 'Positive', 25),
(2, 'A-', 'A', 'Negative', 15),
(3, 'B+', 'B', 'Positive', 20),
(4, 'B-', 'B', 'Negative', 12),
(5, 'AB+', 'AB', 'Positive', 15),
(6, 'AB-', 'AB', 'Negative', 10),
(7, 'O+', 'O', 'Positive', 35),
(8, 'O-', 'O', 'Negative', 30);

INSERT INTO \`blood_components\` (\`id\`, \`code\`, \`name\`, \`storage_temp_celsius\`, \`default_shelf_life_days\`, \`standard_unit_volume_ml\`) VALUES
(1, 'WB', 'Whole Blood', '2°C to 6°C', 35, 450),
(2, 'PRBC', 'Packed Red Blood Cells', '2°C to 6°C', 42, 280),
(3, 'PLT', 'Platelets', '20°C to 24°C', 5, 250),
(4, 'FFP', 'Fresh Frozen Plasma', '-18°C or colder', 365, 220),
(5, 'CRYO', 'Cryoprecipitate AHF', '-18°C or colder', 365, 40);`
    },
    'database.php': {
      title: 'PDO Database Connection Manager',
      path: 'config/database.php',
      lang: 'php',
      content: `<?php
declare(strict_types=1);
namespace App\Config;
use PDO, PDOException;

class Database {
    private static ?PDO $instance = null;
    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $host = getenv('DB_HOST') ?: '127.0.0.1';
            $dbname = getenv('DB_NAME') ?: 'blood_bank_db';
            $user = getenv('DB_USER') ?: 'root';
            $pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';
            $dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            self::$instance = new PDO($dsn, $user, $pass, $options);
        }
        return self::$instance;
    }
}`
    },
    'Security.php': {
      title: 'Security & CSRF Protection Helper',
      path: 'app/Helpers/Security.php',
      lang: 'php',
      content: `<?php
declare(strict_types=1);
namespace App\Helpers;

class Security {
    public static function startSecureSession(): void {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', '1');
            ini_set('session.use_only_cookies', '1');
            ini_set('session.cookie_samesite', 'Lax');
            session_start();
        }
    }
    public static function getCsrfToken(): string {
        self::startSecureSession();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    public static function validateCsrfToken(?string $token): bool {
        self::startSecureSession();
        return hash_equals($_SESSION['csrf_token'] ?? '', (string)$token);
    }
    public static function escape(?string $data): string {
        return htmlspecialchars((string)$data, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}`
    },
    'Auth.php': {
      title: 'RBAC Authorization Helper',
      path: 'app/Helpers/Auth.php',
      lang: 'php',
      content: `<?php
declare(strict_types=1);
namespace App\Helpers;
use App\Config\Database;

class Auth {
    public static function requireRoles(array $allowedRoles): void {
        Security::startSecureSession();
        if (empty($_SESSION['user_id'])) {
            header('Location: /login.php');
            exit;
        }
        $currentRole = $_SESSION['role_slug'] ?? '';
        if (!in_array($currentRole, $allowedRoles, true)) {
            http_response_code(403);
            die('Access Denied: Insufficient Role Permissions.');
        }
    }
}`
    },
    'README.md': {
      title: 'Windows XAMPP Installation Guide',
      path: 'README.md',
      lang: 'markdown',
      content: `# LifeBlood BBMS - Windows XAMPP Setup Guide

1. Download and install XAMPP for Windows (PHP 8.2+)
2. Start Apache and MySQL from XAMPP Control Panel
3. Place project files in: C:\\xampp\\htdocs\\blood-bank-management
4. Open http://localhost/phpmyadmin
5. Create database 'blood_bank_db' with utf8mb4_unicode_ci collation
6. Import database/schema.sql then database/seed.sql
7. Launch system at: http://localhost/blood-bank-management/public
8. Login with admin@lifeblood.org / Admin@12345`
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const testAccounts = [
    { email: 'admin@lifeblood.org', roleName: 'Super Admin', role: 'super-admin' as RoleSlug },
    { email: 'operations@lifeblood.org', roleName: 'BB Admin', role: 'blood-bank-admin' as RoleSlug },
    { email: 'lab@lifeblood.org', roleName: 'Lab Tech', role: 'lab-tech' as RoleSlug },
    { email: 'tech@lifeblood.org', roleName: 'BB Tech', role: 'blood-bank-tech' as RoleSlug },
    { email: 'donors@lifeblood.org', roleName: 'Donor Officer', role: 'donor-officer' as RoleSlug },
    { email: 'stjude.orders@stjude.org', roleName: 'Hospital Officer', role: 'hospital-officer' as RoleSlug },
    { email: 'auditor@lifeblood.org', roleName: 'Report Viewer', role: 'report-viewer' as RoleSlug },
  ];

  const rolePermissionsMap: Record<RoleSlug, { allowed: string[]; restricted: string[] }> = {
    'super-admin': {
      allowed: ['Donor Registry', 'Donation Intake', 'Component Fractionation', 'FEFO Stock Ledger', 'Laboratory Serology & Release', 'Hospital Requisitions', 'Blood Issue & Delivery', 'Product Recalls', 'Staff RBAC Management', 'Audit Trail', 'System Settings', 'Reports & Analytics'],
      restricted: []
    },
    'blood-bank-admin': {
      allowed: ['Donor Registry', 'Donation Intake', 'Component Fractionation', 'FEFO Stock Ledger', 'Hospital Requisitions & Approvals', 'Blood Issue & Delivery', 'Product Recalls', 'Reports & Analytics'],
      restricted: ['System Settings Master Keys', 'Staff Role Privileges Alteration']
    },
    'blood-bank-tech': {
      allowed: ['Donation Intake', 'Component Fractionation', 'FEFO Stock Ledger', 'Cold Chain Transport Preparation', 'Blood Issue Slips'],
      restricted: ['Laboratory Viral Release Determination', 'Hospital Requisition Approval/Rejection', 'Staff Account Provisioning', 'System Settings']
    },
    'lab-tech': {
      allowed: ['Laboratory Serology (HIV/HBV/HCV/Syphilis)', 'ABO/Rh Confirmatory Typing', 'Antibody Screening', 'Clinical Unit Release / Reject Barrier Authorization', 'Recall Investigation Flags'],
      restricted: ['Direct Stock Balances Mutation without Audit', 'Blood Issue Dispatch', 'Hospital Requisition Approval', 'Staff Account Provisioning']
    },
    'donor-officer': {
      allowed: ['Donor Registration & Interviews', 'Vitals Pre-Screening', 'Donor Deferrals', 'Printable Donor Cards', 'Appointments Scheduling', 'SMS Reminders'],
      restricted: ['Laboratory Testing Results', 'Inventory Balances', 'Hospital Requisitions', 'Blood Issue Dispatch', 'Administrative Settings']
    },
    'hospital-officer': {
      allowed: ['Hospital Requisitions Submission', 'Emergency Trauma Requisition', 'Transfusion Outcome Feedback', 'Delivery Slips Acknowledgement'],
      restricted: ['Donor Medical Information', 'Laboratory Release Overrides', 'Direct Inventory Balances Mutation', 'User Management']
    },
    'report-viewer': {
      allowed: ['16 Standardized Regulatory Registers', 'Stock Level Inquiries', 'Audit Activity Logs Read-Only', 'CSV Export'],
      restricted: ['All State-Changing Mutations', 'Donor Intake', 'Laboratory Decisions', 'Blood Issue', 'Stock Discard']
    }
  };

  const selectTestAccount = (acc: typeof testAccounts[0]) => {
    setTestEmail(acc.email);
    setTestPassword('Admin@12345');
    setAuthTestResult(null);
  };

  const runAuthenticationTest = () => {
    const users = StorageService.getUsers();
    const user = users.find(u => u.email.toLowerCase() === testEmail.trim().toLowerCase());

    if (!user) {
      setAuthTestResult({
        status: 'error',
        message: 'Authentication Failed: No account matching this email was found in users database.'
      });
      return;
    }

    if (!user.isActive) {
      setAuthTestResult({
        status: 'error',
        message: 'Account Disabled: User profile is currently deactivated by system administrator.'
      });
      return;
    }

    if (testPassword !== 'Admin@12345') {
      const nextFailed = failedAttempts + 1;
      setFailedAttempts(nextFailed);
      if (nextFailed >= 5) {
        setAuthTestResult({
          status: 'error',
          message: 'Account Locked: 5 consecutive failed login attempts detected. Rate limit lock active for 15 minutes.'
        });
      } else {
        setAuthTestResult({
          status: 'error',
          message: `Invalid Password: password_verify() returned false. (${nextFailed}/5 failed attempts before lockout)`
        });
      }
      return;
    }

    // Success
    setFailedAttempts(0);
    const perms = rolePermissionsMap[user.role] || { allowed: [], restricted: [] };
    const simulatedSessionId = 'sess_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

    setAuthTestResult({
      status: 'success',
      message: `Authentication Successful for ${user.name} (${user.roleName})`,
      details: {
        staffId: user.staffId,
        name: user.name,
        roleName: user.roleName,
        sessionId: simulatedSessionId
      },
      allowedModules: perms.allowed,
      restrictedModules: perms.restricted
    });

    StorageService.logAudit('Auth Tester Verified', 'Security', user.staffId, `Verified credentials for ${user.email} (${user.role})`);
  };

  const testRateLimiting = () => {
    setFailedAttempts(5);
    setAuthTestResult({
      status: 'error',
      message: 'Rate Limiting Demonstration: 5 failed attempts reached. Account locked for 15 minutes with IP logging.'
    });
    StorageService.logAudit('Rate Limit Triggered', 'Security', 'RATE-LIMIT', `Brute force defense triggered for ${testEmail}`);
  };

  const applyActiveRole = () => {
    const users = StorageService.getUsers();
    const user = users.find(u => u.email.toLowerCase() === testEmail.trim().toLowerCase());
    if (user) {
      StorageService.setCurrentUser(user);
      if (onUserChange) {
        onUserChange(user);
      }
      alert(`System role switched to: ${user.name} (${user.roleName}). The entire app is now operating under this profile.`);
    }
  };

  const activeFile = files[selectedFileKey];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Phase 1 Architecture</span>
            <span aria-hidden="true">·</span>
            <span>PHP 8.2 & MySQL Codebase</span>
            <span aria-hidden="true">·</span>
            <span>Windows XAMPP Ready</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            XAMPP PHP & MySQL Architecture Center
          </h1>
        </div>

        <button
          onClick={() => {
            const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = selectedFileKey;
            a.click();
            URL.revokeObjectURL(url);
          }}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-800 hover:bg-red-900 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Download {selectedFileKey}</span>
        </button>
      </div>

      {/* Phase 1 Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-1.5">
          <div className="text-xs font-bold text-red-900 uppercase tracking-wider flex items-center gap-1.5">
            <Database className="w-4 h-4 text-red-700" />
            <span>Database Architecture</span>
          </div>
          <p className="text-xs text-slate-600">
            Normalized 30+ table InnoDB MySQL schema with strict foreign keys, optimistic locking (<code className="font-mono text-[11px]">version</code>), and zero cascade deletes on clinical history.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-1.5">
          <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <FolderTree className="w-4 h-4 text-slate-700" />
            <span>Clean MVC Architecture</span>
          </div>
          <p className="text-xs text-slate-600">
            Modular folder structure separates controllers, models, security middleware, and views outside the public web root to avoid directory exposure.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-1.5">
          <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Security & RBAC Controls</span>
          </div>
          <p className="text-xs text-slate-600">
            Enforces BCrypt password verification, session fixation prevention via <code className="font-mono text-[11px]">session_regenerate_id</code>, rate limiting, and server-side role validation.
          </p>
        </div>

      </div>

      {/* Code Explorer & Viewer */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50 gap-2">
          
          <div className="flex items-center gap-2 overflow-x-auto">
            {Object.entries(files).map(([key, file]) => (
              <button
                key={key}
                onClick={() => setSelectedFileKey(key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  selectedFileKey === key 
                    ? 'bg-white text-red-900 font-bold shadow-xs border border-slate-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {key}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">{activeFile.path}</span>
            <button
              onClick={() => copyToClipboard(activeFile.content, selectedFileKey)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded cursor-pointer transition-colors"
            >
              {copiedKey === selectedFileKey ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Code Content Block */}
        <div className="p-4 bg-slate-950 overflow-x-auto text-xs text-slate-200 font-mono leading-relaxed max-h-[500px]">
          <pre>{activeFile.content}</pre>
        </div>
      </div>

      {/* Phase 1 Execution Checklist */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-slate-800" />
          <span>Phase 1 Verification & Testing Steps (Windows XAMPP)</span>
        </h3>

        <div className="space-y-2 text-xs text-slate-700">
          <div className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded border border-slate-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong>Step 1: Start XAMPP Services</strong> — Open XAMPP Control Panel as Administrator. Click <em>Start</em> on Apache and MySQL. Ensure both ports (80/8080 and 3306) display green.
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded border border-slate-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong>Step 2: Database Creation</strong> — Open <code className="font-mono text-red-900">http://localhost/phpmyadmin</code>, create database <code className="font-mono text-red-900">blood_bank_db</code> with <code className="font-mono text-[11px]">utf8mb4_unicode_ci</code>, and import <code className="font-mono text-[11px]">database/schema.sql</code> followed by <code className="font-mono text-[11px]">database/seed.sql</code>.
            </div>
          </div>

          {/* Step 3: Test Multi-Role Authentication with Full Interactive Functionality */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900 text-xs">
                    Step 3: Test Multi-Role Authentication & Permission Barriers
                  </div>
                  <div className="text-slate-600 text-xs mt-0.5">
                    Navigate to <code className="font-mono text-red-900 bg-red-50 px-1 py-0.5 rounded">http://localhost/blood-bank-management/public</code>. Log in using any of the 7 pre-seeded roles with password <code className="font-mono text-slate-900 font-bold bg-slate-200 px-1 py-0.5 rounded">Admin@12345</code>.
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAuthTester(!showAuthTester)}
                className="px-2.5 py-1 text-xs font-semibold text-red-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded cursor-pointer transition-colors shrink-0 flex items-center gap-1.5 self-start"
              >
                <KeyRound className="w-3.5 h-3.5 text-red-700" />
                <span>{showAuthTester ? 'Hide Auth Tester' : 'Launch Auth Tester'}</span>
              </button>
            </div>

            {/* Interactive Multi-Role Testing Console */}
            {showAuthTester && (
              <div className="mt-3 pt-3 border-t border-slate-200 space-y-3.5 animate-in fade-in duration-150">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-red-800" />
                    <span>Live RBAC Credential & Session Tester</span>
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Simulates PHP 8.2 <code className="font-mono text-slate-700">password_verify()</code> &amp; session regeneration
                  </span>
                </div>

                {/* Role Selector Tabs */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-semibold text-slate-700">
                    Select Test Account (All 7 Clinical Roles):
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {testAccounts.map((acc) => (
                      <button
                        key={acc.email}
                        type="button"
                        onClick={() => selectTestAccount(acc)}
                        className={`px-2 py-1 text-[11px] font-medium rounded transition-colors cursor-pointer border ${
                          testEmail === acc.email
                            ? 'bg-red-800 text-white border-red-800 font-semibold shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {acc.roleName}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Credential Inputs & Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-600 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={testEmail}
                      onChange={(e) => setTestEmail(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white font-mono text-xs focus:ring-1 focus:ring-red-800 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-600 mb-1">
                      Password (BCrypt verified)
                    </label>
                    <input
                      type="text"
                      value={testPassword}
                      onChange={(e) => setTestPassword(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white font-mono text-xs focus:ring-1 focus:ring-red-800 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                  <button
                    type="button"
                    onClick={runAuthenticationTest}
                    className="px-3 py-1.5 font-semibold text-white bg-red-800 hover:bg-red-900 rounded cursor-pointer transition-colors shadow-xs flex items-center gap-1.5"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Verify Credentials &amp; Permissions</span>
                  </button>

                  <button
                    type="button"
                    onClick={testRateLimiting}
                    className="px-2.5 py-1.5 font-medium text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded cursor-pointer transition-colors flex items-center gap-1"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-700" />
                    <span>Test Rate Limiting (5 failed logins)</span>
                  </button>

                  <button
                    type="button"
                    onClick={applyActiveRole}
                    className="px-2.5 py-1.5 font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded cursor-pointer transition-colors flex items-center gap-1"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-slate-600" />
                    <span>Set as Active App Role</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => copyToClipboard(`${testEmail} / ${testPassword}`, 'creds')}
                    className="px-2.5 py-1.5 font-medium text-slate-600 hover:text-slate-900 ml-auto cursor-pointer flex items-center gap-1"
                  >
                    {copiedKey === 'creds' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Copy Credentials</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Live Auth Diagnostic Result Console */}
                {authTestResult && (
                  <div
                    className={`p-3 rounded-lg border text-xs font-mono space-y-2 ${
                      authTestResult.status === 'success'
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                        : 'bg-red-50/70 border-red-200 text-red-950'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1.5 font-sans">
                        {authTestResult.status === 'success' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-red-700 shrink-0" />
                        )}
                        <span>{authTestResult.message}</span>
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">HTTP 200 OK</span>
                    </div>

                    {authTestResult.details && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-emerald-200/60 text-[11px]">
                        <div>
                          <span className="text-slate-500 block font-sans">Authenticated User:</span>
                          <strong>{authTestResult.details.name}</strong> ({authTestResult.details.staffId})
                        </div>
                        <div>
                          <span className="text-slate-500 block font-sans">Role Assigned:</span>
                          <strong>{authTestResult.details.roleName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block font-sans">Session ID Regenerated:</span>
                          <span className="truncate block font-mono text-slate-700">
                            {authTestResult.details.sessionId}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block font-sans">CSRF Protection:</span>
                          <span className="text-emerald-800 font-semibold font-sans">Active &amp; Validated</span>
                        </div>
                      </div>
                    )}

                    {authTestResult.allowedModules && (
                      <div className="pt-2 border-t border-emerald-200/60 space-y-1 font-sans text-xs">
                        <div>
                          <span className="font-semibold text-emerald-900">Authorized Clinical Modules:</span>
                          <div className="flex flex-wrap gap-1 mt-0.5">
                            {authTestResult.allowedModules.map((m: string) => (
                              <span
                                key={m}
                                className="px-1.5 py-0.5 bg-emerald-100 text-emerald-900 rounded text-[10px] font-medium"
                              >
                                {m}
                              </span>
                            ))}
                          </div>
                        </div>

                        {authTestResult.restrictedModules && authTestResult.restrictedModules.length > 0 && (
                          <div className="pt-1">
                            <span className="font-semibold text-red-800">Restricted / Blocked Modules (403 Forbidden):</span>
                            <div className="flex flex-wrap gap-1 mt-0.5">
                              {authTestResult.restrictedModules.map((m: string) => (
                                <span
                                  key={m}
                                  className="px-1.5 py-0.5 bg-red-100 text-red-900 rounded text-[10px] font-medium"
                                >
                                  {m}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
};
