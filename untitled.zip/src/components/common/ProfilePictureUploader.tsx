import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Upload, 
  Trash2, 
  User as UserIcon, 
  Sparkles,
  Check
} from 'lucide-react';

interface ProfilePictureUploaderProps {
  currentAvatarUrl?: string;
  userName?: string;
  onChange: (avatarUrl: string | undefined) => void;
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  helpText?: string;
}

// Preset Clinical Medical Avatars with distinct healthcare iconography
const PRESET_AVATARS = [
  {
    id: 'physician-female',
    name: 'Physician (Female)',
    bg: '#047857',
    iconColor: '#ecfdf5',
    svg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23047857"/><circle cx="50" cy="38" r="18" fill="%23ffffff"/><path d="M22 84c0-15 12-26 28-26s28 11 28 26" fill="%23ffffff"/><circle cx="50" cy="38" r="8" fill="%2310b981"/><path d="M46 64h8v16h-8z" fill="%23047857"/><path d="M42 68h16v8h-16z" fill="%23047857"/></svg>`
  },
  {
    id: 'chief-officer',
    name: 'Chief Medical Director',
    bg: '#991b1b',
    iconColor: '#fef2f2',
    svg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23991b1b"/><circle cx="50" cy="36" r="17" fill="%23ffffff"/><path d="M22 84c0-14 12-25 28-25s28 11 28 25" fill="%23ffffff"/><path d="M47 50h6v12h-6z" fill="%23991b1b"/><path d="M44 53h12v6h-12z" fill="%23991b1b"/><polygon points="50,14 55,24 66,24 57,30 60,40 50,34 40,40 43,30 34,24 45,24" fill="%23f59e0b"/></svg>`
  },
  {
    id: 'lab-specialist',
    name: 'Serology Specialist',
    bg: '#1e40af',
    iconColor: '#eff6ff',
    svg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%231e40af"/><circle cx="50" cy="37" r="17" fill="%23ffffff"/><path d="M20 84c0-14 13-25 30-25s30 11 30 25" fill="%23ffffff"/><path d="M46 64h8v18h-8z" fill="%2338bdf8"/><circle cx="50" cy="34" r="5" fill="%230284c7"/></svg>`
  },
  {
    id: 'transfusion-tech',
    name: 'Blood Bank Tech',
    bg: '#b91c1c',
    iconColor: '#fff1f2',
    svg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23b91c1c"/><circle cx="50" cy="36" r="17" fill="%23ffffff"/><path d="M20 84c0-14 13-25 30-25s30 11 30 25" fill="%23ffffff"/><path d="M50 63c-3-4-8-1-8 3 0 4 8 10 8 10s8-6 8-10c0-4-5-7-8-3z" fill="%23ef4444"/></svg>`
  },
  {
    id: 'admin-governance',
    name: 'System Governance',
    bg: '#0f172a',
    iconColor: '#f8fafc',
    svg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%230f172a"/><circle cx="50" cy="36" r="17" fill="%23ffffff"/><path d="M20 84c0-14 13-25 30-25s30 11 30 25" fill="%23ffffff"/><circle cx="50" cy="72" r="5" fill="%23e2e8f0"/><path d="M47 62h6v6h-6z" fill="%23e2e8f0"/></svg>`
  }
];

export const ProfilePictureUploader: React.FC<ProfilePictureUploaderProps> = ({
  currentAvatarUrl,
  userName = 'User',
  onChange,
  size = 'md',
  label = 'Profile Photo',
  helpText = 'Upload PNG, JPG, or SVG up to 2MB. Square ratio recommended.'
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [showPresets, setShowPresets] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sizeClasses = {
    sm: 'w-12 h-12 text-sm',
    md: 'w-20 h-20 text-xl',
    lg: 'w-24 h-24 text-2xl'
  }[size];

  const handleFileProcess = (file: File) => {
    setError(null);
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (PNG, JPG, WebP, SVG).');
      return;
    }

    if (file.size > 2.5 * 1024 * 1024) {
      setError('Image file must be smaller than 2.5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onChange(result);
        setShowPresets(false);
      }
    };
    reader.onerror = () => {
      setError('Error reading file. Please try another image.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const getInitials = (name: string) => {
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  return (
    <div className="space-y-3">
      {label && (
        <label className="block text-xs font-semibold text-slate-700">
          {label}
        </label>
      )}

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        {/* Avatar Display Frame with Live Drop Target */}
        <div 
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`relative rounded-full shrink-0 flex items-center justify-center overflow-hidden border-2 transition-all ${sizeClasses} ${
            isDragging 
              ? 'border-red-600 ring-4 ring-red-100 scale-105' 
              : 'border-slate-200 bg-slate-100 shadow-xs'
          }`}
        >
          {currentAvatarUrl ? (
            <img 
              src={currentAvatarUrl} 
              alt={userName} 
              className="w-full h-full object-cover" 
            />
          ) : (
            <span className="font-bold text-slate-600 tracking-wider">
              {getInitials(userName)}
            </span>
          )}

          {/* Quick Upload Hover Overlay */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Upload photo"
            className="absolute inset-0 bg-slate-900/50 text-white flex flex-col items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
          >
            <Camera className="w-5 h-5 mb-0.5" />
            <span className="text-[9px] font-semibold">Change</span>
          </button>
        </div>

        {/* Action Buttons & Input */}
        <div className="space-y-1.5 flex-1">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/png,image/jpeg,image/webp,image/svg+xml" 
            className="hidden" 
          />

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md transition-colors cursor-pointer shadow-xs"
            >
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              <span>Choose Photo</span>
            </button>

            <button
              type="button"
              onClick={() => setShowPresets(!showPresets)}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-red-700" />
              <span>Preset Avatars</span>
            </button>

            {currentAvatarUrl && (
              <button
                type="button"
                onClick={() => {
                  onChange(undefined);
                  setError(null);
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-md transition-colors cursor-pointer"
                title="Remove current avatar"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove</span>
              </button>
            )}
          </div>

          <p className="text-[11px] text-slate-400">
            {helpText}
          </p>

          {error && (
            <p className="text-[11px] text-rose-600 font-medium">
              {error}
            </p>
          )}
        </div>
      </div>

      {/* Preset Medical Avatars Picker Drawer */}
      {showPresets && (
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2 animate-in fade-in duration-150">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-red-700" />
              Clinical Preset Badges
            </span>
            <button 
              type="button" 
              onClick={() => setShowPresets(false)}
              className="text-[11px] text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {PRESET_AVATARS.map((preset) => {
              const isSelected = currentAvatarUrl === preset.svg;
              return (
                <button
                  type="button"
                  key={preset.id}
                  onClick={() => {
                    onChange(preset.svg);
                    setShowPresets(false);
                    setError(null);
                  }}
                  className={`flex flex-col items-center p-2 rounded-md border text-center transition-all cursor-pointer ${
                    isSelected 
                      ? 'border-red-800 bg-red-50/50 ring-2 ring-red-800/20' 
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  <div className="relative w-10 h-10 rounded-full overflow-hidden mb-1 border border-slate-200">
                    <img src={preset.svg} alt={preset.name} className="w-full h-full object-cover" />
                    {isSelected && (
                      <div className="absolute inset-0 bg-red-900/40 flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] font-medium text-slate-700 truncate w-full">
                    {preset.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
