/**
 * LifeBlood — Advanced Blood Bank Management System (BBMS)
 * Enterprise-grade Clinical Blood Banking Platform
 */

import React, { useState, useEffect } from 'react';
import { StorageService } from './services/storage';
import { User } from './types';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { DonorManagement } from './components/donors/DonorManagement';
import { DonationManagement } from './components/donations/DonationManagement';
import { BloodGroupsView } from './components/blood-groups/BloodGroupsView';
import { ComponentManagement } from './components/components/ComponentManagement';
import { InventoryManagement } from './components/inventory/InventoryManagement';
import { LaboratoryWorkflow } from './components/laboratory/LaboratoryWorkflow';
import { BloodRequestsView } from './components/requests/BloodRequestsView';
import { HospitalManagement } from './components/hospitals/HospitalManagement';
import { BloodIssueView } from './components/issues/BloodIssueView';
import { AlertsCenter } from './components/alerts/AlertsCenter';
import { AppointmentsView } from './components/appointments/AppointmentsView';
import { ReportsView } from './components/reports/ReportsView';
import { UserManagement } from './components/users/UserManagement';
import { AuditLogsView } from './components/audit/AuditLogsView';
import { SystemSettingsView } from './components/settings/SystemSettingsView';
import { CodeExportCenter } from './components/code-export/CodeExportCenter';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>(() => StorageService.getCurrentUser());
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [isArabic, setIsArabic] = useState<boolean>(false);

  useEffect(() => {
    // Initialize storage seed if empty
    StorageService.init();
  }, []);

  const handleToggleArabic = () => {
    const next = !isArabic;
    setIsArabic(next);
    if (next) {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = 'en';
    }
  };

  const handleQuickAction = (action: string) => {
    if (action === 'register-donor') {
      setActiveView('donors');
    } else if (action === 'record-donation') {
      setActiveView('donations');
    } else if (action === 'new-request') {
      setActiveView('requests');
    }
  };

  const renderActiveView = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <DashboardView 
            currentUser={currentUser} 
            onNavigate={setActiveView} 
            onOpenQuickAction={handleQuickAction}
          />
        );
      case 'donors':
        return <DonorManagement />;
      case 'donations':
        return <DonationManagement currentUser={currentUser} />;
      case 'blood-groups':
        return <BloodGroupsView />;
      case 'components':
        return <ComponentManagement />;
      case 'inventory':
        return <InventoryManagement />;
      case 'laboratory':
        return <LaboratoryWorkflow currentUser={currentUser} />;
      case 'requests':
        return <BloodRequestsView currentUser={currentUser} onNavigate={setActiveView} />;
      case 'hospitals':
        return <HospitalManagement />;
      case 'issues':
        return <BloodIssueView currentUser={currentUser} />;
      case 'alerts':
        return <AlertsCenter currentUser={currentUser} />;
      case 'appointments':
        return <AppointmentsView />;
      case 'reports':
        return <ReportsView />;
      case 'users':
        return <UserManagement />;
      case 'audit':
        return <AuditLogsView />;
      case 'settings':
        return (
          <SystemSettingsView 
            isArabic={isArabic} 
            onToggleArabic={handleToggleArabic} 
            currentUser={currentUser} 
            onUserUpdate={setCurrentUser} 
          />
        );
      case 'code-export':
        return <CodeExportCenter onUserChange={setCurrentUser} />;
      default:
        return (
          <DashboardView 
            currentUser={currentUser} 
            onNavigate={setActiveView} 
            onOpenQuickAction={handleQuickAction}
          />
        );
    }
  };

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 text-slate-800 ${isArabic ? 'font-serif' : ''}`}>
      
      {/* Top Navigation Bar adhering to Top Bar Contract */}
      <Navbar
        currentUser={currentUser}
        onUserChange={setCurrentUser}
        onNavigate={setActiveView}
        activeView={activeView}
        isArabic={isArabic}
        onToggleArabic={handleToggleArabic}
      />

      {/* Main Layout Body with Collapsible Sidebar & Content Canvas */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeView={activeView}
          onNavigate={setActiveView}
          currentUser={currentUser}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {renderActiveView()}
        </main>
      </div>

    </div>
  );
}
