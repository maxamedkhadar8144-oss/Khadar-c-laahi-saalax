/**
 * LifeBlood BBMS - Comprehensive Domain Models & Type Definitions
 */

export type RoleSlug = 
  | 'super-admin' 
  | 'blood-bank-admin' 
  | 'blood-bank-tech' 
  | 'lab-tech' 
  | 'donor-officer' 
  | 'hospital-officer' 
  | 'report-viewer';

export interface User {
  id: number;
  staffId: string;
  name: string;
  email: string;
  phone?: string;
  jobTitle?: string;
  role: RoleSlug;
  roleName: string;
  department: string;
  facility?: string;
  avatarUrl?: string;
  isActive: boolean;
  lastLoginAt?: string;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export type ComponentCode = 'WB' | 'PRBC' | 'PLT' | 'FFP' | 'CRYO';

export interface ComponentDefinition {
  code: ComponentCode;
  name: string;
  storageTemp: string;
  shelfLifeDays: number;
  standardVolumeMl: number;
  requiresAgitation: boolean;
}

export type UnitStatus = 
  | 'Collected' 
  | 'Quarantined' 
  | 'Under Testing' 
  | 'Released' 
  | 'Reserved' 
  | 'Issued' 
  | 'Expired' 
  | 'Discarded' 
  | 'Recalled' 
  | 'Transferred';

export interface Donor {
  id: number;
  donorNumber: string;
  firstName: string;
  lastName: string;
  nationalId: string;
  dateOfBirth: string;
  sex: 'Male' | 'Female' | 'Other';
  bloodGroup: BloodGroup;
  phone: string;
  email: string;
  address: string;
  city: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  status: 'Active' | 'Temporarily Deferred' | 'Permanently Deferred' | 'Inactive';
  consentSigned: boolean;
  consentDate: string;
  totalDonations: number;
  lastDonationDate?: string;
  nextEligibleDate?: string;
  preferredContact: 'SMS' | 'Email' | 'Phone';
  registeredBy: string;
  createdAt: string;
}

export interface DonorScreening {
  id: number;
  donorId: number;
  screeningDate: string;
  weightKg: number;
  hemoglobinGDl: number;
  systolicBp: number;
  diastolicBp: number;
  pulseBpm: number;
  tempCelsius: number;
  passedQuestionnaire: boolean;
  isEligible: boolean;
  notes?: string;
}

export interface DeferralRecord {
  id: number;
  donorId: number;
  type: 'Temporary' | 'Permanent';
  reason: string;
  startDate: string;
  endDate?: string;
  authorizedBy: string;
  notes?: string;
}

export interface Donation {
  id: number;
  donationNumber: string;
  donorId: number;
  donorName: string;
  donorNumber: string;
  bloodGroup: BloodGroup;
  centerName: string;
  donationDate: string;
  collectionType: 'Whole Blood' | 'Apheresis Platelets' | 'Apheresis Plasma';
  volumeMl: number;
  bagBarcode: string;
  anticoagulantBatch: string;
  outcome: 'Successful' | 'Incomplete' | 'Failed';
  hasAdverseReaction: boolean;
  reactionNotes?: string;
  phlebotomist: string;
}

export interface BloodUnit {
  id: number;
  unitBarcode: string;
  donationId: number;
  donationNumber: string;
  parentUnitBarcode?: string; // If derived from Whole Blood
  componentCode: ComponentCode;
  componentName: string;
  bloodGroup: BloodGroup;
  volumeMl: number;
  collectionDate: string;
  expiryDate: string;
  storageLocation: string;
  status: UnitStatus;
  discardReason?: string;
  reservedForRequestId?: number;
  issuedToHospitalId?: number;
  version: number;
}

export interface LabTest {
  id: number;
  unitId: number;
  unitBarcode: string;
  sampleBarcode: string;
  bloodGroupOriginal: BloodGroup;
  aboVerified: 'A' | 'B' | 'AB' | 'O';
  rhVerified: 'Positive' | 'Negative';
  antibodyScreen: 'Negative' | 'Positive' | 'Inconclusive';
  hivResult: 'Non-Reactive' | 'Reactive' | 'Pending';
  hbsagResult: 'Non-Reactive' | 'Reactive' | 'Pending';
  hcvResult: 'Non-Reactive' | 'Reactive' | 'Pending';
  syphilisResult: 'Non-Reactive' | 'Reactive' | 'Pending';
  overallDecision: 'Pending' | 'Released' | 'Rejected';
  testedBy: string;
  verifiedBy?: string;
  verifiedAt?: string;
  testedAt: string;
  notes?: string;
}

export interface CrossmatchRecord {
  id: number;
  requestId: number;
  unitId: number;
  unitBarcode: string;
  patientReference: string;
  method: 'Immediate Spin' | 'Indirect Antiglobulin Test (IAT)' | 'Gel Card';
  result: 'Compatible' | 'Incompatible' | 'Inconclusive';
  verificationCode: string;
  technician: string;
  testedAt: string;
}

export interface BloodRequest {
  id: number;
  requestNumber: string;
  hospitalId: number;
  hospitalName: string;
  requestingClinician: string;
  clinicianPhone: string;
  patientReference: string;
  patientNameMasked: string;
  patientBloodGroup: BloodGroup;
  componentCode: ComponentCode;
  unitsRequested: number;
  unitsIssued: number;
  clinicalIndication: string;
  priority: 'Routine' | 'Urgent' | 'Emergency';
  status: 'Draft' | 'Submitted' | 'Under Review' | 'Approved' | 'Partially Fulfilled' | 'Fulfilled' | 'Rejected' | 'Cancelled';
  requiredBy: string;
  rejectionReason?: string;
  reservedUnitBarcodes?: string[];
  createdAt: string;
}

export interface Hospital {
  id: number;
  hospitalCode: string;
  name: string;
  facilityType: 'Tertiary Hospital' | 'Regional Referral Hospital' | 'Specialized Trauma Center' | 'Maternity Hospital' | 'Private Clinic';
  address: string;
  city: string;
  phone: string;
  email: string;
  licenseNumber: string;
  contactPerson: string;
  contactPhone: string;
  isActive: boolean;
}

export interface BloodIssue {
  id: number;
  issueSlipNumber: string;
  requestId: number;
  requestNumber: string;
  unitId: number;
  unitBarcode: string;
  componentCode: ComponentCode;
  bloodGroup: BloodGroup;
  hospitalName: string;
  receivingOfficer: string;
  receivingOfficerId: string;
  transportTempCelsius: number;
  transportBoxId: string;
  issuedBy: string;
  issuedAt: string;
}

export interface BloodReturn {
  id: number;
  issueId: number;
  issueSlipNumber: string;
  unitBarcode: string;
  returnDate: string;
  reason: string;
  coldChainMaintained: boolean;
  visualInspectionPassed: boolean;
  inspectionDecision: 'Restocked to Quarantine' | 'Discarded as Wastage';
  inspectedBy: string;
  notes?: string;
}

export interface RecallRecord {
  id: number;
  recallCode: string;
  reason: string;
  severity: 'Critical' | 'High' | 'Moderate';
  donorId?: number;
  donorNumber?: string;
  affectedUnitBarcodes: string[];
  status: 'Active' | 'Investigating' | 'Quarantined' | 'Resolved';
  actionTaken?: string;
  initiatedBy: string;
  createdAt: string;
}

export interface Appointment {
  id: number;
  donorId: number;
  donorName: string;
  donorNumber: string;
  bloodGroup: BloodGroup;
  phone: string;
  centerName: string;
  appointmentDate: string;
  appointmentTime: string;
  status: 'Scheduled' | 'Confirmed' | 'Completed' | 'Cancelled' | 'No-Show';
  reminderSent: boolean;
  notes?: string;
}

export interface AuditLogEntry {
  id: number;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  entityId: string;
  details: string;
  ipAddress: string;
}

export interface BackupSnapshot {
  id: string;
  name: string;
  createdAt: string;
  sizeKb: number;
  recordCount: number;
  createdBy: string;
  notes?: string;
  version: string;
  data: string; // Serialized JSON data of the database state
}

export interface SystemSettings {
  organizationName: string;
  licenseNumber?: string;
  hotlinePhone: string;
  officialEmail?: string;
  websiteUrl?: string;
  headquartersAddress?: string;
  defaultLanguage: 'en' | 'so' | 'ar';
  enableFefo: boolean;
  sessionTimeoutMinutes: number;
  emergencyONegativeReserve: number;
  autoQuarantineTesting: boolean;
  maxFailedLoginAttempts: number;
  lockoutDurationMinutes: number;
  theme: 'light' | 'dark';
  departments?: string[];
  storageLocations?: string[];
  maintenanceMode?: boolean;
}

