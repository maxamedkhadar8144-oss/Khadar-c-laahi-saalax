<?php
/**
 * LifeBlood BBMS - Database Connection Manager
 * Secure PDO Singleton with Prepared Statements and Error Handling
 * Compatible with PHP 8.2+ and MySQL / MariaDB on XAMPP Windows
 */

declare(strict_types=1);

namespace App\Config;

use PDO;
use PDOException;

class Database
{
    private static ?PDO $instance = null;

    private static string $host = '127.0.0.1';
    private static string $dbname = 'blood_bank_db';
    private static string $user = 'root';
    private static string $password = ''; // Default empty password for XAMPP
    private static string $charset = 'utf8mb4';

    /**
     * Get singleton PDO database connection instance
     */
    public static function getConnection(): PDO
    {
        if (self::$instance === null) {
            // Load overrides from environment if present
            $host = getenv('DB_HOST') ?: self::$host;
            $dbname = getenv('DB_NAME') ?: self::$dbname;
            $user = getenv('DB_USER') ?: self::$user;
            $pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : self::$password;
            $port = getenv('DB_PORT') ?: '3306';

            $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=" . self::$charset;

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false, // Always use real native prepared statements
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            try {
                self::$instance = new PDO($dsn, $user, $pass, $options);
            } catch (PDOException $e) {
                // Log detailed error privately, never expose raw DB credentials to user
                error_log("LifeBlood DB Connection Failure: " . $e->getMessage());
                http_response_code(500);
                die(json_encode([
                    'success' => false,
                    'message' => 'Database connection failed. Please ensure MySQL is running in XAMPP and database/schema.sql has been imported into `blood_bank_db`.'
                ]));
            }
        }

        return self::$instance;
    }
}
