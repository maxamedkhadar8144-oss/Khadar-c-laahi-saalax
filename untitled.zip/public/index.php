<?php
/**
 * LifeBlood — Blood Bank Management System (BBMS)
 * Front Controller & Routing Gateway (PHP 8.2+ / XAMPP Windows)
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../app/Helpers/Security.php';
require_once __DIR__ . '/../app/Helpers/Auth.php';

use App\Config\Database;
use App\Helpers\Security;
use App\Helpers\Auth;

Security::startSecureSession();

$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$basePath = '/blood-bank-management/public';

// Normalize URI
$route = str_replace($basePath, '', $requestUri);
$route = trim($route, '/');

// Handle API / AJAX or Server Page Requests
if ($route === '' || $route === 'index.php') {
    // If not authenticated, redirect to login
    if (!Auth::check()) {
        header('Location: ' . $basePath . '/login.php');
        exit;
    }
    // Render Dashboard Overview
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'operational',
        'system' => 'LifeBlood Transfusion Authority',
        'version' => '2.4.0',
        'authenticated_user' => Auth::user(),
        'instructions' => 'Welcome to LifeBlood BBMS. Access clinical modules via authenticated routes or through the interactive management dashboard.'
    ]);
    exit;
}

if ($route === 'api/status') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("SELECT COUNT(*) AS total_units FROM blood_units WHERE status = 'Released'");
        $row = $stmt->fetch();
        echo json_encode([
            'database' => 'connected',
            'released_stock_units' => (int)($row['total_units'] ?? 0),
            'server_time' => date('Y-m-d H:i:s')
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// 404 handler
http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'error' => 'Route not found',
    'route' => $route
]);
