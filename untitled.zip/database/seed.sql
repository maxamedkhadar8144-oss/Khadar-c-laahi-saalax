-- ==============================================================================
-- LIFEBLOOD — ADVANCED BLOOD BANK MANAGEMENT SYSTEM (BBMS)
-- COMPREHENSIVE SEED DATA FOR TESTING & PRODUCTION INITIALIZATION
-- ==============================================================================

USE `blood_bank_db`;

-- ------------------------------------------------------------------------------
-- 1. SEED ROLES
-- ------------------------------------------------------------------------------
INSERT INTO `roles` (`id`, `slug`, `name`, `description`) VALUES
(1, 'super-admin', 'Super Administrator', 'Full system access, audit logs, configuration, and user permissions'),
(2, 'blood-bank-admin', 'Blood Bank Administrator', 'Operations supervision, stock thresholds, staff management, approvals'),
(3, 'blood-bank-tech', 'Blood Bank Technician', 'Component fractionation, storage handling, quarantine and issue processing'),
(4, 'lab-tech', 'Laboratory Technician', 'Immunohematology, infectious disease screening panels, release verification'),
(5, 'donor-officer', 'Donor Registration Officer', 'Donor intake, eligibility check, deferral recording, appointment scheduling'),
(6, 'hospital-officer', 'Hospital Requesting Officer', 'Hospital blood requisitions, urgency prioritization, delivery tracking'),
(7, 'report-viewer', 'Report Viewer', 'Read-only access to statistical analytics, stock reports, and clinical audits');

-- ------------------------------------------------------------------------------
-- 2. SEED BLOOD GROUPS (ABO & Rh Factor)
-- ------------------------------------------------------------------------------
INSERT INTO `blood_groups` (`id`, `group_name`, `abo_type`, `rh_factor`, `min_stock_threshold`, `critical_shortage_threshold`, `description`) VALUES
(1, 'A+', 'A', 'Positive', 25, 8, 'A RhD Positive - Can receive A+, A-, O+, O-'),
(2, 'A-', 'A', 'Negative', 15, 5, 'A RhD Negative - Can receive A-, O-'),
(3, 'B+', 'B', 'Positive', 20, 6, 'B RhD Positive - Can receive B+, B-, O+, O-'),
(4, 'B-', 'B', 'Negative', 12, 4, 'B RhD Negative - Can receive B-, O-'),
(5, 'AB+', 'AB', 'Positive', 15, 4, 'AB RhD Positive - Universal recipient for red blood cells'),
(6, 'AB-', 'AB', 'Negative', 10, 3, 'AB RhD Negative - Can receive A-, B-, AB-, O-'),
(7, 'O+', 'O', 'Positive', 35, 12, 'O RhD Positive - Can receive O+, O-'),
(8, 'O-', 'O', 'Negative', 30, 10, 'O RhD Negative - Universal red cell donor for emergency uncrossmatched blood');

-- ------------------------------------------------------------------------------
-- 3. SEED BLOOD COMPONENTS
-- ------------------------------------------------------------------------------
INSERT INTO `blood_components` (`id`, `code`, `name`, `storage_temp_celsius`, `default_shelf_life_days`, `standard_unit_volume_ml`, `requires_agitation`) VALUES
(1, 'WB', 'Whole Blood', '2°C to 6°C', 35, 450, 0),
(2, 'PRBC', 'Packed Red Blood Cells', '2°C to 6°C', 42, 280, 0),
(3, 'PLT', 'Platelets (Single Donor/Pool)', '20°C to 24°C', 5, 250, 1),
(4, 'FFP', 'Fresh Frozen Plasma', '-18°C or colder', 365, 220, 0),
(5, 'CRYO', 'Cryoprecipitate AHF', '-18°C or colder', 365, 40, 0);

-- ------------------------------------------------------------------------------
-- 4. SEED DONATION CENTERS & STORAGE UNITS
-- ------------------------------------------------------------------------------
INSERT INTO `donation_centers` (`id`, `code`, `name`, `address`, `city`, `phone`) VALUES
(1, 'CTR-HQ', 'Metropolitan Blood Transfusion Center', '452 Medical Center Blvd', 'Capital City', '+1-555-019-2831'),
(2, 'CTR-NORTH', 'Northside Community Donor Clinic', '108 Civic Plaza Road', 'Northwood', '+1-555-019-5820'),
(3, 'CTR-EAST', 'University Teaching Hospital Blood Hub', '89 Academic Way', 'Eastgate', '+1-555-019-7744');

INSERT INTO `storage_locations` (`id`, `center_id`, `location_code`, `location_name`, `equipment_type`, `target_temp_min`, `target_temp_max`, `capacity_units`) VALUES
(1, 1, 'FRIDGE-A1', 'Main Red Cell Cold Room #1', 'Blood Bank Refrigerator', 2.0, 6.0, 600),
(2, 1, 'FRIDGE-A2', 'Emergency O- Reserve Fridge', 'Blood Bank Refrigerator', 2.0, 6.0, 200),
(3, 1, 'FREEZER-B1', 'Ultra-Low Plasma Deep Freezer #1', 'Ultra-Low Freezer', -30.0, -18.0, 800),
(4, 1, 'AGITATOR-C1', 'Controlled Agitation Platelet Incubator', 'Platelet Agitator', 20.0, 24.0, 150),
(5, 1, 'QUARANTINE-Q1', 'Pre-Testing Quarantine Cooler', 'Quarantine Cooler', 2.0, 6.0, 300);

-- ------------------------------------------------------------------------------
-- 5. SEED HOSPITALS
-- ------------------------------------------------------------------------------
INSERT INTO `hospitals` (`id`, `hospital_code`, `name`, `facility_type`, `address`, `city`, `phone`, `email`, `license_number`, `contact_person`, `contact_phone`) VALUES
(1, 'HOSP-001', 'St. Jude General Hospital', 'Tertiary Hospital', '1200 Mercy Drive', 'Capital City', '+1-555-882-1000', 'bloodbank@stjude.org', 'LIC-MED-2024-9981', 'Dr. Evelyn Vance (Chief Hematologist)', '+1-555-882-1044'),
(2, 'HOSP-002', 'City Trauma & Emergency Center', 'Specialized Trauma Center', '77 Responder Ave', 'Capital City', '+1-555-911-3000', 'trauma.blood@citytrauma.gov', 'LIC-MED-2023-4120', 'Dr. Marcus Sterling (Trauma Director)', '+1-555-911-3022'),
(3, 'HOSP-003', 'Northwood Maternal & Pediatric Center', 'Maternity Hospital', '304 Blossom Street', 'Northwood', '+1-555-344-9000', 'orders@northwoodmaternal.org', 'LIC-MED-2025-0711', 'Nurse Supervisor Aisha Noor', '+1-555-344-9018'),
(4, 'HOSP-004', 'Highland Memorial Regional Hospital', 'Regional Referral Hospital', '500 Highland Peak Rd', 'Highland', '+1-555-722-4400', 'lab@highlandmemorial.org', 'LIC-MED-2022-8823', 'Dr. Tariq Farooq (Blood Bank Liason)', '+1-555-722-4412');

-- ------------------------------------------------------------------------------
-- 6. SEED USERS (Password for all demo accounts: 'Admin@12345' hashed with BCRYPT)
-- Hash generated via password_hash('Admin@12345', PASSWORD_BCRYPT)
-- ------------------------------------------------------------------------------
INSERT INTO `users` (`id`, `staff_id`, `name`, `email`, `password_hash`, `phone`, `role_id`, `department`, `is_active`) VALUES
(1, 'STAFF-001', 'Dr. Amina Yusuf', 'admin@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0001', 1, 'Executive Administration', 1),
(2, 'STAFF-002', 'Farah Hassan', 'operations@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0002', 2, 'Operations Management', 1),
(3, 'STAFF-003', 'Elena Rostova', 'lab@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0003', 4, 'Immunohematology Laboratory', 1),
(4, 'STAFF-004', 'Khadar Jama', 'tech@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0004', 3, 'Component Processing & Inventory', 1),
(5, 'STAFF-005', 'Sarah Jenkins', 'donors@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0005', 5, 'Donor Relations & Recruitment', 1),
(6, 'STAFF-006', 'Dr. Evelyn Vance', 'stjude.orders@stjude.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-882-1044', 6, 'Hospital Transfusion Service', 1),
(7, 'STAFF-007', 'Audit Inspector Cole', 'auditor@lifeblood.org', '$2y$12$Nq9v7Jx0nEv3zZ.rLwO9.O9sTqC8k5o3YqM3o3.eZ1X/L8k2eYwSa', '+1-555-010-0007', 7, 'Clinical Governance & Compliance', 1);

-- ------------------------------------------------------------------------------
-- 7. SEED REGISTERED DONORS
-- ------------------------------------------------------------------------------
INSERT INTO `donors` (`id`, `donor_number`, `first_name`, `last_name`, `national_id`, `date_of_birth`, `sex`, `blood_group_id`, `phone`, `email`, `address`, `city`, `emergency_contact_name`, `emergency_contact_phone`, `status`, `consent_signed`, `consent_date`, `total_donations`, `last_donation_date`, `next_eligible_date`, `registered_by_user_id`) VALUES
(1, 'DON-2026-00101', 'Abdi', 'Warsame', 'NAT-8829104', '1992-04-14', 'Male', 8, '+1-555-201-9988', 'abdi.warsame@example.com', '14 Ocean View Avenue', 'Capital City', 'Hodan Warsame (Spouse)', '+1-555-201-9989', 'Active', 1, '2026-01-15', 7, '2026-08-12', '2026-11-12', 5),
(2, 'DON-2026-00102', 'Liam', 'O\'Connor', 'NAT-7749210', '1988-11-23', 'Male', 7, '+1-555-302-8811', 'liam.oc@example.com', '78 Pinecrest Drive', 'Northwood', 'Sean O\'Connor (Brother)', '+1-555-302-8812', 'Active', 1, '2026-02-10', 4, '2026-09-02', '2026-12-02', 5),
(3, 'DON-2026-00103', 'Faduma', 'Ali', 'NAT-6638192', '1995-07-08', 'Female', 1, '+1-555-403-7722', 'faduma.ali@example.com', '210 Maple Terrace', 'Capital City', 'Mariam Ali (Sister)', '+1-555-403-7723', 'Active', 1, '2026-03-01', 5, '2026-07-28', '2026-11-28', 5),
(4, 'DON-2026-00104', 'Mateo', 'Silva', 'NAT-5527183', '1990-09-19', 'Male', 3, '+1-555-504-6633', 'mateo.silva@example.com', '44 Highland Road', 'Eastgate', 'Lucia Silva (Spouse)', '+1-555-504-6634', 'Active', 1, '2026-02-18', 3, '2026-09-15', '2026-12-15', 5),
(5, 'DON-2026-00105', 'Chloe', 'Dubois', 'NAT-4416074', '1997-02-04', 'Female', 5, '+1-555-605-5544', 'chloe.d@example.com', '312 River Road', 'Northwood', 'Marc Dubois (Father)', '+1-555-605-5545', 'Active', 1, '2026-04-12', 2, '2026-08-30', '2026-12-30', 5),
(6, 'DON-2026-00106', 'Zahra', 'Nur', 'NAT-3305965', '1993-12-30', 'Female', 2, '+1-555-706-4455', 'zahra.nur@example.com', '95 Cedar Lane', 'Capital City', 'Bilal Nur (Brother)', '+1-555-706-4456', 'Active', 1, '2026-01-20', 6, '2026-09-20', '2026-01-20', 5);

-- ------------------------------------------------------------------------------
-- 8. SEED SYSTEM SETTINGS
-- ------------------------------------------------------------------------------
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `description`) VALUES
('organization_name', 'LifeBlood Transfusion Authority', 'Official name displayed on headers and slips'),
('default_language', 'en', 'System initial language (en, so, ar)'),
('timezone', 'Africa/Mogadishu', 'Default operational timezone'),
('enable_feefo', '1', 'Enforce First Expired, First Out inventory issuance'),
('session_timeout_minutes', '30', 'Automatic logout duration for security compliance'),
('emergency_o_negative_reserve', '15', 'Minimum units of O- reserved strictly for life-threatening trauma'),
('contact_hotline', '+1-555-BLOOD-24', 'Emergency 24/7 blood dispatcher hotline');
