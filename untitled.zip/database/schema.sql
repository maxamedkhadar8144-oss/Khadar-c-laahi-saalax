-- ==============================================================================
-- LIFEBLOOD — ADVANCED BLOOD BANK MANAGEMENT SYSTEM (BBMS)
-- DATABASE SCHEMA FOR MYSQL 8.0+ / MARIADB 10.4+ (XAMPP WINDOWS COMPLIANT)
-- ENGINE: InnoDB | CHARSET: utf8mb4 | COLLATION: utf8mb4_unicode_ci
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `blood_bank_db` 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `blood_bank_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------------------------
-- 1. ROLES & PERMISSIONS (RBAC)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `slug` VARCHAR(50) NOT NULL UNIQUE,
    `name` VARCHAR(100) NOT NULL,
    `description` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `permissions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `module` VARCHAR(50) NOT NULL,
    `slug` VARCHAR(80) NOT NULL UNIQUE,
    `name` VARCHAR(120) NOT NULL,
    `description` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `role_permissions` (
    `role_id` INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`role_id`, `permission_id`),
    FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2. USERS & STAFF ACCOUNTS
-- ------------------------------------------------------------------------------
CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `staff_id` VARCHAR(30) NOT NULL UNIQUE,
    `name` VARCHAR(120) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(30) NULL,
    `role_id` INT UNSIGNED NOT NULL,
    `facility_id` INT UNSIGNED NULL,
    `department` VARCHAR(80) NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `require_password_change` TINYINT(1) DEFAULT 0,
    `failed_login_attempts` INT UNSIGNED DEFAULT 0,
    `lockout_until` DATETIME NULL,
    `last_login_at` DATETIME NULL,
    `last_login_ip` VARCHAR(45) NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3. BLOOD GROUPS & COMPONENT DEFINITIONS
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `blood_groups`;
CREATE TABLE `blood_groups` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `group_name` VARCHAR(10) NOT NULL UNIQUE, -- 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
    `abo_type` ENUM('A', 'B', 'AB', 'O') NOT NULL,
    `rh_factor` ENUM('Positive', 'Negative') NOT NULL,
    `min_stock_threshold` INT UNSIGNED DEFAULT 15,
    `critical_shortage_threshold` INT UNSIGNED DEFAULT 5,
    `description` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `blood_components`;
CREATE TABLE `blood_components` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(20) NOT NULL UNIQUE, -- 'WB', 'PRBC', 'PLT', 'FFP', 'CRYO'
    `name` VARCHAR(100) NOT NULL,
    `storage_temp_celsius` VARCHAR(50) NOT NULL, -- e.g. '2°C to 6°C', '-18°C or colder'
    `default_shelf_life_days` INT UNSIGNED NOT NULL,
    `standard_unit_volume_ml` INT UNSIGNED NOT NULL,
    `requires_agitation` TINYINT(1) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 4. DONATION CENTERS & STORAGE LOCATIONS
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `donation_centers`;
CREATE TABLE `donation_centers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(30) NOT NULL UNIQUE,
    `name` VARCHAR(150) NOT NULL,
    `address` VARCHAR(255) NOT NULL,
    `city` VARCHAR(80) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `storage_locations`;
CREATE TABLE `storage_locations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `center_id` INT UNSIGNED NOT NULL,
    `location_code` VARCHAR(50) NOT NULL UNIQUE,
    `location_name` VARCHAR(100) NOT NULL,
    `equipment_type` ENUM('Blood Bank Refrigerator', 'Ultra-Low Freezer', 'Platelet Agitator', 'Quarantine Cooler') NOT NULL,
    `target_temp_min` DECIMAL(4,1) NOT NULL,
    `target_temp_max` DECIMAL(4,1) NOT NULL,
    `capacity_units` INT UNSIGNED NOT NULL DEFAULT 500,
    `is_active` TINYINT(1) DEFAULT 1,
    FOREIGN KEY (`center_id`) REFERENCES `donation_centers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 5. DONOR REGISTRATION & SCREENING
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `donor_deferrals`;
DROP TABLE IF EXISTS `donor_screenings`;
DROP TABLE IF EXISTS `donors`;

CREATE TABLE `donors` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `donor_number` VARCHAR(30) NOT NULL UNIQUE, -- e.g. 'DON-2026-00101'
    `first_name` VARCHAR(80) NOT NULL,
    `last_name` VARCHAR(80) NOT NULL,
    `national_id` VARCHAR(50) NULL UNIQUE,
    `date_of_birth` DATE NOT NULL,
    `sex` ENUM('Male', 'Female', 'Other') NOT NULL,
    `blood_group_id` INT UNSIGNED NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `email` VARCHAR(120) NULL,
    `address` TEXT NOT NULL,
    `city` VARCHAR(80) NOT NULL,
    `emergency_contact_name` VARCHAR(120) NULL,
    `emergency_contact_phone` VARCHAR(30) NULL,
    `status` ENUM('Active', 'Temporarily Deferred', 'Permanently Deferred', 'Inactive') DEFAULT 'Active',
    `consent_signed` TINYINT(1) DEFAULT 1,
    `consent_date` DATE NOT NULL,
    `total_donations` INT UNSIGNED DEFAULT 0,
    `last_donation_date` DATE NULL,
    `next_eligible_date` DATE NULL,
    `preferred_contact_method` ENUM('SMS', 'Email', 'Phone') DEFAULT 'SMS',
    `registered_by_user_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
    FOREIGN KEY (`registered_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `donor_screenings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `donor_id` INT UNSIGNED NOT NULL,
    `screening_date` DATETIME NOT NULL,
    `weight_kg` DECIMAL(5,2) NOT NULL,
    `hemoglobin_g_dl` DECIMAL(4,1) NOT NULL,
    `systolic_bp` INT UNSIGNED NOT NULL,
    `diastolic_bp` INT UNSIGNED NOT NULL,
    `pulse_bpm` INT UNSIGNED NOT NULL,
    `temperature_celsius` DECIMAL(4,1) NOT NULL,
    `passed_health_questionnaire` TINYINT(1) NOT NULL DEFAULT 1,
    `is_eligible` TINYINT(1) NOT NULL DEFAULT 1,
    `ineligibility_reason` VARCHAR(255) NULL,
    `screened_by_user_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`screened_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `donor_deferrals` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `donor_id` INT UNSIGNED NOT NULL,
    `deferral_type` ENUM('Temporary', 'Permanent') NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NULL,
    `authorized_by_user_id` INT UNSIGNED NOT NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`authorized_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 6. DONATIONS & BLOOD UNITS
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `inventory_transactions`;
DROP TABLE IF EXISTS `component_derivations`;
DROP TABLE IF EXISTS `blood_units`;
DROP TABLE IF EXISTS `donations`;

CREATE TABLE `donations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `donation_number` VARCHAR(35) NOT NULL UNIQUE, -- 'DN-2026-10491'
    `donor_id` INT UNSIGNED NOT NULL,
    `center_id` INT UNSIGNED NOT NULL,
    `screening_id` INT UNSIGNED NULL,
    `donation_date` DATETIME NOT NULL,
    `collection_type` ENUM('Whole Blood', 'Apheresis Platelets', 'Apheresis Plasma') DEFAULT 'Whole Blood',
    `volume_collected_ml` INT UNSIGNED NOT NULL DEFAULT 450,
    `bag_barcode` VARCHAR(50) NOT NULL UNIQUE,
    `anticoagulant_batch` VARCHAR(50) NOT NULL,
    `collection_outcome` ENUM('Successful', 'Incomplete', 'Failed') NOT NULL DEFAULT 'Successful',
    `has_adverse_reaction` TINYINT(1) DEFAULT 0,
    `reaction_severity` ENUM('Mild', 'Moderate', 'Severe') NULL,
    `reaction_notes` TEXT NULL,
    `phlebotomist_user_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`),
    FOREIGN KEY (`center_id`) REFERENCES `donation_centers` (`id`),
    FOREIGN KEY (`screening_id`) REFERENCES `donor_screenings` (`id`),
    FOREIGN KEY (`phlebotomist_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blood_units` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `unit_barcode` VARCHAR(40) NOT NULL UNIQUE, -- 'DIN-2026-08819'
    `donation_id` INT UNSIGNED NOT NULL,
    `component_id` INT UNSIGNED NOT NULL,
    `blood_group_id` INT UNSIGNED NOT NULL,
    `volume_ml` INT UNSIGNED NOT NULL,
    `collection_date` DATETIME NOT NULL,
    `expiry_date` DATETIME NOT NULL,
    `storage_location_id` INT UNSIGNED NOT NULL,
    `status` ENUM('Collected', 'Quarantined', 'Under Testing', 'Released', 'Reserved', 'Issued', 'Expired', 'Discarded', 'Recalled', 'Transferred') NOT NULL DEFAULT 'Quarantined',
    `discard_reason` VARCHAR(255) NULL,
    `discard_date` DATETIME NULL,
    `discarded_by_user_id` INT UNSIGNED NULL,
    `version` INT UNSIGNED NOT NULL DEFAULT 1, -- Optimistic locking safeguard
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`donation_id`) REFERENCES `donations` (`id`),
    FOREIGN KEY (`component_id`) REFERENCES `blood_components` (`id`),
    FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
    FOREIGN KEY (`storage_location_id`) REFERENCES `storage_locations` (`id`),
    FOREIGN KEY (`discarded_by_user_id`) REFERENCES `users` (`id`),
    INDEX `idx_status_expiry` (`status`, `expiry_date`),
    INDEX `idx_group_component` (`blood_group_id`, `component_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `component_derivations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `parent_unit_id` INT UNSIGNED NOT NULL,
    `derived_unit_id` INT UNSIGNED NOT NULL,
    `separation_date` DATETIME NOT NULL,
    `centrifuge_protocol` VARCHAR(100) NULL,
    `technician_user_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`parent_unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`derived_unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`technician_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 7. LABORATORY TESTING & RELEASE WORKFLOW
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `laboratory_results`;
DROP TABLE IF EXISTS `laboratory_tests`;

CREATE TABLE `laboratory_tests` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `unit_id` INT UNSIGNED NOT NULL,
    `sample_barcode` VARCHAR(45) NOT NULL UNIQUE,
    `test_category` ENUM('Immunohematology', 'Infectious Disease', 'Confirmatory') NOT NULL,
    `abo_verified` ENUM('A', 'B', 'AB', 'O') NULL,
    `rh_verified` ENUM('Positive', 'Negative') NULL,
    `antibody_screen_result` ENUM('Negative', 'Positive', 'Inconclusive') DEFAULT 'Negative',
    `hiv_result` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    `hbsag_result` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    `hcv_result` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    `syphilis_result` ENUM('Non-Reactive', 'Reactive', 'Pending') DEFAULT 'Pending',
    `overall_decision` ENUM('Pending', 'Released', 'Rejected') DEFAULT 'Pending',
    `tested_by_user_id` INT UNSIGNED NOT NULL,
    `verified_by_user_id` INT UNSIGNED NULL,
    `verified_at` DATETIME NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`tested_by_user_id`) REFERENCES `users` (`id`),
    FOREIGN KEY (`verified_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 8. HOSPITALS & BLOOD REQUEST MANAGEMENT
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `blood_returns`;
DROP TABLE IF EXISTS `blood_issues`;
DROP TABLE IF EXISTS `blood_reservations`;
DROP TABLE IF EXISTS `crossmatch_records`;
DROP TABLE IF EXISTS `blood_request_items`;
DROP TABLE IF EXISTS `blood_requests`;
DROP TABLE IF EXISTS `hospitals`;

CREATE TABLE `hospitals` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hospital_code` VARCHAR(30) NOT NULL UNIQUE,
    `name` VARCHAR(150) NOT NULL,
    `facility_type` ENUM('Tertiary Hospital', 'Regional Referral Hospital', 'Specialized Trauma Center', 'Maternity Hospital', 'Private Clinic') NOT NULL,
    `address` TEXT NOT NULL,
    `city` VARCHAR(80) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `email` VARCHAR(120) NOT NULL,
    `license_number` VARCHAR(60) NOT NULL,
    `contact_person` VARCHAR(100) NOT NULL,
    `contact_phone` VARCHAR(30) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blood_requests` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `request_number` VARCHAR(35) NOT NULL UNIQUE, -- 'REQ-2026-00441'
    `hospital_id` INT UNSIGNED NOT NULL,
    `requesting_clinician` VARCHAR(120) NOT NULL,
    `clinician_phone` VARCHAR(30) NOT NULL,
    `patient_reference_number` VARCHAR(50) NOT NULL,
    `patient_name_masked` VARCHAR(80) NULL, -- Redacted or initials only for privacy
    `patient_blood_group_id` INT UNSIGNED NULL,
    `clinical_indication` VARCHAR(255) NOT NULL,
    `priority` ENUM('Routine', 'Urgent', 'Emergency') NOT NULL DEFAULT 'Routine',
    `status` ENUM('Draft', 'Submitted', 'Under Review', 'Approved', 'Partially Fulfilled', 'Fulfilled', 'Rejected', 'Cancelled') NOT NULL DEFAULT 'Submitted',
    `required_by_datetime` DATETIME NOT NULL,
    `rejection_reason` VARCHAR(255) NULL,
    `processed_by_user_id` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`),
    FOREIGN KEY (`patient_blood_group_id`) REFERENCES `blood_groups` (`id`),
    FOREIGN KEY (`processed_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blood_request_items` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `request_id` INT UNSIGNED NOT NULL,
    `component_id` INT UNSIGNED NOT NULL,
    `blood_group_id` INT UNSIGNED NOT NULL,
    `quantity_requested` INT UNSIGNED NOT NULL,
    `quantity_issued` INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`component_id`) REFERENCES `blood_components` (`id`),
    FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `crossmatch_records` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `request_id` INT UNSIGNED NOT NULL,
    `unit_id` INT UNSIGNED NOT NULL,
    `test_datetime` DATETIME NOT NULL,
    `method` ENUM('Immediate Spin', 'Indirect Antiglobulin Test (IAT)', 'Gel Card') NOT NULL,
    `result` ENUM('Compatible', 'Incompatible', 'Inconclusive') NOT NULL,
    `verification_code` VARCHAR(50) NOT NULL,
    `technician_user_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`),
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`technician_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blood_reservations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `request_id` INT UNSIGNED NOT NULL,
    `unit_id` INT UNSIGNED NOT NULL UNIQUE,
    `reserved_at` DATETIME NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `reserved_by_user_id` INT UNSIGNED NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`),
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`reserved_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 9. BLOOD ISSUE & TRANSFUSION TRACEABILITY
-- ------------------------------------------------------------------------------
CREATE TABLE `blood_issues` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `issue_slip_number` VARCHAR(35) NOT NULL UNIQUE, -- 'ISS-2026-00918'
    `request_id` INT UNSIGNED NOT NULL,
    `unit_id` INT UNSIGNED NOT NULL,
    `crossmatch_id` INT UNSIGNED NULL,
    `hospital_id` INT UNSIGNED NOT NULL,
    `issuing_user_id` INT UNSIGNED NOT NULL,
    `receiving_officer_name` VARCHAR(100) NOT NULL,
    `receiving_officer_id` VARCHAR(50) NOT NULL,
    `transport_temperature_celsius` DECIMAL(4,1) NOT NULL,
    `transport_box_id` VARCHAR(40) NOT NULL,
    `issue_datetime` DATETIME NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`),
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`crossmatch_id`) REFERENCES `crossmatch_records` (`id`),
    FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`),
    FOREIGN KEY (`issuing_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blood_returns` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `issue_id` INT UNSIGNED NOT NULL,
    `unit_id` INT UNSIGNED NOT NULL,
    `return_date` DATETIME NOT NULL,
    `return_reason` VARCHAR(255) NOT NULL,
    `cold_chain_maintained` TINYINT(1) NOT NULL,
    `visual_inspection_passed` TINYINT(1) NOT NULL,
    `inspection_decision` ENUM('Restocked to Quarantine', 'Discarded as Wastage') NOT NULL,
    `inspected_by_user_id` INT UNSIGNED NOT NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`issue_id`) REFERENCES `blood_issues` (`id`),
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`inspected_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 10. RECALLS, ALERTS, AUDIT & APPOINTMENTS
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `adverse_reaction_reports`;
DROP TABLE IF EXISTS `recalls`;
DROP TABLE IF EXISTS `appointments`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `system_settings`;

CREATE TABLE `recalls` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `recall_code` VARCHAR(35) NOT NULL UNIQUE,
    `reason` VARCHAR(255) NOT NULL,
    `severity` ENUM('Critical', 'High', 'Moderate') NOT NULL,
    `affected_donor_id` INT UNSIGNED NULL,
    `affected_unit_id` INT UNSIGNED NULL,
    `status` ENUM('Active', 'Investigating', 'Quarantined', 'Resolved') NOT NULL DEFAULT 'Active',
    `initiated_by_user_id` INT UNSIGNED NOT NULL,
    `action_taken` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`affected_donor_id`) REFERENCES `donors` (`id`),
    FOREIGN KEY (`affected_unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`initiated_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `adverse_reaction_reports` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `issue_id` INT UNSIGNED NOT NULL,
    `patient_reference` VARCHAR(50) NOT NULL,
    `reaction_type` VARCHAR(100) NOT NULL, -- TRALI, Febrile Non-Hemolytic, Acute Hemolytic, etc.
    `onset_time` DATETIME NOT NULL,
    `clinical_symptoms` TEXT NOT NULL,
    `investigation_status` ENUM('Under Review', 'Confirmed TR', 'Ruled Out') DEFAULT 'Under Review',
    `reported_by_clinician` VARCHAR(120) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`issue_id`) REFERENCES `blood_issues` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `appointments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `donor_id` INT UNSIGNED NOT NULL,
    `center_id` INT UNSIGNED NOT NULL,
    `appointment_date` DATE NOT NULL,
    `appointment_time` TIME NOT NULL,
    `status` ENUM('Scheduled', 'Confirmed', 'Completed', 'Cancelled', 'No-Show') DEFAULT 'Scheduled',
    `reminder_sent` TINYINT(1) DEFAULT 0,
    `notes` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`),
    FOREIGN KEY (`center_id`) REFERENCES `donation_centers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(60) NOT NULL,
    `entity_id` VARCHAR(50) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `user_agent` VARCHAR(255) NULL,
    `old_values` JSON NULL,
    `new_values` JSON NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    INDEX `idx_action_date` (`action`, `created_at`),
    INDEX `idx_entity` (`entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `inventory_transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `unit_id` INT UNSIGNED NOT NULL,
    `transaction_type` ENUM('Collection', 'Testing Quarantine', 'Release', 'Reservation', 'Issue', 'Discard', 'Recall', 'Return') NOT NULL,
    `from_status` VARCHAR(40) NULL,
    `to_status` VARCHAR(40) NOT NULL,
    `reference_doc` VARCHAR(80) NULL,
    `authorized_by_user_id` INT UNSIGNED NOT NULL,
    `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`unit_id`) REFERENCES `blood_units` (`id`),
    FOREIGN KEY (`authorized_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `system_settings` (
    `setting_key` VARCHAR(60) PRIMARY KEY,
    `setting_value` TEXT NOT NULL,
    `description` VARCHAR(255) NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
