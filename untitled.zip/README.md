# LifeBlood — Advanced Blood Bank Management System (BBMS)

An enterprise-grade, clinical Blood Bank Management System engineered for hospitals, regional blood transfusion centers, and clinical laboratories. Designed to support stringent transfusion safety, First Expired, First Out (FEFO) inventory accounting, infectious disease release barriers, and end-to-end vein-to-vein traceability.

---

## 1. System Architecture & Database Highlights

- **Normalized Relational Schema**: 30+ tables with strict foreign-key integrity, optimistic row versioning, and zero cascading deletes on clinical history.
- **Role-Based Access Control (RBAC)**: 7 distinct staff roles:
  1. Super Administrator
  2. Blood Bank Administrator
  3. Blood Bank Technician
  4. Laboratory Technician
  5. Donor Registration Officer
  6. Hospital / Requesting Clinician
  7. Report Viewer
- **Vein-to-Vein Traceability**: Donor $\rightarrow$ Whole Blood Unit $\rightarrow$ Laboratory Testing $\rightarrow$ Component Fractionation (PRBC, Platelets, FFP, Cryo) $\rightarrow$ Hospital Request & Crossmatch $\rightarrow$ Controlled Cold-Chain Issue $\rightarrow$ Transfusion Outcome.
- **Safety Rule Enforcements**:
  - Untested or non-released units are automatically quarantined; clinical release is barred without verified negative viral screening (HIV, HBV, HCV, Syphilis).
  - Whole Blood and derived components share strict parent-child lineage so inventory balances are never double-counted.
  - Active recalls cascade instant quarantine flags across all products derived from the flagged donor.

---

## 2. Windows Installation via XAMPP (Apache, PHP 8.2+, MySQL)

Follow these exact steps to run LifeBlood on Windows:

### Step 1: Install & Launch XAMPP
1. Download XAMPP for Windows (with PHP 8.2 or higher) from [Apache Friends](https://www.apachefriends.org/).
2. Run the installer and launch the **XAMPP Control Panel**.
3. Click **Start** for both **Apache** and **MySQL**. Verify that both indicators turn green.

### Step 2: Deploy Project Files
1. Copy or extract this project folder into your XAMPP root:
   ```text
   C:\xampp\htdocs\blood-bank-management
   ```
2. Verify that the folder structure matches:
   ```text
   C:\xampp\htdocs\blood-bank-management\
     ├── app\
     │    ├── Controllers\
     │    ├── Models\
     │    └── Helpers\
     ├── config\
     │    └── database.php
     ├── database\
     │    ├── schema.sql
     │    └── seed.sql
     ├── public\
     │    └── index.php
     └── README.md
   ```

### Step 3: Initialize Database in phpMyAdmin
1. Open your browser and navigate to `http://localhost/phpmyadmin`.
2. Click **Databases** on the top menu, enter `blood_bank_db`, and select collation `utf8mb4_unicode_ci`. Click **Create**.
3. Select `blood_bank_db` in the left sidebar and navigate to the **Import** tab.
4. Click **Choose File**, select `C:\xampp\htdocs\blood-bank-management\database\schema.sql`, and click **Import** (or **Go**).
5. Once complete, click **Import** again, choose `C:\xampp\htdocs\blood-bank-management\database\seed.sql`, and click **Import**.

### Step 4: Verify Database Connection
Open `config/database.php` in a text editor. By default for XAMPP:
- **Host**: `127.0.0.1`
- **Database**: `blood_bank_db`
- **Username**: `root`
- **Password**: `""` (empty string)

If you have a custom MySQL root password in XAMPP, update `$password = 'your_password';`.

### Step 5: Launch LifeBlood
Open your browser and navigate to:
```text
http://localhost/blood-bank-management/public
```

---

## 3. Pre-Configured Test Accounts (Phase 1)

All test accounts are seeded with password: `Admin@12345`

| Role | Email | Responsibilities |
| :--- | :--- | :--- |
| **Super Administrator** | `admin@lifeblood.org` | System configuration, audit logs, user management |
| **Blood Bank Administrator** | `operations@lifeblood.org` | Operational thresholds, staff oversight, emergency release |
| **Laboratory Technician** | `lab@lifeblood.org` | Immunohematology typing, viral screening, release sign-off |
| **Blood Bank Technician** | `tech@lifeblood.org` | Component fractionation, cold-room storage, FEFO dispatch |
| **Donor Registration Officer** | `donors@lifeblood.org` | Donor intake, screening interviews, deferrals, cards |
| **Hospital Requesting Officer** | `stjude.orders@stjude.org` | Emergency & routine blood orders, patient crossmatch |
| **Report Viewer** | `auditor@lifeblood.org` | Read-only analytics, stock registers, and regulatory logs |

---

## 4. Troubleshooting Common Windows / XAMPP Issues

1. **Port 80 / 443 Conflict (Apache won't start)**:
   - In XAMPP Control Panel, click **Config** $\rightarrow$ `httpd.conf` on the Apache row.
   - Find `Listen 80` and change to `Listen 8080`.
   - Access the system at `http://localhost:8080/blood-bank-management/public`.
2. **Port 3306 Conflict (MySQL won't start)**:
   - Ensure an existing MySQL or MariaDB Windows service is not already running. Run `services.msc` and stop any standalone MySQL instance before starting XAMPP MySQL.
3. **PDO MySQL Extension Missing**:
   - In XAMPP Control Panel, click **Config** $\rightarrow$ `php.ini` on Apache.
   - Ensure the line `extension=pdo_mysql` is uncommented (no leading semicolon `;`).
